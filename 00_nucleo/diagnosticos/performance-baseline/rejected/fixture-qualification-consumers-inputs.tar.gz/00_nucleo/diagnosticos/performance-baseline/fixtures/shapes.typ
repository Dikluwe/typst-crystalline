#set page(width: 400pt, height: 600pt, margin: 24pt)
#for i in range(128) { rect(width: 24pt, height: 8pt, fill: blue); linebreak() }