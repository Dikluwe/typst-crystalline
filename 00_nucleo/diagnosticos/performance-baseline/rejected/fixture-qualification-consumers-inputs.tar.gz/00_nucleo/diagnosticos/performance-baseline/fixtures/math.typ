#show math.equation: set text(font: "Baseline Math")
#set page(width: 400pt, height: 600pt, margin: 24pt)
#set text(font: "Libertinus Serif", size: 10pt)


$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $

$ (a+b)/(c+d) + sqrt(x^2 + y^2) $