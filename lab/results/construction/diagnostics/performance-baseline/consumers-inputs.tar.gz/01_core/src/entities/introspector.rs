//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/entities/introspector.md
//! @prompt-hash f8e7201b
//! @layer L1
//! @updated 2026-05-12
//!
//! `Introspector` trait + `TagIntrospector` impl concreta.
//! P165 sub-passo .D (M3 Introspection — núcleo do query layer).
//!
//! Plain trait sem `#[comemo::track]` — tracking deferido para M7+
//! quando fixpoint memoization for relevante. Struct concreta lê
//! sub-stores expostos como fields públicos (composição visível).

use std::collections::HashMap;

use crate::entities::bib_entry::BibEntry;
use crate::entities::bib_store::BibStore;
use crate::entities::counter::CounterKey;
use crate::entities::counter_registry::CounterRegistry;
use crate::entities::element_kind::ElementKind;
use crate::entities::label::Label;
use crate::entities::label_kind::UnreferencableKind;
use crate::entities::label_registry::LabelRegistry;
use crate::entities::location::Location;
use crate::entities::metadata_store::MetadataStore;
use crate::entities::page_store::PageStore;
use crate::entities::resolved_label_store::ResolvedLabelStore;
use crate::entities::selector::Selector;
use crate::entities::state_registry::StateRegistry;
use crate::entities::value::Value;
use ecow::EcoString;

/// Interface de consulta sobre elementos indexados pela introspecção.
///
/// M3 minimal: 5 métodos read-only. `position_of` é stub (retorna
/// sempre `None`) — mecanismo de população virá em M5+ ou M9 quando
/// layout integrar.
///
/// **P168 (M5 sub-passo 2)**: adicionado `figure_number_for_label`
/// para suportar primeira migração real (figure-ref em layout_ref).
///
/// **P204B (M8)** — `#[comemo::track]` aplicado per ADR-0073
/// (paridade vanilla literal). Trait fica `Send + Sync`.
#[comemo::track]
pub trait Introspector: Send + Sync {
    /// Vector de todas as `Location`s indexadas com este kind, em
    /// ordem de aparecimento no walk.
    fn query_by_kind(&self, kind: ElementKind) -> Vec<Location>;

    /// `Some(location)` se a label existir; `None` caso contrário.
    fn query_by_label(&self, label: &Label) -> Option<Location>;

    /// Primeira `Location` indexada com este kind, ou `None` se
    /// nenhuma existir.
    fn query_first(&self, kind: ElementKind) -> Option<Location>;

    /// `Some(loc)` apenas se houver **exactamente** uma `Location`
    /// indexada com este kind. `None` se 0 ou >1.
    fn query_unique(&self, kind: ElementKind) -> Option<Location>;

    /// **P204D (M8)** — assinatura migrada de stub `Option<()>`
    /// para `Option<Position>` per ADR-0073 (paridade vanilla
    /// literal: `fn position(&self, loc: Location) -> Option<DocumentPosition>`).
    ///
    /// `TagIntrospector` impl retorna sempre `None` — Position
    /// vive em `Layouter.runtime.positions` (single-pass populated
    /// durante layout, per P203A C5). Consumers que precisem de
    /// Position acedem via Layouter directamente, não via
    /// trait. ADR-0073 §C6a (P204D diagnóstico).
    ///
    /// Future trait impl que **tenha** acesso a Layouter runtime
    /// (ex: PagedIntrospector pós-layout, análogo vanilla)
    /// pode override e retornar `Some(Position)`.
    fn position_of(
        &self,
        location: Location,
    ) -> Option<crate::entities::position::Position>;

    /// P1493 — posição local de uma Location dentro de \`html.frame\`.
    ///
    /// Implementações sem store HTML preservam ausência por defeito.
    fn html_position_of(
        &self,
        location: Location,
    ) -> Option<crate::entities::position::HtmlPosition> {
        let _ = location;
        None
    }

    /// P168 (M5): número 1-based da figura associada à label, **apenas
    /// se a figura é numerada+captioned**. Equivalente ao
    /// `state.figure_label_numbers.get(label).copied()` legacy.
    /// Retorna `None` se label não existe, não pertence a uma figura,
    /// ou figura não tem numbering+caption.
    fn figure_number_for_label(&self, label: &Label) -> Option<usize>;

    /// **P169 (M9 sub-passo 1)** — todos os values embebidos via
    /// `metadata(value)` vanilla, na ordem de aparecimento no walk.
    /// Retorna slice vazio se nenhum metadata existir.
    fn query_metadata(&self) -> &[Value];

    /// **P170 (M9 sub-passo 2)** — formato hierárquico do counter
    /// como string ("1.2.3"). Equivalente a
    /// `state.format_hierarchical(key)` legacy. Suporta lacuna #5.
    fn formatted_counter(&self, key: &CounterKey) -> Option<String>;

    /// **P171 (M9 sub-passo 3)** — valor do state `key` na Location
    /// indicada. Aplica updates ordenados até `location` (inclusive).
    /// Retorna `None` se key não foi inicializada.
    fn state_value(&self, key: &str, location: Location) -> Option<&Value>;

    /// **P171 (M9 sub-passo 3)** — valor final do state `key` (último
    /// update aplicado). Equivalente a `state_value(key, last_loc)`.
    ///
    /// **P240 (M9d/M7+1) — two-pass real**: após fixpoint convergência,
    /// `apply_state_funcs` (P191B) avalia `StateUpdate::Func` cumulativo;
    /// `final_value` lê `history.last()` — portanto retorna o valor
    /// final two-pass real (paridade vanilla `state.final()`). Não
    /// requer refactor adicional pós-P240 audit C7 cenário α confirmado.
    fn state_final_value(&self, key: &str) -> Option<&Value>;

    /// **P240 (M9d/M7+1)** — Content pre-rendered para `state.display`.
    /// Owned `Content` (clone) — necessário porque `Tracked` não permite
    /// retornar `&Content` directo. Caller layout arm
    /// `Content::StateDisplay` consome valor. `None` se `(key, loc)` não
    /// foi populated (fixpoint pre-walk ainda não convergiu OR Func
    /// errored OR key inexistente em `loc`).
    fn state_display_value(
        &self,
        key: String,
        location: Location,
    ) -> Option<crate::entities::content::Content>;

    /// **P241 (M9d/M7+2)** — Content pre-rendered para `counter.display`
    /// paralelo absoluto `state_display_value` P240. Caller layout arm
    /// `Content::CounterDisplayCallback` consome valor pre-rendered
    /// produzido por `apply_counter_displays` pós-fixpoint.
    fn counter_display_value(
        &self,
        key: CounterKey,
        location: Location,
    ) -> Option<crate::entities::content::Content>;

    /// **P175 (M9 sub-passo 5)** — query genérica via `Selector`.
    /// P175 minimal: só `Selector::Kind(kind)`, que delega a
    /// `query_by_kind`. Variants futuros (`Label`, `And`, `Or`,
    /// `Where`) ficam para passos dedicados.
    fn query(&self, selector: &Selector) -> Vec<Location>;

    /// **P844** (achado #47 de P831) — `Content` do elemento na
    /// `Location` indicada, registado pelo walk no sub-store
    /// `elements`. Alimenta `query()` para devolver o elemento
    /// encontrado (com campos acessíveis) em vez de só a `Location` —
    /// paridade vanilla `query() -> array<content>`. `None` para
    /// introspectors sintéticos (construídos sem walk, ex.: testes que
    /// populam `kind_index` directamente) — callers fazem fallback
    /// para `Value::Location` nesse caso.
    fn element_at(
        &self,
        location: Location,
    ) -> Option<&crate::entities::content::Content>;

    /// **P177 (M9 sub-passo 7)** — formato hierárquico do counter
    /// na `Location` indicada. `None` se key inexistente ou history
    /// vazia para `loc <= location`.
    fn formatted_counter_at(
        &self,
        key: &CounterKey,
        location: Location,
    ) -> Option<String>;

    /// **P451** — valores brutos do counter hierárquico na `Location`
    /// indicada. Permite ao layout aplicar patterns de formatação
    /// configuráveis (romanos, letras, etc.). `None` se key inexistente
    /// ou history vazia para `loc <= location`.
    fn counter_values_at(&self, key: &CounterKey, location: Location)
        -> Option<&[usize]>;

    /// **P844** (achado #49 de P831) — valores brutos **finais** do
    /// counter `key` (estado após o walk completo da iteração de
    /// fixpoint anterior). Alimenta o método `counter.final()` —
    /// paridade vanilla `Counter::final` (`introspection/counter.rs`).
    /// Delega a `CounterRegistry::value`. `None` se key nunca foi
    /// tocado (caller faz fallback para `[0]`, como `counter.get`).
    fn counter_final_values(&self, key: &CounterKey) -> Option<&[usize]>;

    /// **P462** — chave do counter associada a uma `Label` (ex: "heading",
    /// "figure:image", "equation", "table"). `None` se a label não existe
    /// ou não está associada a um elemento numerado.
    fn counter_key_for_label(&self, label: &Label) -> Option<&CounterKey>;

    /// **P788** — `Some(flag)` se a `Location` pertence a um heading com
    /// flag de `numbering` registada; `None` se não é heading registado.
    /// Alimenta o erro vanilla `cannot reference heading without numbering`.
    fn heading_has_numbering(&self, location: Location) -> Option<bool>;

    /// **P856** — `Some(flag)` se a `Location` pertence a uma equation com
    /// flag de `numbering` registada; `None` se não é equation registada.
    /// Alimenta o erro vanilla `cannot reference equation without numbering`.
    fn equation_has_numbering(&self, location: Location) -> Option<bool>;

    /// **P1121** — `Some(pattern)` se a `Location` pertence a uma equation com
    /// padrão de `numbering` registado; `None` caso contrário.
    fn equation_numbering_pattern(&self, location: Location) -> Option<&str>;

    fn equation_numbering_content(
        &self,
        location: Location,
    ) -> Option<crate::entities::content::Content>;

    fn equation_supplement_content(
        &self,
        location: Location,
    ) -> Option<crate::entities::content::Content>;

    /// **P856** — `Some(kind)` se a label existe no documento mas está
    /// associada a conteúdo não referenciável (texto, raw, etc.);
    /// `None` caso contrário. Usado por `layout_ref` para emitir a
    /// mensagem de erro específica do tipo.
    fn unreferencable_label_kind(
        &self,
        label: &Label,
    ) -> Option<crate::entities::label_kind::UnreferencableKind>;

    /// **P181F** — entry bibliográfica por chave. Replica
    /// `state.bib_entries.iter().find(|e| e.key == *key)` actual em
    /// `layout/mod.rs:584` (P181G migrará caller). Linear scan sobre
    /// `BibStore::entries`; `None` se key não existe.
    fn bib_entry_for_key(&self, key: &str) -> Option<&BibEntry>;

    /// **P181F** — número 1-based associado à chave bibliográfica.
    /// Replica `state.bib_numbers.get(key).copied()` actual em
    /// `layout/mod.rs:590`. Lookup O(1) via `BibStore::numbers`;
    /// `None` se key não existe.
    fn bib_number_for_key(&self, key: &str) -> Option<u32>;

    /// **P468** — número de citação 1-based por ordem de primeira
    /// aparição da chave no documento. Delega a
    /// `BibStore::citation_number_for_key`.
    fn citation_number_for_key(&self, key: &str) -> Option<u32>;

    /// **P468** — slice com a ordem de primeira aparição das chaves
    /// citadas no documento. Delega a `BibStore::citation_order`.
    fn citation_order(&self) -> &[String];

    /// **P472** — back-references de uma chave bibliográfica: lista
    /// 1-based de posições de citação no documento (em ordem de aparição).
    /// Vec vazio se a key nunca foi citada.
    fn back_refs_for_key(&self, key: &str) -> Vec<usize>;

    /// **P472** — lista de figuras para List of Figures: `(número, caption)`.
    fn figures_for_lof(&self) -> &[(usize, String)];

    /// **P472** — lista de tabelas para List of Tables: `(número, caption)`.
    fn tables_for_lot(&self) -> &[(usize, String)];

    /// **P184C** — número 1-based da figure na posição `idx` (0-indexed)
    /// entre as figures do `kind` indicado, em ordem de aparecimento
    /// no walk. Constrói `CounterKey::Str(format!("figure:{}", kind))` e
    /// delega a `CounterRegistry::value_at_index` (chave populada em P184B
    /// arm Figure de `from_tags`). Default kind `"image"` é
    /// responsabilidade do caller (cf. `mod.rs:431`).
    /// `None` se kind ausente do registry ou idx fora de range.
    fn figure_number_at_index(&self, kind: &str, idx: usize) -> Option<usize>;

    /// **P185B** — valor 1-based de counter flat na `Location`
    /// indicada. Delega a `counters.value_at(key, location)?.last().copied()`.
    /// `None` se key inexistente em `location` ou history vazia.
    /// Para counters flat (figure, equation), `.last()` é o número
    /// actual; para hierárquicos (heading), retorna o nível mais
    /// profundo — usar `formatted_counter_at` (P177) nesse caso.
    /// Suporta C2 (equation counter) — consumer migra em P188 após
    /// P185C. Cf. ADR-0068.
    fn flat_counter_at(&self, key: &CounterKey, location: Location) -> Option<usize>;

    /// **P193B** — texto resolvido para a `Label` indicada. `Some(text)`
    /// se label registada em `ResolvedLabelStore`; `None` caso
    /// contrário. Delega a `resolved_labels.get(label)`.
    ///
    /// **Estado em P193B**: sub-store fica vazio em produção até
    /// P195 adicionar arm de populate em `from_tags`. Walks E2/E4
    /// (P189B) continuam a popular `state.resolved_labels` legacy
    /// directamente; consumer C4 migra em P194 com
    /// substitution-with-fallback (`resolved_label_for(label)
    /// .or_else(|| state.resolved_labels.get(label))`). Vide P193
    /// consolidado §5.
    fn resolved_label_for(&self, label: &Label) -> Option<&str>;

    /// **P200B** (M5 universal completo) — entries de outline (TOC)
    /// emitidas pelo walk arm Heading pós-recursão. Cada entry é
    /// `(auto-label, número puro, frozen body materializado, level)`.
    /// Sub-store `intr.headings_for_toc` populated via `from_tags` arm
    /// `ElementPayload::HeadingForToc`. Fecha **E2-residuo**
    /// (lacuna #3) e completa E2 estruturalmente. Consumer
    /// `layout/outline.rs:24` migrado para substitution-with-fallback.
    fn headings_for_toc(
        &self,
    ) -> &[(Label, Option<String>, crate::entities::content::Content, usize)];

    /// **P606** — entries de bookmarks PDF (`/Outlines`), separadas do
    /// índice do documento. Seguem a mesma forma de `headings_for_toc`, mas
    /// são filtradas pelo valor efectivo de `bookmarked` (explicitamente
    /// definido ou `outlined` como fallback).
    fn headings_for_bookmarks(
        &self,
    ) -> &[(Label, Option<String>, crate::entities::content::Content, usize)];

    /// **P207B (M9c)** — todos os labels registados com a respectiva
    /// `Location`, ordenados alfabéticamente por `Label` (estabilidade
    /// determinística). Delega a `LabelRegistry::iter()` + clone+copy.
    /// Vazio se nenhum label foi adicionado.
    ///
    /// Equivalente vanilla: `Introspector::query_labelled()
    /// -> EcoVec<Content>`. Cristalino retorna handles
    /// `(Label, Location)` em vez de `Content` materializado, por
    /// coerência com design pattern handle-based (ADR-0073 §C6 +
    /// ADR-0074): consumers podem fazer lookup via `Location` quando
    /// precisam do elemento concreto. Primeiro item Bloco I do
    /// roadmap M9c (per ADR-0076).
    fn query_labelled(&self) -> Vec<(Label, Location)>;

    /// **P207C (M9c)** — Número de Locations associadas a `label`.
    /// 0 se label nunca foi registado. Delega a
    /// `LabelRegistry::count(label)`.
    ///
    /// Após o refactor P207C, `LabelRegistry` é multi-label
    /// (`HashMap<Label, Vec<Location>>`), portanto `label_count`
    /// distingue entre "inexistente" (0), "única" (1) e "duplicada"
    /// (≥2). Equivalente vanilla: `Introspector::label_count(Label)
    /// -> usize`. Resolve item 7 da auditoria P207A.
    fn label_count(&self, label: &Label) -> usize;

    /// **P207D (M9c)** — Total de páginas no documento. Vanilla
    /// `PagedIntrospector::pages` ignora o argumento `location` e
    /// devolve sempre o total; cristalino segue a mesma semântica.
    /// `None` pre-injecção (`PageStore::empty()`); `Some(N)`
    /// pós-`inject_pages`. Item 10 da auditoria P207A.
    fn pages(&self, location: Location) -> Option<std::num::NonZeroUsize>;

    /// **P207D (M9c)** — Número de página (1-based) onde `location`
    /// aterra. Delega a `SealedPositions::position_of(location)?.page`.
    /// `None` pre-injecção ou se Location não-locatable. Item 9
    /// da auditoria P207A.
    fn page(&self, location: Location) -> Option<std::num::NonZeroUsize>;

    /// **P207D (M9c)** — Pattern de numbering para a página onde
    /// `location` aterra. Combina `page(location)?` com
    /// `PageStore::numbering_for_page`. Vanilla retorna
    /// `Option<&Numbering>` (enum); cristalino retorna
    /// `Option<&EcoString>` (pattern directo) per ADR-0024.
    /// Item 12 da auditoria P207A.
    fn page_numbering(
        &self,
        location: Location,
    ) -> Option<&crate::entities::numbering::Numbering>;

    /// **P207D (M9c)** — Supplement para a página onde `location`
    /// aterra. Combina `page(location)?` com
    /// `PageStore::supplement_for_page`. Tipo `Option<&Content>`
    /// idêntico a vanilla (cristalino preserva `Content` per
    /// ADR-0026). Item 13 da auditoria P207A.
    fn page_supplement(
        &self,
        location: Location,
    ) -> Option<&crate::entities::content::Content>;
}

/// Implementação concreta de `Introspector` construída a partir de
/// `Vec<Tag>` via `rules/introspect/from_tags::from_tags`.
///
/// Sub-stores são `pub` para composição visível e acesso directo em
/// testes e consumers M4+. Mutação só durante fase de construção
/// via métodos `pub(crate)` dos próprios sub-stores.
#[derive(Debug, Clone, Default)]
pub struct TagIntrospector {
    pub labels: LabelRegistry,
    pub counters: CounterRegistry,
    pub kind_index: HashMap<ElementKind, Vec<Location>>,
    /// **P844** (achado #47 de P831) — mapa `Location → Content` de
    /// cada elemento locatable, populado pelo walk no momento da
    /// emissão da `Tag::Start`. Alimenta `Introspector::element_at`
    /// para `query()` devolver o elemento (paridade vanilla).
    pub elements: HashMap<Location, crate::entities::value::IntrospectedContent>,
    // P168 (M5 sub-passo 2): mapa Label → número 1-based para
    // figuras numeradas+captioned. Populado por `from_tags` quando
    // `ElementPayload::Figure.is_counted == true` E há label associada.
    // Equivalente paralelo a `CounterStateLegacy.figure_label_numbers`
    // — usado por `references.rs::layout_ref` em M5.
    pub figure_label_numbers: HashMap<Label, usize>,
    /// **P462** — mapa `Label → chave do counter` (ex: "heading",
    /// "figure:image", "equation", "table"). Populado durante o walk
    /// quando um elemento numerado é etiquetado via `Content::Label`.
    pub label_to_counter_key: HashMap<Label, CounterKey>,
    /// **P788** — mapa `Location → numbering_active` para headings
    /// (flag baked da chain na emissão; `element_payload.md` §P788).
    /// O counter de heading aplica-se incondicionalmente (P335), logo
    /// "tem counter" ≠ "tem numbering" — este mapa alimenta o erro
    /// vanilla `cannot reference heading without numbering`.
    pub heading_numbering: HashMap<Location, bool>,
    /// **P856** — mapa `Location → numbering_active` para equations,
    /// análogo a `heading_numbering`. Alimenta o erro vanilla
    /// `cannot reference equation without numbering`.
    pub equation_numbering: HashMap<Location, bool>,
    pub equation_numberings: HashMap<Location, Value>,
    /// **P1121** — mapa `Location -> numbering_pattern` para equations.
    pub equation_numbering_pattern: HashMap<Location, ecow::EcoString>,
    pub equation_numbering_callbacks: HashMap<Location, crate::entities::func::Func>,
    pub equation_numbering_contents: HashMap<Location, crate::entities::content::Content>,
    pub equation_supplements: HashMap<Location, crate::entities::value::Value>,
    pub equation_supplement_langs: HashMap<Location, Option<crate::entities::lang::Lang>>,
    pub equation_supplement_contents:
        HashMap<Location, crate::entities::content::Content>,
    pub equation_number_aligns: HashMap<Location, crate::entities::layout_types::Align2D>,
    pub equation_alts: HashMap<Location, Option<EcoString>>,
    /// **P856** — mapa `Label → UnreferencableKind` para labels que
    /// existem no documento mas não são referenciáveis (texto, raw,
    /// etc.). Populado pelo walk arm `Content::Label` quando o body
    /// não produz um Tag locatable/numerável.
    pub unreferencable_labels: HashMap<Label, UnreferencableKind>,
    /// **P169 (M9 sub-passo 1)** — values embebidos via `metadata(value)`
    /// vanilla. Acumulado por `from_tags` em ordem de aparecimento.
    pub metadata: MetadataStore,
    /// **P171 (M9 sub-passo 3)** — runtime mutable state.
    /// `from_tags` popula via arms para `ElementPayload::State` e
    /// `ElementPayload::StateUpdate`.
    pub state: StateRegistry,
    /// **P181B** — sub-store para entries bibliográficas + numeração
    /// 1-based. População começa em P181E (`from_tags` arm
    /// `ElementPayload::Bibliography`); até lá permanece vazio.
    /// Consumer migrará em P181G (Layouter cite-arm via
    /// `Introspector::bib_entry_for_key` / `bib_number_for_key`).
    pub bib_store: BibStore,
    /// **P193B** (M5 sequência §9 P189 passo 1) — sub-store para
    /// mapeamento Label → texto resolvido. População começa em
    /// P195 (`from_tags` arm Labelled emitido após walk arm migrar);
    /// até lá permanece vazio em produção. Consumer C4 migra em
    /// P194 (`layout/references.rs::layout_ref`) com
    /// substitution-with-fallback. Suporta cadeia E2-E6 P189B
    /// fechar incrementalmente.
    pub resolved_labels: ResolvedLabelStore,
    /// **P200B** (M5 universal completo) — sub-store dedicado para
    /// entries de outline (TOC). Tuple por entry: `(auto-label,
    /// número puro, frozen body materializado, level)`. População via
    /// `from_tags` arm `ElementPayload::HeadingForToc` emitido
    /// pelo walk arm Heading pós-recursão (3ª Tag depois de
    /// Heading + Labelled auto-toc P196B). Fecha **E2-residuo**
    /// (lacuna #3 declarada desde P189B/P196B) e completa
    /// estruturalmente E2 (4ª mutação). Consumer
    /// `layout/outline.rs:24` lê via Introspector path com
    /// fallback legacy (`state.headings_for_toc`). Mutação 4
    /// legacy preservada como write paralelo M5 (Layouter
    /// assignments `mod.rs:1490, 1521` dependem); cleanup
    /// orgânico em M6.
    pub headings_for_toc:
        Vec<(Label, Option<String>, crate::entities::content::Content, usize)>,
    /// **P1402** — outlines encontrados, em ordem, para materializar uma
    /// ocorrência pública `outline.entry` por item incluído.
    pub outline_elements: Vec<crate::entities::elements::outline::OutlineElem>,
    /// **P1402** — Locations dos headings que alimentam `headings_for_toc`,
    /// preservadas na mesma ordem para ligar `entry.element` ao snapshot.
    pub outlined_heading_locations: Vec<Location>,
    /// **P1405** — máximos absolutos de `prefix_inset` por chave de outline
    /// e nível 1-based, extraídos dos carriers privados `prefix-info`.
    pub outline_prefix_widths: HashMap<i64, Vec<Option<f64>>>,
    /// **P606** — sub-store dedicado a bookmarks PDF (`/Outlines`).
    /// Populada por `ElementPayload::HeadingForBookmarks`. Partilha a
    /// mesma forma de `headings_for_toc` mas filtra pelo valor efectivo
    /// de `HeadingElem::bookmarked`.
    pub headings_for_bookmarks:
        Vec<(Label, Option<String>, crate::entities::content::Content, usize)>,
    /// **P205C (F3)** — sub-store sealed `Location → Position`
    /// injectado pós-layout via `inject_positions` per ADR-0074.
    /// `Default::default()` é vazio (pre-layout); `position_of`
    /// devolve `None` enquanto não injectado. Caller pós-layout
    /// (cf. tests E2E) faz
    /// `intr.inject_positions(doc.extracted_positions)` para
    /// activar lookup real.
    ///
    /// Cristalino diverge intencionalmente de vanilla
    /// (`PagedIntrospector` separado por valor); cristalino
    /// reusa `TagIntrospector` enriquecido por simplicidade
    /// (P205C C2 = Caminho A; P205A.div-1 — vanilla não tem
    /// Layouter monolítico).
    pub positions: crate::entities::sealed_positions::SealedPositions,
    /// P1493 — store da geração corrente para coordenadas locais HTML.
    ///
    /// Separado de \`positions\`: nunca contém página nem alimenta consultas
    /// paginadas.
    pub html_positions: HashMap<Location, crate::entities::position::HtmlPosition>,
    /// **P207D (M9c)** — sub-store sealed para metadata page-level
    /// per ADR-0076. Injectado pós-layout via `inject_pages`
    /// (paralelo a `inject_positions` P205C). Pre-injecção,
    /// queries page-aware (`pages`, `page_numbering`,
    /// `page_supplement`) retornam `None`. `page(location)` usa
    /// `positions` directamente (não depende de `page_store`).
    pub page_store: PageStore,

    /// **P240 (M9d/M7+1)** — pre-rendered Content por
    /// `(state_key, location)` produzido pelo `apply_state_displays`
    /// pós-fixpoint (paralelo `apply_state_funcs` P191B). Consumer:
    /// layout arm `Content::StateDisplay` via
    /// `Introspector::state_display_value(key, loc)`. Layouter
    /// permanece puro (sem Engine+ctx em signature) — paridade
    /// arquitectural estrita Opção γ P239 audit.
    pub state_displays: HashMap<(String, Location), crate::entities::content::Content>,

    /// **P241 (M9d/M7+2)** — pre-rendered Content por
    /// `(counter_key, location)` produzido pelo
    /// `apply_counter_displays` pós-fixpoint paralelo absoluto
    /// `state_displays` P240. Consumer: layout arm
    /// `Content::CounterDisplayCallback` via
    /// `Introspector::counter_display_value(key, loc)`.
    pub counter_displays:
        HashMap<(CounterKey, Location), crate::entities::content::Content>,

    /// **P472** — lista de figuras para List of Figures: `(número, caption)`.
    /// Populado em `populate_intr_from_tag_start` para Figure `is_counted`.
    pub figures_for_lof: Vec<(usize, String)>,

    /// **P472** — lista de tabelas para List of Tables: `(número, caption)`.
    /// Populado em `populate_intr_from_tag_start` para Table `is_counted`.
    pub tables_for_lot: Vec<(usize, String)>,

    /// **P504** — mapa `Location → Location` do parent imediato no walk.
    /// Populado pós-walk a partir das tags `Start`/`End`.
    pub parent_locations: HashMap<Location, Location>,

    /// **P506** — mapa `ContextBlock id → Location` para expansão
    /// pós-introspecção. Populado durante o walk.
    pub context_block_locations: HashMap<u64, Location>,
}

impl TagIntrospector {
    /// Construtor vazio. Equivalente a `Default::default()`.
    pub fn empty() -> Self {
        Self::default()
    }

    pub(crate) fn record_outline_prefix_width(
        &mut self,
        key: i64,
        level: usize,
        inset: f64,
    ) {
        if level == 0 || !inset.is_finite() {
            return;
        }
        let widths = self.outline_prefix_widths.entry(key).or_default();
        if widths.len() < level {
            widths.resize(level, None);
        }
        let slot = &mut widths[level - 1];
        *slot = Some(slot.map_or(inset, |current| current.max(inset)));
    }

    pub(crate) fn outline_prefix_widths(&self, key: i64) -> &[Option<f64>] {
        self.outline_prefix_widths.get(&key).map(Vec::as_slice).unwrap_or(&[])
    }

    /// **P205C (F3)** — Injecta sub-store sealed
    /// `SealedPositions` produzido por `Layouter::finish` (em
    /// `PagedDocument.extracted_positions`). Pós-injecção,
    /// `position_of` consulta o sealed sub-store em vez de
    /// retornar sempre `None`.
    ///
    /// Pattern de uso:
    /// ```rust
    /// use typst_core::compiler::introspect::introspect_with_introspector;
    /// use typst_core::compiler::layout::layout_with_introspector;
    /// use typst_core::entities::content::Content;
    /// use typst_core::entities::element_kind::ElementKind;
    /// use typst_core::entities::introspector::Introspector;
    ///
    /// let content = Content::heading(1, Content::text("Title"));
    /// let mut intr = introspect_with_introspector(&content);
    /// let location = intr.query_first(ElementKind::Heading).unwrap();
    /// let doc = layout_with_introspector(&content, intr.clone());
    /// intr.inject_positions(doc.extracted_positions.clone());
    /// assert!(intr.position_of(location).is_some());
    /// ```
    ///
    /// Per ADR-0074 (PROPOSTO 2026-05-07; F3 minimal). Fecha
    /// pendência ADR-0073 §C6a.
    pub fn inject_positions(
        &mut self,
        sealed: crate::entities::sealed_positions::SealedPositions,
    ) {
        self.positions = sealed;
    }

    /// P1493 — substitui integralmente o store local HTML da geração.
    pub fn inject_html_positions(
        &mut self,
        positions: HashMap<Location, crate::entities::position::HtmlPosition>,
    ) {
        self.html_positions = positions;
    }

    /// **P207D (M9c)** — Injecta `PageStore` produzido pós-layout
    /// per ADR-0076. Paralelo a `inject_positions` (P205C):
    /// pós-injecção, queries page-aware (`pages`, `page_numbering`,
    /// `page_supplement`) começam a resolver.
    ///
    /// Padrão de uso típico:
    /// ```rust
    /// use std::num::NonZeroUsize;
    /// use typst_core::compiler::introspect::introspect_with_introspector;
    /// use typst_core::compiler::layout::layout_with_introspector;
    /// use typst_core::entities::content::Content;
    /// use typst_core::entities::element_kind::ElementKind;
    /// use typst_core::entities::introspector::Introspector;
    /// use typst_core::entities::page_store::PageStore;
    ///
    /// let content = Content::heading(1, Content::text("one page"));
    /// let mut intr = introspect_with_introspector(&content);
    /// let location = intr.query_first(ElementKind::Heading).unwrap();
    /// let doc = layout_with_introspector(&content, intr.clone());
    /// let total = NonZeroUsize::new(doc.pages.len()).unwrap();
    /// intr.inject_pages(PageStore::from_total_pages(total));
    /// assert_eq!(intr.pages(location), Some(total));
    /// ```
    pub fn inject_pages(&mut self, page_store: PageStore) {
        self.page_store = page_store;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::entities::counter::CounterKey;
    use crate::entities::counter_update::CounterUpdate;

    fn loc(raw: u128) -> Location {
        Location::from_raw(raw)
    }

    fn lbl(s: &str) -> Label {
        Label(s.to_string())
    }

    fn ck(s: &str) -> CounterKey {
        CounterKey::Str(s.into())
    }

    #[test]
    fn empty_devolve_vazio_em_todos_os_queries() {
        let i = TagIntrospector::empty();
        assert_eq!(i.query_by_kind(ElementKind::Heading), Vec::<Location>::new());
        assert_eq!(i.query_by_label(&lbl("foo")), None);
        assert_eq!(i.query_first(ElementKind::Heading), None);
        assert_eq!(i.query_unique(ElementKind::Heading), None);
        assert_eq!(i.position_of(loc(1)), None);
    }

    #[test]
    fn p1405_prefix_width_store_e_maximo_estavel() {
        let mut i = TagIntrospector::empty();
        i.record_outline_prefix_width(7, 2, 11.0);
        i.record_outline_prefix_width(7, 2, 9.0);
        i.record_outline_prefix_width(7, 2, 13.0);
        i.record_outline_prefix_width(8, 1, 5.0);
        assert_eq!(i.outline_prefix_widths(7), &[None, Some(13.0)]);
        assert_eq!(i.outline_prefix_widths(8), &[Some(5.0)]);
        assert!(i.outline_prefix_widths(9).is_empty());
    }

    // ── P204B (M8) — Sentinel tests ──────────────────────────────────────
    //
    // Confirmam que `#[comemo::track]` foi aplicado ao trait
    // `Introspector` per ADR-0073 (paridade vanilla literal). Falham
    // de compilação se o atributo for removido ou se bounds Send+Sync
    // forem perdidos.

    #[test]
    fn p204b_trait_e_send_sync() {
        // Sentinel: confirma que o trait Introspector é Send+Sync
        // (per ADR-0073 / P204B). Falha de compilação se bounds
        // forem removidos do trait declaration.
        fn assert_send_sync<T: Send + Sync + ?Sized>() {}
        assert_send_sync::<dyn Introspector>();
    }

    #[test]
    fn p204b_dyn_trait_implementa_track() {
        // Sentinel: confirma que `dyn Introspector + 'static`
        // implementa `comemo::Track` (gerado pelo macro
        // `#[comemo::track]`). Falha de compilação se atributo
        // for removido.
        fn assert_track<T: comemo::Track + ?Sized>() {}
        assert_track::<dyn Introspector>();
    }

    #[test]
    fn p204b_tagintrospector_pode_ser_tracked_via_dyn() {
        // Sentinel: confirma que TagIntrospector concreto pode ser
        // usado via &dyn Introspector e o handle .track() é
        // produzido via macro-generated impl. `comemo::Track` é
        // implementado para `dyn Introspector + '__comemo_dynamic`,
        // não para o tipo concreto — coerção e .track() devem
        // funcionar.
        use comemo::Track;
        let intr = TagIntrospector::empty();
        let dyn_ref: &dyn Introspector = &intr;
        // .track() produz Tracked<'_, dyn Introspector + '_>.
        let _tracked = dyn_ref.track();
    }

    #[test]
    fn populado_responde_correctamente() {
        let mut i = TagIntrospector::empty();
        i.labels.add(lbl("intro"), loc(7));
        i.counters.apply(ck("heading"), CounterUpdate::step());
        i.kind_index.entry(ElementKind::Heading).or_default().push(loc(7));
        i.kind_index.entry(ElementKind::Heading).or_default().push(loc(13));

        // 2 headings → query_by_kind retorna 2 em ordem.
        assert_eq!(i.query_by_kind(ElementKind::Heading), vec![loc(7), loc(13)]);
        // query_first → primeira.
        assert_eq!(i.query_first(ElementKind::Heading), Some(loc(7)));
        // query_unique → None porque há 2.
        assert_eq!(i.query_unique(ElementKind::Heading), None);
        // query_by_label.
        assert_eq!(i.query_by_label(&lbl("intro")), Some(loc(7)));
        // P205C: position_of devolve None quando `positions` não foi
        // injectado (default empty `SealedPositions`). Comportamento
        // P204D §C6a preservado para introspectors pré-layout.
        assert_eq!(i.position_of(loc(7)), None);
    }

    #[test]
    fn unique_devolve_some_quando_so_existe_um() {
        let mut i = TagIntrospector::empty();
        i.kind_index.entry(ElementKind::Figure).or_default().push(loc(99));
        assert_eq!(i.query_unique(ElementKind::Figure), Some(loc(99)));
        assert_eq!(i.query_first(ElementKind::Figure), Some(loc(99)));
    }

    #[test]
    fn kinds_distintos_isolados() {
        let mut i = TagIntrospector::empty();
        i.kind_index.entry(ElementKind::Heading).or_default().push(loc(1));
        i.kind_index.entry(ElementKind::Citation).or_default().push(loc(2));

        assert_eq!(i.query_by_kind(ElementKind::Heading), vec![loc(1)]);
        assert_eq!(i.query_by_kind(ElementKind::Citation), vec![loc(2)]);
        assert_eq!(i.query_by_kind(ElementKind::Figure), Vec::<Location>::new());
    }

    // ── P175 (M9 sub-passo 5) — query via Selector ──────────────────────

    #[test]
    fn query_vazio_devolve_vec_vazio() {
        let i = TagIntrospector::empty();
        let result = i.query(&Selector::Kind(ElementKind::Heading));
        assert_eq!(result, Vec::<Location>::new());
    }

    #[test]
    fn query_kind_devolve_locations_em_ordem() {
        let mut i = TagIntrospector::empty();
        i.kind_index.entry(ElementKind::Heading).or_default().push(loc(7));
        i.kind_index.entry(ElementKind::Heading).or_default().push(loc(13));
        i.kind_index.entry(ElementKind::Heading).or_default().push(loc(20));
        let result = i.query(&Selector::Kind(ElementKind::Heading));
        assert_eq!(result, vec![loc(7), loc(13), loc(20)]);
    }

    #[test]
    fn query_kind_isola_por_kind() {
        let mut i = TagIntrospector::empty();
        i.kind_index.entry(ElementKind::Heading).or_default().push(loc(1));
        i.kind_index.entry(ElementKind::Figure).or_default().push(loc(2));
        i.kind_index.entry(ElementKind::Citation).or_default().push(loc(3));
        assert_eq!(i.query(&Selector::Kind(ElementKind::Heading)), vec![loc(1)]);
        assert_eq!(i.query(&Selector::Kind(ElementKind::Figure)), vec![loc(2)]);
        assert_eq!(i.query(&Selector::Kind(ElementKind::Citation)), vec![loc(3)]);
        // Outros kinds → vazio.
        assert!(i.query(&Selector::Kind(ElementKind::Metadata)).is_empty());
    }

    // ── P177 (M9 sub-passo 7) — formatted_counter_at ────────────────────

    #[test]
    fn formatted_counter_at_em_introspector_vazio_devolve_none() {
        let i = TagIntrospector::empty();
        assert_eq!(i.formatted_counter_at(&ck("heading"), loc(10)), None);
    }

    #[test]
    fn formatted_counter_at_devolve_snapshot_correcto() {
        let mut i = TagIntrospector::empty();
        // Simular sequência [1, 2, 1] em headings via apply_hierarchical_at.
        i.counters.apply_hierarchical_at(ck("heading"), 1, loc(10)); // [1]
        i.counters.apply_hierarchical_at(ck("heading"), 2, loc(20)); // [1, 1]
        i.counters.apply_hierarchical_at(ck("heading"), 1, loc(30)); // [2]

        assert_eq!(i.formatted_counter_at(&ck("heading"), loc(10)).as_deref(), Some("1"));
        assert_eq!(
            i.formatted_counter_at(&ck("heading"), loc(20)).as_deref(),
            Some("1.1")
        );
        assert_eq!(i.formatted_counter_at(&ck("heading"), loc(30)).as_deref(), Some("2"));
        // Antes de qualquer update.
        assert_eq!(i.formatted_counter_at(&ck("heading"), loc(5)), None);
    }

    #[test]
    fn formatted_counter_at_key_inexistente_devolve_none() {
        let mut i = TagIntrospector::empty();
        i.counters.apply_hierarchical_at(ck("heading"), 1, loc(10));
        assert_eq!(i.formatted_counter_at(&ck("inexistente"), loc(20)), None);
    }

    // ── P181B — sub-store BibStore field ────────────────────────────────

    #[test]
    fn empty_inicializa_bib_store_vazio() {
        let i = TagIntrospector::empty();
        assert!(i.bib_store.is_empty());
        assert!(i.bib_store.entries().is_empty());
        assert_eq!(i.bib_store.entry_for_key("any"), None);
        assert_eq!(i.bib_store.number_for_key("any"), None);
    }

    // ── P181F — trait métodos bib_entry_for_key + bib_number_for_key ────

    #[test]
    fn bib_entry_for_key_em_introspector_vazio_devolve_none() {
        let i = TagIntrospector::empty();
        assert_eq!(i.bib_entry_for_key("any"), None);
    }

    #[test]
    fn bib_number_for_key_em_introspector_vazio_devolve_none() {
        let i = TagIntrospector::empty();
        assert_eq!(i.bib_number_for_key("any"), None);
    }

    #[test]
    fn bib_methods_resolvem_apos_populacao_directa_do_sub_store() {
        // Popula directamente via sub-store (sem chamar from_tags
        // — esse caminho é coberto em from_tags::tests P181E).
        // Verifica que os trait methods delegam correctamente.
        let mut i = TagIntrospector::empty();
        i.bib_store
            .add_bibliography(vec![crate::entities::bib_entry::BibEntry {
                key: "intro".to_string(),
                author: String::new(),
                title: String::new(),
                year: 0,
                volume: None,
                pages: None,
                journal: None,
                publisher: None,
                url: None,
                doi: None,
                editor: None,
                series: None,
                note: None,
                isbn: None,
                location: None,
                organization: None,
            }]);
        i.bib_store.assign_number("intro".to_string(), 1);

        assert!(i.bib_entry_for_key("intro").is_some());
        assert_eq!(i.bib_entry_for_key("intro").unwrap().key, "intro");
        assert_eq!(i.bib_number_for_key("intro"), Some(1));
        assert_eq!(i.bib_entry_for_key("nao_existe"), None);
        assert_eq!(i.bib_number_for_key("nao_existe"), None);
    }

    // ── P184C — figure_number_at_index ──────────────────────────────

    #[test]
    fn figure_number_at_index_em_introspector_vazio_devolve_none() {
        let i = TagIntrospector::empty();
        assert_eq!(i.figure_number_at_index("image", 0), None);
        assert_eq!(i.figure_number_at_index("table", 0), None);
    }

    #[test]
    fn figure_number_at_index_apos_populate_devolve_some() {
        // Replica directamente o que arm Figure faz em `from_tags`
        // (P184B): apply_at("figure:{kind}", Step, loc).
        let mut i = TagIntrospector::empty();
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(10));
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(20));
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(30));
        assert_eq!(i.figure_number_at_index("image", 0), Some(1));
        assert_eq!(i.figure_number_at_index("image", 1), Some(2));
        assert_eq!(i.figure_number_at_index("image", 2), Some(3));
    }

    #[test]
    fn figure_number_at_index_kinds_distintos_isolados() {
        let mut i = TagIntrospector::empty();
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(10));
        i.counters
            .apply_at(ck("figure:table"), CounterUpdate::step(), loc(20));
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(30));
        // image: 2 figures (idx 0, 1); table: 1 figure (idx 0).
        assert_eq!(i.figure_number_at_index("image", 0), Some(1));
        assert_eq!(i.figure_number_at_index("image", 1), Some(2));
        assert_eq!(i.figure_number_at_index("table", 0), Some(1));
        assert_eq!(i.figure_number_at_index("table", 1), None);
    }

    #[test]
    fn figure_number_at_index_idx_fora_de_range_devolve_none() {
        let mut i = TagIntrospector::empty();
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(10));
        // 1 figure populada; idx 1+ é fora de range.
        assert_eq!(i.figure_number_at_index("image", 0), Some(1));
        assert_eq!(i.figure_number_at_index("image", 1), None);
        assert_eq!(i.figure_number_at_index("image", 100), None);
    }

    #[test]
    fn figure_number_at_index_default_kind_image() {
        // Replica path do arm Figure quando `kind: None`: chave fica
        // "figure:image". Caller (Layouter) resolve `None` → "image"
        // antes de chamar; trait method não vê `Option`.
        let mut i = TagIntrospector::empty();
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(10));
        assert_eq!(i.figure_number_at_index("image", 0), Some(1));
    }

    // ── P185B — flat_counter_at ────────────────────────────────────

    #[test]
    fn flat_counter_at_em_introspector_vazio_devolve_none() {
        let i = TagIntrospector::empty();
        assert_eq!(i.flat_counter_at(&ck("figure:image"), loc(0)), None);
        assert_eq!(i.flat_counter_at(&ck("equation"), loc(100)), None);
    }

    #[test]
    fn flat_counter_at_apos_populate_devolve_some_em_loc_posterior() {
        let mut i = TagIntrospector::empty();
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(10));
        assert_eq!(i.flat_counter_at(&ck("figure:image"), loc(15)), Some(1));
        // Em loc(10) (mesma location) também.
        assert_eq!(i.flat_counter_at(&ck("figure:image"), loc(10)), Some(1));
    }

    #[test]
    fn flat_counter_at_re_update_reflecte_location_consultada() {
        // Caso central: valida snapshot por Location.
        let mut i = TagIntrospector::empty();
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(10));
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(20));
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(30));
        assert_eq!(i.flat_counter_at(&ck("figure:image"), loc(15)), Some(1));
        assert_eq!(i.flat_counter_at(&ck("figure:image"), loc(25)), Some(2));
        assert_eq!(i.flat_counter_at(&ck("figure:image"), loc(35)), Some(3));
    }

    #[test]
    fn flat_counter_at_keys_distintas_isoladas() {
        let mut i = TagIntrospector::empty();
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(10));
        i.counters
            .apply_at(ck("figure:table"), CounterUpdate::step(), loc(20));
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(30));
        // image: 2 steps em loc(10) e loc(30).
        assert_eq!(i.flat_counter_at(&ck("figure:image"), loc(15)), Some(1));
        assert_eq!(i.flat_counter_at(&ck("figure:image"), loc(35)), Some(2));
        // table: 1 step em loc(20); ausente em loc(15).
        assert_eq!(i.flat_counter_at(&ck("figure:table"), loc(15)), None);
        assert_eq!(i.flat_counter_at(&ck("figure:table"), loc(25)), Some(1));
    }

    #[test]
    fn flat_counter_at_location_anterior_a_qualquer_apply_devolve_none() {
        let mut i = TagIntrospector::empty();
        i.counters
            .apply_at(ck("figure:image"), CounterUpdate::step(), loc(10));
        // Snapshot vazio para Location anterior à primeira apply_at.
        assert_eq!(i.flat_counter_at(&ck("figure:image"), loc(5)), None);
    }

    // ── P193B — resolved_label_for ──────────────────────────────────────

    #[test]
    fn resolved_label_for_em_introspector_vazio_devolve_none() {
        let i = TagIntrospector::empty();
        assert_eq!(i.resolved_label_for(&lbl("foo")), None);
    }

    #[test]
    fn resolved_label_for_apos_populate_devolve_some() {
        // Populate manual via field directo (P193B abre infra; arm
        // de populate em from_tags vem em P195).
        let mut i = TagIntrospector::empty();
        i.resolved_labels.insert(lbl("intro"), "Secção 1".to_string());
        i.resolved_labels.insert(lbl("metodos"), "Secção 2".to_string());

        // Trait method delega correctamente.
        assert_eq!(i.resolved_label_for(&lbl("intro")), Some("Secção 1"));
        assert_eq!(i.resolved_label_for(&lbl("metodos")), Some("Secção 2"));
        assert_eq!(i.resolved_label_for(&lbl("ausente")), None);
    }

    // ── P205C (F3) — position_of impl real via SealedPositions ──────

    fn pos(page_nz: usize, x: f64, y: f64) -> crate::entities::position::Position {
        use crate::entities::layout_types::{Point, Pt};
        use std::num::NonZeroUsize;
        crate::entities::position::Position {
            page: NonZeroUsize::new(page_nz).unwrap(),
            point: Point { x: Pt(x), y: Pt(y) },
        }
    }

    #[test]
    fn p205c_position_of_pre_injecao_devolve_none() {
        // Sentinel: introspector default tem `positions` vazio
        // (`SealedPositions::empty`); position_of devolve None.
        // Comportamento P204D §C6a preservado pre-injecção.
        let i = TagIntrospector::empty();
        assert_eq!(i.position_of(loc(1)), None);
        assert_eq!(i.position_of(loc(99)), None);
    }

    #[test]
    fn p205c_inject_positions_activa_lookup_real() {
        use crate::entities::sealed_positions::SealedPositions;
        use std::collections::HashMap;

        let mut runtime_positions = HashMap::new();
        runtime_positions.insert(loc(7), pos(1, 10.0, 20.0));
        runtime_positions.insert(loc(13), pos(2, 30.0, 40.0));

        let mut i = TagIntrospector::empty();
        // Pre-injecção: vazio.
        assert_eq!(i.position_of(loc(7)), None);

        // Injecta SealedPositions (simula caller pós-layout).
        i.inject_positions(SealedPositions::from_runtime(runtime_positions));

        // Pós-injecção: lookup real.
        assert_eq!(i.position_of(loc(7)), Some(pos(1, 10.0, 20.0)));
        assert_eq!(i.position_of(loc(13)), Some(pos(2, 30.0, 40.0)));
        assert_eq!(i.position_of(loc(99)), None); // location ausente
    }

    #[test]
    fn p205c_inject_positions_e_idempotente_para_reinjecao() {
        // Re-injecção sobrescreve (caller pós-layout pode injectar
        // resultados de iterações sucessivas do fixpoint).
        use crate::entities::sealed_positions::SealedPositions;
        use std::collections::HashMap;

        let mut i = TagIntrospector::empty();

        let mut first = HashMap::new();
        first.insert(loc(1), pos(1, 0.0, 0.0));
        i.inject_positions(SealedPositions::from_runtime(first));
        assert_eq!(i.position_of(loc(1)), Some(pos(1, 0.0, 0.0)));

        // Segunda injecção (iteração fixpoint subsequente) sobrescreve.
        let mut second = HashMap::new();
        second.insert(loc(1), pos(2, 50.0, 60.0));
        i.inject_positions(SealedPositions::from_runtime(second));
        assert_eq!(i.position_of(loc(1)), Some(pos(2, 50.0, 60.0)));
    }

    // ── P207B (M9c) — query_labelled ────────────────────────────────

    #[test]
    fn p207b_query_labelled_em_introspector_vazio_devolve_vec_vazio() {
        let i = TagIntrospector::empty();
        assert_eq!(i.query_labelled(), Vec::<(Label, Location)>::new());
    }

    #[test]
    fn p207b_query_labelled_um_label() {
        let mut i = TagIntrospector::empty();
        i.labels.add(lbl("intro"), loc(7));
        assert_eq!(i.query_labelled(), vec![(lbl("intro"), loc(7))]);
    }

    #[test]
    fn p207b_query_labelled_multiplos_ordenados_alfabeticamente() {
        // Inserção em ordem arbitrária; output ordenado por Label
        // garante determinismo independente do `HashMap::iter`
        // interno (per ADR-0076 C1 — query_labelled determinístico).
        let mut i = TagIntrospector::empty();
        i.labels.add(lbl("gamma"), loc(30));
        i.labels.add(lbl("alpha"), loc(10));
        i.labels.add(lbl("beta"), loc(20));
        assert_eq!(
            i.query_labelled(),
            vec![
                (lbl("alpha"), loc(10)),
                (lbl("beta"), loc(20)),
                (lbl("gamma"), loc(30)),
            ]
        );
    }

    // ── P207C (M9c) — label_count via trait ─────────────────────────

    // ── P207D (M9c) — Page-aware trait methods ──────────────────────

    #[test]
    fn p207d_pages_pre_injecao_devolve_none() {
        let i = TagIntrospector::empty();
        assert_eq!(i.pages(loc(1)), None);
        assert_eq!(i.pages(loc(99)), None);
    }

    #[test]
    fn p207d_pages_pos_injecao_devolve_total() {
        use crate::entities::page_store::PageStore;
        use std::num::NonZeroUsize;
        let mut i = TagIntrospector::empty();
        i.inject_pages(PageStore::from_total_pages(NonZeroUsize::new(7).unwrap()));
        // Paridade vanilla: pages() ignora location.
        assert_eq!(i.pages(loc(1)), Some(NonZeroUsize::new(7).unwrap()));
        assert_eq!(i.pages(loc(999)), Some(NonZeroUsize::new(7).unwrap()));
    }

    #[test]
    fn p207d_page_pre_injecao_devolve_none() {
        let i = TagIntrospector::empty();
        // Sem positions injectado, page() devolve None.
        assert_eq!(i.page(loc(1)), None);
    }

    #[test]
    fn p207d_page_pos_injecao_positions_devolve_some() {
        use crate::entities::sealed_positions::SealedPositions;
        use std::collections::HashMap;
        let mut i = TagIntrospector::empty();
        let mut runtime = HashMap::new();
        runtime.insert(loc(7), pos(3, 0.0, 0.0)); // page 3
        runtime.insert(loc(13), pos(5, 10.0, 20.0)); // page 5
        i.inject_positions(SealedPositions::from_runtime(runtime));
        // page() devolve o componente page da Position.
        assert_eq!(i.page(loc(7)).map(|n| n.get()), Some(3));
        assert_eq!(i.page(loc(13)).map(|n| n.get()), Some(5));
        // Location ausente: None.
        assert_eq!(i.page(loc(99)), None);
    }

    #[test]
    fn p207d_page_numbering_pre_injecao_devolve_none() {
        let i = TagIntrospector::empty();
        assert_eq!(i.page_numbering(loc(1)), None);
    }

    #[test]
    fn p207d_page_numbering_pos_injecao_devolve_some() {
        use crate::entities::page_store::PageStore;
        use crate::entities::sealed_positions::SealedPositions;
        use std::collections::HashMap;
        use std::num::NonZeroUsize;
        let mut i = TagIntrospector::empty();

        // Injectar positions: loc 7 → page 1; loc 13 → page 2.
        let mut runtime = HashMap::new();
        runtime.insert(loc(7), pos(1, 0.0, 0.0));
        runtime.insert(loc(13), pos(2, 0.0, 0.0));
        i.inject_positions(SealedPositions::from_runtime(runtime));

        // Injectar page_store completo: 2 páginas com numbering.
        let store = PageStore::from_runtime(
            NonZeroUsize::new(2).unwrap(),
            vec![
                Some(crate::entities::numbering::Numbering::Pattern(EcoString::from(
                    "1",
                ))),
                Some(crate::entities::numbering::Numbering::Pattern(EcoString::from(
                    "I",
                ))),
            ],
            vec![
                crate::entities::content::Content::Empty,
                crate::entities::content::Content::Empty,
            ],
        );
        i.inject_pages(store);

        assert_eq!(i.page_numbering(loc(7)).map(|s| s.as_str()), Some("1"),);
        assert_eq!(i.page_numbering(loc(13)).map(|s| s.as_str()), Some("I"),);
        // Location sem position: None.
        assert_eq!(i.page_numbering(loc(99)), None);
    }

    #[test]
    fn p207d_page_supplement_pre_injecao_devolve_none() {
        let i = TagIntrospector::empty();
        assert_eq!(i.page_supplement(loc(1)).is_none(), true);
    }

    #[test]
    fn p207d_page_supplement_pos_injecao_devolve_some() {
        use crate::entities::page_store::PageStore;
        use crate::entities::sealed_positions::SealedPositions;
        use std::collections::HashMap;
        use std::num::NonZeroUsize;
        let mut i = TagIntrospector::empty();

        let mut runtime = HashMap::new();
        runtime.insert(loc(7), pos(1, 0.0, 0.0));
        i.inject_positions(SealedPositions::from_runtime(runtime));

        let store = PageStore::from_runtime(
            NonZeroUsize::new(1).unwrap(),
            vec![None],
            vec![crate::entities::content::Content::Empty],
        );
        i.inject_pages(store);

        // Supplement existe (Content::Empty).
        assert!(i.page_supplement(loc(7)).is_some());
    }

    #[test]
    fn p207d_page_methods_e2e_pattern() {
        // E2E: introspector vazio → inject positions + pages → 4
        // métodos resolvem coerentemente.
        use crate::entities::page_store::PageStore;
        use crate::entities::sealed_positions::SealedPositions;
        use std::collections::HashMap;
        use std::num::NonZeroUsize;

        let mut i = TagIntrospector::empty();
        // Pre-tudo: 4 retornam None.
        assert_eq!(i.pages(loc(1)), None);
        assert_eq!(i.page(loc(1)), None);
        assert_eq!(i.page_numbering(loc(1)), None);
        assert!(i.page_supplement(loc(1)).is_none());

        // Inject positions: page 2 para loc(5).
        let mut runtime = HashMap::new();
        runtime.insert(loc(5), pos(2, 0.0, 0.0));
        i.inject_positions(SealedPositions::from_runtime(runtime));

        // Inject pages com numbering "II" e supplement Empty.
        i.inject_pages(PageStore::from_runtime(
            NonZeroUsize::new(3).unwrap(),
            vec![
                None,
                Some(crate::entities::numbering::Numbering::Pattern(EcoString::from(
                    "II",
                ))),
                None,
            ],
            vec![
                crate::entities::content::Content::Empty,
                crate::entities::content::Content::Empty,
                crate::entities::content::Content::Empty,
            ],
        ));

        // Pós-injecção: tudo resolve.
        assert_eq!(i.pages(loc(5)).map(|n| n.get()), Some(3));
        assert_eq!(i.page(loc(5)).map(|n| n.get()), Some(2));
        assert_eq!(i.page_numbering(loc(5)).map(|s| s.as_str()), Some("II"),);
        assert!(i.page_supplement(loc(5)).is_some());
    }

    #[test]
    fn p207c_introspector_label_count_via_trait() {
        // Empty: 0 para qualquer label.
        let mut i = TagIntrospector::empty();
        assert_eq!(i.label_count(&lbl("ausente")), 0);

        // Single insertion: 1.
        i.labels.add(lbl("unica"), loc(1));
        assert_eq!(i.label_count(&lbl("unica")), 1);

        // Triple insertion para mesmo label (multi-label P207C).
        i.labels.add(lbl("multi"), loc(10));
        i.labels.add(lbl("multi"), loc(11));
        i.labels.add(lbl("multi"), loc(12));
        assert_eq!(i.label_count(&lbl("multi")), 3);

        // Outros labels permanecem em 0.
        assert_eq!(i.label_count(&lbl("ausente")), 0);

        // Consistência com query_labelled: total de pares com label
        // = soma de label_count para todos os labels únicos.
        let total = i.query_labelled().len();
        assert_eq!(total, i.label_count(&lbl("unica")) + i.label_count(&lbl("multi")));
    }

    // ── P472 — back_refs_for_key / figures_for_lof / tables_for_lot ──────

    #[test]
    fn back_refs_for_key_vazio_em_introspector_vazio() {
        let i = TagIntrospector::empty();
        assert!(i.back_refs_for_key("x").is_empty());
    }

    #[test]
    fn back_refs_via_introspector_delega_a_bib_store() {
        use crate::entities::bib_store::BibStore;
        let mut i = TagIntrospector::empty();
        i.bib_store.record_citation("key1".to_string());
        i.bib_store.record_citation("key2".to_string());
        i.bib_store.record_citation("key1".to_string());
        let refs1 = i.back_refs_for_key("key1");
        assert_eq!(refs1, vec![1, 3]);
        let refs2 = i.back_refs_for_key("key2");
        assert_eq!(refs2, vec![2]);
    }

    #[test]
    fn figures_for_lof_vazio_em_introspector_vazio() {
        let i = TagIntrospector::empty();
        assert!(i.figures_for_lof().is_empty());
    }

    #[test]
    fn tables_for_lot_vazio_em_introspector_vazio() {
        let i = TagIntrospector::empty();
        assert!(i.tables_for_lot().is_empty());
    }

    #[test]
    fn figures_for_lof_populado_directamente() {
        let mut i = TagIntrospector::empty();
        i.figures_for_lof.push((1, "Diagrama 1".to_string()));
        i.figures_for_lof.push((2, "Mapa".to_string()));
        let lof = i.figures_for_lof();
        assert_eq!(lof.len(), 2);
        assert_eq!(lof[0], (1, "Diagrama 1".to_string()));
        assert_eq!(lof[1], (2, "Mapa".to_string()));
    }
}

#[cfg(test)]
mod p1493_tests {
    use super::*;
    use crate::entities::layout_types::{Point, Pt};
    use crate::entities::position::HtmlPosition;
    use std::collections::HashMap;

    #[test]
    fn p1493_injecao_html_substitui_geracao_sem_tocar_posicao_paginada() {
        let first = Location::from_raw(1493);
        let stale = Location::from_raw(1494);
        let expected = HtmlPosition { point: Point { x: Pt(30.0), y: Pt(20.0) } };
        let mut intr = TagIntrospector::empty();

        assert_eq!(intr.html_position_of(first), None);
        intr.inject_html_positions(HashMap::from([
            (first, expected),
            (stale, HtmlPosition { point: Point { x: Pt(1.0), y: Pt(2.0) } }),
        ]));
        assert_eq!(intr.html_position_of(first), Some(expected));
        assert_eq!(intr.position_of(first), None);

        intr.inject_html_positions(HashMap::from([(
            first,
            HtmlPosition { point: Point { x: Pt(40.0), y: Pt(25.0) } },
        )]));
        assert_eq!(intr.html_position_of(stale), None);
        assert_eq!(
            intr.html_position_of(first),
            Some(HtmlPosition { point: Point { x: Pt(40.0), y: Pt(25.0) } })
        );
    }
}
