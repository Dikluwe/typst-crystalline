#!/usr/bin/env python3
"""Controlled fresh-process font lifecycle comparison; original baseline stays immutable."""
import argparse, hashlib, json, os, pathlib, resource, shutil, subprocess, threading, time
import run as c
OUT = pathlib.Path(__file__).resolve().parent
original_files = c.source_files

def inputs():
    files = set(original_files())
    files.update(OUT / name for name in ['experiment.py', 'protocol.md', 'seal_owned.py'])
    files.update(c.ROOT / name for name in json.loads((OUT/'initial.json').read_text())['originals'] if name.endswith('.md'))
    return sorted(files)
c.source_files = inputs


def variants():
    return json.loads((OUT/'variants.json').read_text())

def identities():
    for name, row in variants().items():
        assert c.sha(row['path']) == row['sha256'], name+' executable changed'
    assert c.sha(c.ROOT/'lab/typst-original/target/release/typst') == c.VANILLA_SHA


def build(name):
    receipt = c.monitored(['cargo','build','--release','--offline','--locked','-p','typst-wiring','--message-format=json'], 'build-'+name, affinity=False)
    messages = []
    for line in (OUT/'logs'/('build-'+name+'.log')).read_text().splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if row.get('reason') == 'compiler-artifact' and row.get('executable') and row['target']['name']=='typst':
            messages.append(row)
    row = messages[-1]
    assert row['profile']['opt_level']=='3' and not row['profile']['debug_assertions']
    path=OUT/'bin'/(name+'-typst'); shutil.copy2(row['executable'],path)
    values=variants(); values[name]={'path':str(path),'sha256':c.sha(path),'profile':row['profile'],'source_before':receipt['fingerprint_before'],'source_after':receipt['fingerprint_after'],'command':receipt['command']}
    c.save(pathlib.Path('variants.json'), values)
    source = c.snapshot(name+'-built')
    c.save(pathlib.Path('build-state.json'), source)
    archive=OUT/'state'/(name+'-sources.tar.gz')
    import tarfile
    with tarfile.open(archive,'w:gz') as t:
        for p in c.source_files():
            if p.is_relative_to(c.ROOT): t.add(p,arcname=str(p.relative_to(c.ROOT)))
    print(name,'release executable archived',flush=True)


def one(name, fixture, directory, label, traced=False, limit=False):
    values=variants(); exe=str(c.ROOT/'lab/typst-original/target/release/typst') if name=='vanilla' else values[name]['path']
    pdf=directory/(label+'.pdf'); trace=directory/(label+'.json')
    cmd=[exe,'compile',str(fixture),str(pdf),'--root',str(fixture.parent),'--pdf-tagged=false','--pretty=false','--font-path',str(OUT/'fonts')]
    if name=='vanilla': cmd+=['--jobs','1']
    if traced: cmd+=['--timings' if name=='vanilla' else '--timings-json',str(trace)]
    def setup():
        os.sched_setaffinity(0,{c.CPU})
        if limit: resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
    with open(directory/(label+'.stdout'),'wb') as stdout,open(directory/(label+'.stderr'),'wb') as stderr:
        started=c.utc(); clock=time.perf_counter_ns()
        proc=subprocess.Popen(cmd,cwd=c.ROOT,env=c.ENV,stdout=stdout,stderr=stderr,preexec_fn=setup)
        _,status,usage=os.wait4(proc.pid,0); proc.returncode=os.waitstatus_to_exitcode(status)
        wall=(time.perf_counter_ns()-clock)/1e6
    row={'variant':name,'fixture':fixture.stem,'label':label,'utc_start':started,'utc_end':c.utc(),'command':cmd,'wall_ms':wall,'user_ms':usage.ru_utime*1000,'system_ms':usage.ru_stime*1000,'maxrss_kib':usage.ru_maxrss,'exit_code':proc.returncode,'executable_sha256':c.sha(exe),'fixture_sha256':c.sha(fixture),'output':str(pdf.relative_to(OUT)),'instrumented':traced,'rlimit_as_bytes':512*1024*1024 if limit else None}
    if pdf.exists():row['output_sha256']=c.sha(pdf)
    return row


def block(round_number, fixture, traced):
    mode='traced' if traced else 'plain'; label=f'{mode}-r{round_number}-{fixture.stem}'
    directory=OUT/'samples'/label
    if directory.exists():
        receipt_path=OUT/'receipts'/(label+'.json')
        old=json.loads(receipt_path.read_text()) if receipt_path.exists() else {}
        expected=json.loads((OUT/'build-state.json').read_text())
        if old.get('valid') and old.get('before')==expected['sha256'] and old.get('after')==expected['sha256'] and old.get('head')==expected['head']:
            identities();print(label,'retained',flush=True);return
        dest=OUT/'rejected'/(label+'-'+str(time.time_ns()));dest.parent.mkdir(exist_ok=True);shutil.move(directory,dest)
    directory.mkdir(parents=True)
    identities();before=c.snapshot(label+'-before');c.require_built_state(before)
    stop=threading.Event();contamination=[]
    def monitor():
        while not stop.wait(.1):
            hit=c.blockers(c.processes(),None)
            if hit:contamination.append({'utc':c.utc(),'processes':hit})
    worker=threading.Thread(target=monitor);worker.start(); rows=[];warmups=[]
    names=['before','lazy','interval','vanilla']
    try:
        for name in names:
            for warm in range(2):warmups.append(one(name,fixture,directory,f'warm-{name}-{warm}',traced))
        for iteration in range(6 if traced else 12):
            shift=(iteration+round_number)%len(names);order=names[shift:]+names[:shift]
            if iteration%2:order=list(reversed(order))
            for name in order:
                row=one(name,fixture,directory,f'{iteration:02}-{name}',traced);row.update(round=round_number,iteration=iteration,order=order);rows.append(row)
    finally:
        stop.set();worker.join()
    after=c.snapshot(label+'-after');identities()
    stable=(before['sha256'],before['head'])==(after['sha256'],after['head'])
    valid=stable and not contamination and all(row['exit_code']==0 for row in rows+warmups)
    c.save(pathlib.Path('samples')/label/'samples.json',{'warmups':warmups,'samples':rows})
    c.save(pathlib.Path('receipts')/(label+'.json'),{'valid':valid,'before':before['sha256'],'after':after['sha256'],'head':before['head'],'contamination':contamination,'round':round_number,'fixture':fixture.name,'instrumented':traced})
    print(label,'VALID' if valid else 'DISCARDED',flush=True)
    if not valid:raise RuntimeError('Rejected complete block '+label)


def measure(traced):
    identities()
    for round_number in range(1,4):
        c.quiet()
        for fixture in sorted((OUT/'fixtures').glob('*.typ')):
            if fixture.stem.startswith('memory-'):continue
            block(round_number,fixture,traced)


def memory():
    directory=OUT/'memory';directory.mkdir(exist_ok=True);rows=[]
    for fixture in sorted((OUT/'fixtures').glob('memory-*.typ')):
        for name in ['before','lazy','interval','vanilla']:
            rows.append(one(name,fixture,directory,fixture.stem+'-'+name,limit=True))
    c.save(pathlib.Path('memory-results.json'),{'note':'Functional/memory validation, not admitted timing samples; address-space limit is the unchanged P1410 512 MiB. wait4 RSS has the parent floor limitation.','rows':rows})
    assert all(row['exit_code']==0 for row in rows), 'memory probe failed'
    print('P1410 probes passed under 512 MiB',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['build','plain','traced','memory']);parser.add_argument('--name');args=parser.parse_args()
    if args.action=='build':build(args.name)
    elif args.action=='memory':memory()
    else:measure(args.action=='traced')
