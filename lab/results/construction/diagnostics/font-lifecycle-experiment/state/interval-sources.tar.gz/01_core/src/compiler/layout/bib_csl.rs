//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/compiler/layout/bib_csl.md
//! @prompt-hash f4e35111
//! @layer L1
//! @updated 2026-06-23
//!
//! **P418** — Integração hayagriva/citationberg para renderização CSL de
//! `BibliographyElem` e `CiteElem`. Responsabilidades:
//! - Converter `BibEntry` (subset cristalino) para `hayagriva::Entry` via YAML
//!   intermédio, reaproveitando o parser do hayagriva.
//! - Resolver CSL style: built-ins via `hayagriva::archive::ArchivedStyle`.
//! - Pré-renderizar citações (4 forms) e bibliografia num `BibRenderCache`.
//! - Converter `ElemChildren` hayagriva para `Content` cristalino (Strong/Emph/
//!   Link/Linebreak).
//!
//! **P420** — ficheiros `.csl` customizados via path (resolvidos em eval e
//! aplicados aqui através de `IndependentStyle`).
//! Scope-out: múltiplas bibliografias, locales via ficheiro externo,
//! formatação vertical (superscript/subscript) sem Content variant correspondente.

use std::collections::HashMap;

use crate::entities::source_result::{SourceDiagnostic, SourceResult};
use crate::entities::span::Span;
use hayagriva::archive::ArchivedStyle;
use hayagriva::citationberg;
use hayagriva::citationberg::{Display, IndependentStyle, Locale};
use hayagriva::{
    BibliographyDriver, CitationItem, CitationRequest, CitePurpose, ElemChild,
    ElemChildren, Entry, Formatted, Formatting,
};

use crate::entities::bib_entry::BibEntry;
use crate::entities::citation_form::CitationForm;
use crate::entities::content::Content;

/// Cache pré-renderizado para um par style/locale.
#[derive(Debug, Clone)]
pub struct BibRenderCache {
    /// Citações pré-renderizadas por form e por key bibliográfica.
    pub citations: HashMap<CitationForm, HashMap<String, Content>>,
    /// Bibliografia pré-renderizada (se o style a definir).
    pub bibliography: Option<Content>,
}

/// Style CSL default quando o documento não especifica outro.
const DEFAULT_STYLE: &str = "ieee";

/// Constrói o cache de renderização para as entries e style indicados.
///
/// - `style`: nome built-in (ex: `"ieee"`, `"apa"`, `"chicago-author-date"`).
///   Se `None`, usa `DEFAULT_STYLE`.
/// - `locale`: locale override (ex: `"en-US"`, `"pt-PT"`). Se `None`, usa o
///   locale default do style.
///
/// Retorna `None` se o style não for resolvido ou se houver falha irrecuperável
/// na conversão das entries.
pub fn build_cache(
    entries: &[BibEntry],
    style: Option<&str>,
    locale: Option<&str>,
    citation_order: Option<&[String]>,
) -> SourceResult<BibRenderCache> {
    let style_name = style.unwrap_or(DEFAULT_STYLE);
    let independent = resolve_style_name(style_name).ok_or_else(|| {
        vec![SourceDiagnostic::error(
            Span::detached(),
            format!("unknown bibliography style '{}'", style_name),
        )]
    })?;
    build_cache_with_style(entries, &independent, locale, citation_order)
}

/// Constrói o cache a partir de um `IndependentStyle` já resolvido (P420).
///
/// Usado pelo layout quando `BibliographyElem.resolved_style` foi preenchido
/// em eval time (built-in ou custom `.csl`).
///
/// **P533** — `citation_order` reordena as entries antes de renderizar a
/// bibliografia, garantindo que estilos numéricos (ex: `ieee`) listam as
/// referências pela ordem de primeira citação no documento.
pub fn build_cache_with_style(
    entries: &[BibEntry],
    independent: &IndependentStyle,
    locale: Option<&str>,
    citation_order: Option<&[String]>,
) -> SourceResult<BibRenderCache> {
    let locales = build_locales(locale);

    // **P547** — só reordenar por citation_order em estilos numéricos (ex: IEEE).
    // Estilos autor-data (APA, Chicago, MLA) ordenam alfabeticamente pelo CSL.
    let numeric = is_numeric_style(independent);
    let mut ordered_entries: Vec<BibEntry> = entries.to_vec();
    if numeric {
        if let Some(order) = citation_order {
            ordered_entries.sort_by_key(|e| {
                order.iter().position(|k| k == &e.key).unwrap_or(usize::MAX)
            });
        }
    }

    let hay_entries: Vec<Entry> = ordered_entries
        .iter()
        .map(bib_entry_to_hayagriva)
        .collect::<Result<Vec<_>, _>>()?;
    if hay_entries.is_empty() {
        return Ok(BibRenderCache { citations: HashMap::new(), bibliography: None });
    }

    let mut citations: HashMap<CitationForm, HashMap<String, Content>> = HashMap::new();

    for form in [
        CitationForm::Normal,
        CitationForm::Prose,
        CitationForm::Author,
        CitationForm::Year,
    ] {
        let purpose = form_to_purpose(form);
        let mut driver = BibliographyDriver::new();
        for entry in &hay_entries {
            let mut item = CitationItem::with_entry(entry);
            item.purpose = purpose;
            driver.citation(CitationRequest::from_items(
                vec![item],
                independent,
                &locales,
            ));
        }
        let rendered = driver.finish(hayagriva::BibliographyRequest::new(
            independent,
            None,
            &locales,
        ));
        let mut map = HashMap::new();
        for (i, entry) in hay_entries.iter().enumerate() {
            if let Some(cite) = rendered.citations.get(i) {
                map.insert(
                    entry.key().to_string(),
                    elem_children_to_content(&cite.citation),
                );
            }
        }
        citations.insert(form, map);
    }

    // Bibliografia: usa um driver novo com purpose None para obter o layout
    // de referências completo.
    let mut driver = BibliographyDriver::new();
    for entry in &hay_entries {
        driver.citation(CitationRequest::from_items(
            vec![CitationItem::with_entry(entry)],
            independent,
            &locales,
        ));
    }
    let rendered =
        driver.finish(hayagriva::BibliographyRequest::new(independent, None, &locales));
    let bibliography = rendered.bibliography.as_ref().map(render_bibliography);

    Ok(BibRenderCache { citations, bibliography })
}

/// Resolve um style built-in pelo nome. Aceita styles do hayagriva archive.
pub fn resolve_style_name(name: &str) -> Option<IndependentStyle> {
    let archived = ArchivedStyle::by_name(name)?;
    match archived.get() {
        hayagriva::citationberg::Style::Independent(s) => Some(s),
        _ => None,
    }
}

/// Parseia conteúdo XML CSL em memória (P420).
///
/// A leitura do disco é responsabilidade do caller (eval/bibliography.rs via
/// `World::read_bytes`); este helper expõe apenas o parsing para os consumers
/// de layout e para tests unitários sem I/O.
pub fn parse_csl_style(content: &str) -> Result<IndependentStyle, String> {
    IndependentStyle::from_xml(content)
        .map_err(|e| format!("failed to parse CSL style: {:?}", e))
}

/// Devolve `true` se o style CSL declarar formato de citação numérico.
fn is_numeric_style(independent: &IndependentStyle) -> bool {
    independent.info.category.iter().any(|cat| {
        matches!(
            cat,
            citationberg::StyleCategory::CitationFormat {
                format: citationberg::CitationFormat::Numeric,
            }
        )
    })
}

/// Constrói o slice de locales a passar ao hayagriva.
fn build_locales(locale: Option<&str>) -> Vec<Locale> {
    let all = hayagriva::archive::locales();
    match locale {
        Some(l) => all
            .into_iter()
            .filter(|loc| loc.lang.as_ref().map(|c| c.0.as_str() == l).unwrap_or(false))
            .collect(),
        None => all,
    }
}

/// Mapeia `CitationForm` cristalino para `Option<CitePurpose>` hayagriva.
fn form_to_purpose(form: CitationForm) -> Option<CitePurpose> {
    match form {
        CitationForm::Normal => None,
        CitationForm::Prose => Some(CitePurpose::Prose),
        CitationForm::Author => Some(CitePurpose::Author),
        CitationForm::Year => Some(CitePurpose::Year),
    }
}

/// Reduz runs BibTeX de dois ou mais hífens ao separador ASCII consumido pelo
/// parser de page ranges do hayagriva, sem tocar nos demais caracteres.
fn normalize_bibtex_page_range(pages: &str) -> String {
    let mut normalized = String::with_capacity(pages.len());
    let mut chars = pages.chars().peekable();

    while let Some(ch) = chars.next() {
        normalized.push(ch);
        if ch == '-' {
            while chars.next_if_eq(&'-').is_some() {}
        }
    }

    normalized
}

/// Converte um `BibEntry` cristalino num `hayagriva::Entry` gerando YAML
/// intermédio e aproveitando o parser do hayagriva.
fn bib_entry_to_hayagriva(entry: &BibEntry) -> SourceResult<Entry> {
    // P644: chave vazia é erro antes de gerar YAML.
    if entry.key.is_empty() {
        return Err(vec![SourceDiagnostic::error(
            Span::detached(),
            "bibliography contains entry with empty key".to_string(),
        )]);
    }

    let mut yaml = String::new();
    yaml.push_str(&format!("{}:\n", sanitize_yaml_key(&entry.key)));

    // Heurística simples de tipo: journal presente → Article; senão Book.
    let entry_type = if entry.journal.is_some() { "Article" } else { "Book" };
    yaml.push_str(&format!("  type: {entry_type}\n"));
    yaml.push_str(&format!("  title: {}\n", escape_yaml_scalar(&entry.title)));

    // **P547** — o campo author cristalino usa "Last, First and Last2, First2".
    // Hayagriva interpreta uma string única como uma única pessoa; enviar como
    // lista YAML permite separação correcta dos autores.
    let authors: Vec<&str> = entry
        .author
        .split(" and ")
        .map(|s| s.trim())
        .filter(|s| !s.is_empty())
        .collect();
    if authors.is_empty() {
        yaml.push_str("  author: \"\"\n");
    } else if authors.len() == 1 {
        yaml.push_str(&format!("  author: {}\n", escape_yaml_scalar(authors[0])));
    } else {
        yaml.push_str("  author:\n");
        for a in authors {
            yaml.push_str(&format!("    - {}\n", escape_yaml_scalar(a)));
        }
    }

    yaml.push_str(&format!("  date: {}\n", entry.year));

    if let Some(v) = &entry.volume {
        yaml.push_str(&format!("  volume: {}\n", escape_yaml_scalar(v)));
    }
    if let Some(p) = &entry.pages {
        // **P1456** — reconhecer o run inteiro evita o hífen residual que
        // `str::replace` deixava em sequências ímpares com três ou mais.
        let normalized = normalize_bibtex_page_range(p);
        yaml.push_str(&format!("  page-range: {}\n", escape_yaml_scalar(&normalized)));
    }
    if let Some(j) = &entry.journal {
        yaml.push_str("  parent:\n");
        yaml.push_str(&format!("    title: {}\n", escape_yaml_scalar(j)));
    }
    if let Some(p) = &entry.publisher {
        yaml.push_str(&format!("  publisher: {}\n", escape_yaml_scalar(p)));
    }
    if let Some(u) = &entry.url {
        yaml.push_str(&format!("  url: {}\n", escape_yaml_scalar(u)));
    }
    if let Some(d) = &entry.doi {
        yaml.push_str(&format!("  doi: {}\n", escape_yaml_scalar(d)));
    }
    if let Some(e) = &entry.editor {
        yaml.push_str(&format!("  editor: {}\n", escape_yaml_scalar(e)));
    }
    if let Some(s) = &entry.series {
        yaml.push_str(&format!("  series: {}\n", escape_yaml_scalar(s)));
    }
    if let Some(n) = &entry.note {
        yaml.push_str(&format!("  note: {}\n", escape_yaml_scalar(n)));
    }
    if let Some(i) = &entry.isbn {
        yaml.push_str(&format!("  isbn: {}\n", escape_yaml_scalar(i)));
    }
    if let Some(l) = &entry.location {
        yaml.push_str(&format!("  location: {}\n", escape_yaml_scalar(l)));
    }
    if let Some(o) = &entry.organization {
        yaml.push_str(&format!("  organization: {}\n", escape_yaml_scalar(o)));
    }

    let library = hayagriva::io::from_yaml_str(&yaml).map_err(|e| {
        vec![SourceDiagnostic::error(
            Span::detached(),
            format!("failed to parse bibliography entry '{}': {}", entry.key, e),
        )]
    })?;

    library.get(&entry.key).cloned().ok_or_else(|| {
        vec![SourceDiagnostic::error(
            Span::detached(),
            format!("bibliography entry '{}' missing after YAML conversion", entry.key),
        )]
    })
}

/// Serializa texto como string JSON, que também é um escalar double-quoted
/// válido em YAML. Assim o parser nunca infere bool, null ou número a partir
/// de um campo textual e o próprio serializer cobre escapes e Unicode.
fn escape_yaml_scalar(s: &str) -> String {
    serde_json::to_string(s).expect("serializing a string to JSON cannot fail")
}

/// Sanitiza a chave do mapa YAML (key da entry). Se necessário, envolve em aspas.
fn sanitize_yaml_key(s: &str) -> String {
    escape_yaml_scalar(s)
}

/// Renderiza uma `RenderedBibliography` hayagriva num `Content` cristalino.
fn render_bibliography(bib: &hayagriva::RenderedBibliography) -> Content {
    let mut items = Vec::with_capacity(bib.items.len());
    for item in &bib.items {
        let mut line_parts = Vec::new();
        if let Some(first) = &item.first_field {
            line_parts.push(elem_child_to_content(first));
            line_parts.push(Content::text(" "));
        }
        line_parts.push(elem_children_to_content(&item.content));
        items.push(Content::sequence(line_parts));
        items.push(Content::linebreak());
    }
    Content::sequence(items)
}

/// Converte `ElemChildren` hayagriva num único `Content` (Sequence se >1).
fn elem_children_to_content(children: &ElemChildren) -> Content {
    if children.0.len() == 1 {
        elem_child_to_content(&children.0[0])
    } else {
        Content::sequence(children.0.iter().map(elem_child_to_content).collect())
    }
}

/// Converte um `ElemChild` hayagriva para `Content`.
fn elem_child_to_content(child: &ElemChild) -> Content {
    match child {
        ElemChild::Text(t) => formatted_to_content(t),
        ElemChild::Elem(e) => {
            let inner = elem_children_to_content(&e.children);
            match e.display {
                Some(Display::Block)
                | Some(Display::Indent)
                | Some(Display::LeftMargin) => {
                    Content::sequence(vec![inner, Content::linebreak()])
                }
                _ => inner,
            }
        }
        ElemChild::Markup(m) => Content::text(m.as_str()),
        ElemChild::Link { text, url } => {
            Content::link(url.as_str(), formatted_to_content(text))
        }
        ElemChild::Transparent { .. } => Content::Empty,
    }
}

/// Converte texto formatado hayagriva para `Content`, aplicando Strong/Emph/etc.
fn formatted_to_content(f: &Formatted) -> Content {
    apply_formatting(Content::text(f.text.as_str()), f.formatting)
}

/// Aplica formatação CSL sobre um `Content` de texto.
fn apply_formatting(content: Content, formatting: Formatting) -> Content {
    use hayagriva::citationberg::{FontStyle, FontVariant, FontWeight, TextDecoration};

    let mut c = content;
    if formatting.font_weight == FontWeight::Bold {
        c = Content::strong(c);
    }
    if formatting.font_style == FontStyle::Italic {
        c = Content::emph(c);
    }
    if formatting.font_variant == FontVariant::SmallCaps {
        c = Content::smallcaps(c);
    }
    if formatting.text_decoration == TextDecoration::Underline {
        c = Content::underline(c, None, None, None);
    }
    // VerticalAlign (superscript/subscript) não tem Content variant em P418.
    c
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::entities::bib_entry::BibEntry;

    fn sample_entries() -> Vec<BibEntry> {
        vec![
            BibEntry::new("k1", "Doe, John", "A Crystal Paper", 2024)
                .with_journal("Journal of Examples")
                .with_volume("7")
                .with_pages("1-10"),
            BibEntry::new("k2", "Smith, Jane", "Another Book", 2023)
                .with_publisher("Example Press"),
        ]
    }

    #[test]
    fn build_cache_ieee_produz_citacoes_e_bibliografia() {
        let cache = build_cache(&sample_entries(), Some("ieee"), None, None).unwrap();
        assert!(cache.bibliography.is_some());
        let normal = cache.citations.get(&CitationForm::Normal).unwrap();
        assert!(normal.contains_key("k1"));
        assert!(normal.contains_key("k2"));
    }

    #[test]
    fn build_cache_ieee_reordena_por_citation_order() {
        let cache = build_cache(
            &sample_entries(),
            Some("ieee"),
            None,
            Some(&["k2".to_string(), "k1".to_string()]),
        )
        .unwrap();
        let bib = cache.bibliography.unwrap().plain_text();
        let crystal_pos = bib.find("Crystal Paper").unwrap_or(usize::MAX);
        let another_pos = bib.find("Another Book").unwrap_or(usize::MAX);
        assert!(
            another_pos < crystal_pos,
            "bibliografia deve listar k2 (Another Book) antes de k1 (Crystal Paper): {bib}"
        );
    }

    #[test]
    fn build_cache_apa_produz_citacoes_author_year() {
        let cache = build_cache(&sample_entries(), Some("apa"), None, None).unwrap();
        let author = cache.citations.get(&CitationForm::Author).unwrap();
        let year = cache.citations.get(&CitationForm::Year).unwrap();
        let k1_author = author.get("k1").unwrap().plain_text();
        let k1_year = year.get("k1").unwrap().plain_text();
        assert!(k1_author.contains("Doe"), "author: {k1_author}");
        assert!(k1_year.contains("2024"), "year: {k1_year}");
    }

    #[test]
    fn build_cache_style_inexistente_retorna_none() {
        assert!(
            build_cache(&sample_entries(), Some("not-a-real-style"), None, None).is_err()
        );
    }

    #[test]
    fn build_cache_entries_vazias_produz_cache_vazio() {
        let cache = build_cache(&[], Some("ieee"), None, None).unwrap();
        assert!(cache.citations.is_empty());
        assert!(cache.bibliography.is_none());
    }

    #[test]
    fn elem_children_plain_text_preserva_texto() {
        let mut children = ElemChildren::default();
        children.0.push(ElemChild::Text(Formatted {
            text: "hello".into(),
            formatting: Formatting::default(),
        }));
        assert_eq!(elem_children_to_content(&children).plain_text(), "hello");
    }

    #[test]
    fn formatted_italic_vai_para_emph() {
        use hayagriva::citationberg::FontStyle;
        let mut formatting = Formatting::default();
        formatting.font_style = FontStyle::Italic;
        let c = apply_formatting(Content::text("italico"), formatting);
        assert!(matches!(c, Content::Emph(_)));
        assert_eq!(c.plain_text(), "italico");
    }

    #[test]
    fn build_cache_locale_pt_br_nao_quebra() {
        let cache =
            build_cache(&sample_entries(), Some("ieee"), Some("pt-BR"), None).unwrap();
        assert!(cache.bibliography.is_some());
        let normal = cache.citations.get(&CitationForm::Normal).unwrap();
        assert!(normal.contains_key("k1"));
    }

    #[test]
    fn build_cache_locale_inexistente_usa_locales_disponiveis() {
        // Locale inexistente: slice vazio; hayagriva recai no locale do style.
        let cache =
            build_cache(&sample_entries(), Some("ieee"), Some("xx-XX"), None).unwrap();
        assert!(cache.bibliography.is_some());
    }

    #[test]
    fn build_cache_chicago_author_date_resolve() {
        let cache =
            build_cache(&sample_entries(), Some("chicago-author-date"), None, None)
                .unwrap();
        assert!(cache.bibliography.is_some());
        let prose = cache.citations.get(&CitationForm::Prose).unwrap();
        let txt = prose.get("k1").unwrap().plain_text();
        assert!(txt.contains("Doe") || txt.contains("2024"), "prose: {txt}");
    }

    #[test]
    fn citation_normal_ieee_brackets() {
        let cache = build_cache(&sample_entries(), Some("ieee"), None, None).unwrap();
        let normal = cache.citations.get(&CitationForm::Normal).unwrap();
        let txt = normal.get("k1").unwrap().plain_text();
        assert!(txt.starts_with('[') && txt.ends_with(']'), "ieee normal: {txt}");
    }

    #[test]
    fn citation_prose_apa_contem_author_e_year() {
        let cache = build_cache(&sample_entries(), Some("apa"), None, None).unwrap();
        let prose = cache.citations.get(&CitationForm::Prose).unwrap();
        let txt = prose.get("k1").unwrap().plain_text();
        assert!(txt.contains("Doe"), "prose author: {txt}");
        assert!(txt.contains("2024"), "prose year: {txt}");
    }

    #[test]
    fn citation_author_apa_is_author_only() {
        let cache = build_cache(&sample_entries(), Some("apa"), None, None).unwrap();
        let author = cache.citations.get(&CitationForm::Author).unwrap();
        let txt = author.get("k1").unwrap().plain_text();
        assert!(txt.contains("Doe"), "author: {txt}");
    }

    #[test]
    fn citation_year_apa_is_year_only() {
        let cache = build_cache(&sample_entries(), Some("apa"), None, None).unwrap();
        let year = cache.citations.get(&CitationForm::Year).unwrap();
        let txt = year.get("k1").unwrap().plain_text();
        assert!(txt.contains("2024"), "year: {txt}");
    }

    #[test]
    fn bibliography_ieee_contains_numbers() {
        let cache = build_cache(&sample_entries(), Some("ieee"), None, None).unwrap();
        let txt = cache.bibliography.unwrap().plain_text();
        assert!(txt.contains("[1]"), "bib: {txt}");
        assert!(txt.contains("[2]"), "bib: {txt}");
    }

    #[test]
    fn bibliography_apa_contains_author_title_year() {
        let cache = build_cache(&sample_entries(), Some("apa"), None, None).unwrap();
        let txt = cache.bibliography.unwrap().plain_text();
        assert!(txt.contains("Doe"), "apa bib author: {txt}");
        assert!(txt.contains("Crystal Paper"), "apa bib title: {txt}");
        assert!(txt.contains("2024"), "apa bib year: {txt}");
    }

    #[test]
    fn elem_children_with_emph_and_strong() {
        use hayagriva::citationberg::{FontStyle, FontWeight};
        let mut children = ElemChildren::default();
        children.0.push(ElemChild::Text(Formatted {
            text: "bold ".into(),
            formatting: Formatting {
                font_weight: FontWeight::Bold,
                ..Formatting::default()
            },
        }));
        children.0.push(ElemChild::Text(Formatted {
            text: "italic".into(),
            formatting: Formatting {
                font_style: FontStyle::Italic,
                ..Formatting::default()
            },
        }));
        let c = elem_children_to_content(&children);
        assert!(c.plain_text().contains("bold italic"));
    }

    #[test]
    fn elem_child_link_preserves_url_and_text() {
        let child = ElemChild::Link {
            text: Formatted {
                text: "click".into(),
                formatting: Formatting::default(),
            },
            url: "https://example.com".into(),
        };
        let c = elem_child_to_content(&child);
        assert_eq!(c.plain_text(), "click");
        assert!(matches!(c, Content::Link(_)));
    }

    #[test]
    fn formatted_strong_vai_para_strong() {
        use hayagriva::citationberg::FontWeight;
        let mut formatting = Formatting::default();
        formatting.font_weight = FontWeight::Bold;
        let c = apply_formatting(Content::text("negrito"), formatting);
        assert!(matches!(c, Content::Strong(_)));
    }

    #[test]
    fn formatted_smallcaps_vai_para_smallcaps() {
        use hayagriva::citationberg::FontVariant;
        let mut formatting = Formatting::default();
        formatting.font_variant = FontVariant::SmallCaps;
        let c = apply_formatting(Content::text("smallcaps"), formatting);
        assert!(matches!(c, Content::SmallCaps { .. }));
    }

    #[test]
    fn formatted_underline_vai_para_underline() {
        use hayagriva::citationberg::TextDecoration;
        let mut formatting = Formatting::default();
        formatting.text_decoration = TextDecoration::Underline;
        let c = apply_formatting(Content::text("sublinhado"), formatting);
        assert!(matches!(c, Content::Underline(_)));
    }

    #[test]
    fn escape_yaml_scalar_quotas_com_colon() {
        let s = escape_yaml_scalar("New York: ACM");
        assert!(s.starts_with('"') && s.ends_with('"'));
    }

    #[test]
    fn escape_yaml_scalar_numerico_e_quotado() {
        let s = escape_yaml_scalar("2024");
        assert!(s.starts_with('"') && s.ends_with('"'));
    }

    #[test]
    fn bib_entry_to_hayagriva_converte_key_e_title() {
        let entry = BibEntry::new("mykey", "Author, A.", "The Title", 2022);
        let h = bib_entry_to_hayagriva(&entry).unwrap();
        assert_eq!(h.key(), "mykey");
        assert_eq!(h.title().unwrap().value.to_str(), "The Title");
    }

    #[test]
    fn bib_entry_to_hayagriva_article_tem_journal_parent() {
        let entry = BibEntry::new("art", "Author, A.", "Title", 2022)
            .with_journal("J of Examples");
        let h = bib_entry_to_hayagriva(&entry).unwrap();
        assert!(!h.parents().is_empty());
    }

    #[test]
    fn p1457_escalares_textuais_usam_serializacao_total() {
        for (input, expected) in [
            ("", "\"\""),
            ("plain text", "\"plain text\""),
            ("True", "\"True\""),
            ("NULL", "\"NULL\""),
            (".nan", "\".nan\""),
            ("? value", "\"? value\""),
            ("say \"hi\"", "\"say \\\"hi\\\"\""),
            ("C:\\fonts", "\"C:\\\\fonts\""),
            ("line\nbreak", "\"line\\nbreak\""),
            ("a\tb", "\"a\\tb\""),
            ("pré–pós", "\"pré–pós\""),
        ] {
            assert_eq!(escape_yaml_scalar(input), expected, "input {input:?}");
        }
    }

    #[test]
    fn p1457_title_com_spelling_yaml_tipado_permanece_texto() {
        let entry = BibEntry::new("typed", "Author, A.", "True", 2024);
        let h = bib_entry_to_hayagriva(&entry).unwrap();
        assert_eq!(h.title().unwrap().value.to_str(), "True");
    }

    #[test]
    fn p1456_page_range_run_triplo_normaliza_como_unidade() {
        let entry =
            BibEntry::new("range", "Author, A.", "Title", 2022).with_pages("45---67");
        let h = bib_entry_to_hayagriva(&entry).unwrap();
        assert_eq!(h.page_range().unwrap().to_string(), "45-67");
    }

    #[test]
    fn p1456_normalizacao_preserva_fronteiras_e_unicode() {
        for (input, expected) in [
            ("", ""),
            ("45", "45"),
            ("45-67", "45-67"),
            ("45--67", "45-67"),
            ("45---67", "45-67"),
            ("45----67", "45-67"),
            ("S12--S14", "S12-S14"),
            ("1--3, 7--9", "1-3, 7-9"),
            ("pré--pós", "pré-pós"),
            ("alpha beta", "alpha beta"),
        ] {
            assert_eq!(normalize_bibtex_page_range(input), expected, "input {input:?}");
        }
    }

    // ── P420 — CSL customizado via path ───────────────────────────────────────

    fn p420_custom_csl() -> &'static str {
        r#"<?xml version="1.0" encoding="UTF-8"?>
<style xmlns="http://purl.org/net/xbiblio/csl" version="1.0" class="in-text" default-locale="en-US">
  <info>
    <title>Custom</title>
    <id>http://example.org/custom</id>
  </info>
  <citation>
    <layout><text variable="title"/></layout>
  </citation>
  <bibliography>
    <layout><text variable="title"/></layout>
  </bibliography>
</style>"#
    }

    #[test]
    fn p420_resolve_style_name_ieee_ok() {
        let style = resolve_style_name("ieee");
        assert!(style.is_some(), "ieee deve resolver");
    }

    #[test]
    fn p420_resolve_style_name_inexistente_none() {
        assert!(resolve_style_name("not-a-real-style").is_none());
    }

    #[test]
    fn p420_parse_csl_style_valido() {
        let style = parse_csl_style(p420_custom_csl());
        assert!(style.is_ok(), "{:?}", style);
        assert_eq!(style.unwrap().info.title.value, "Custom");
    }

    #[test]
    fn p420_parse_csl_style_xml_malformado() {
        let err = parse_csl_style("<style>").unwrap_err();
        assert!(err.contains("failed to parse CSL style"), "{err}");
    }

    #[test]
    fn p420_build_cache_with_style_custom_aplica_titulo() {
        let style = parse_csl_style(p420_custom_csl()).unwrap();
        let entries = vec![BibEntry::new("k1", "Author, A.", "The Title", 2024)];
        let cache = build_cache_with_style(&entries, &style, None, None).unwrap();
        let bib = cache.bibliography.unwrap().plain_text();
        assert!(bib.contains("The Title"), "bib: {bib}");
    }

    // ── P644 — erros em bib_entry_to_hayagriva ────────────────────────────────

    #[test]
    fn p644_bib_entry_to_hayagriva_chave_vazia_produz_erro() {
        let entry = BibEntry::new(
            "".to_string(),
            "Autor".to_string(),
            "Título".to_string(),
            2024,
        );
        let err = bib_entry_to_hayagriva(&entry).unwrap_err();
        assert!(
            err[0].message.contains("bibliography contains entry with empty key"),
            "{}",
            err[0].message
        );
    }

    #[test]
    fn p1457_bib_entry_controle_escapado_preserva_texto() {
        // P1457 substitui o YAML internamente inválido usado como sentinela em
        // P644: U+0000 agora é escapado pelo serializer e volta como texto.
        let entry = BibEntry::new(
            "key".to_string(),
            "Autor".to_string(),
            "Título\u{0000}inválido".to_string(),
            2024,
        );
        let converted = bib_entry_to_hayagriva(&entry).unwrap();
        assert_eq!(converted.title().unwrap().value.to_str(), "Título\0inválido");
    }
}
