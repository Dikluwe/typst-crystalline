//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/compiler/math/layout/attach.md
//! @prompt-hash 21756944
//! @layer L1
//! @updated 2026-08-20
//!
//! Método `layout_attach` de `MathLayouter`. Extraído de `math/layout/mod.rs`
//! no Passo 96.8 conforme ADR-0037. Suporta 6 anexos concomitantes: t, b, tl, bl, tr, br.

use crate::compiler::layout::FontMetrics;
use crate::entities::{
    content::Content,
    elements::math_attach::MathAttachSlot,
    layout_types::{FrameItem, MathSize, Pt, TextStyle},
};

use super::symbols;
use super::{offset_item, MathBox};

#[derive(Debug, Clone, PartialEq, Eq)]
struct PrimesRecipe {
    glyphs: Vec<char>,
    half_width_extent: usize,
    half_width_offsets: Vec<usize>,
}

fn primes_recipe(count: usize) -> PrimesRecipe {
    match count {
        1 => PrimesRecipe {
            glyphs: vec!['′'],
            half_width_extent: 2,
            half_width_offsets: vec![0],
        },
        2 => PrimesRecipe {
            glyphs: vec!['″'],
            half_width_extent: 2,
            half_width_offsets: vec![0],
        },
        3 => PrimesRecipe {
            glyphs: vec!['‴'],
            half_width_extent: 2,
            half_width_offsets: vec![0],
        },
        4 => PrimesRecipe {
            glyphs: vec!['⁗'],
            half_width_extent: 2,
            half_width_offsets: vec![0],
        },
        count => PrimesRecipe {
            glyphs: vec!['′'; count],
            half_width_extent: count + 1,
            half_width_offsets: (0..count).collect(),
        },
    }
}

#[cfg(test)]
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct P1444PrimesRecipe {
    pub glyphs: Vec<char>,
    pub half_width_extent: usize,
    pub half_width_offsets: Vec<usize>,
}

#[cfg(test)]
pub(crate) fn p1444_primes_recipe(count: usize) -> P1444PrimesRecipe {
    let recipe = primes_recipe(count);
    P1444PrimesRecipe {
        glyphs: recipe.glyphs,
        half_width_extent: recipe.half_width_extent,
        half_width_offsets: recipe.half_width_offsets,
    }
}

impl<'a, M: FontMetrics> super::MathLayouter<'a, M> {
    pub(super) fn layout_primes(
        &self,
        elem: &crate::entities::elements::math_attach::MathPrimesElem,
        style: &TextStyle,
    ) -> MathBox {
        let recipe = primes_recipe(elem.count);
        if recipe.glyphs.len() == 1 && recipe.half_width_extent == 2 {
            return self.layout_text_node(&recipe.glyphs[0].to_string().into(), style);
        }

        let prime = self.layout_text_node(&"′".into(), style);
        let half = prime.width / 2.0;
        let mut items = Vec::with_capacity(prime.items.len() * recipe.glyphs.len());
        for half_offset in recipe.half_width_offsets {
            items.extend(
                prime.items.iter().cloned().map(|item| {
                    offset_item(item, Pt(half * half_offset as f64), Pt(0.0))
                }),
            );
        }
        MathBox {
            width: half * recipe.half_width_extent as f64,
            ascent: prime.ascent,
            descent: prime.descent,
            items,
        }
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn layout_attach_slots(
        &self,
        base: &Content,
        t: &MathAttachSlot,
        b: &MathAttachSlot,
        tl: &MathAttachSlot,
        bl: &MathAttachSlot,
        tr: &MathAttachSlot,
        br: &MathAttachSlot,
        style: &TextStyle,
    ) -> MathBox {
        fn present(slot: &MathAttachSlot) -> Option<&Content> {
            match slot {
                MathAttachSlot::Present(content) => Some(content),
                MathAttachSlot::Omitted | MathAttachSlot::ExplicitNone => None,
            }
        }

        self.layout_attach(
            base,
            present(t),
            present(b),
            present(tl),
            present(bl),
            present(tr),
            present(br),
            style,
        )
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn layout_attach(
        &self,
        base: &Content,
        t: Option<&Content>,
        b: Option<&Content>,
        tl: Option<&Content>,
        bl: Option<&Content>,
        tr: Option<&Content>,
        br: Option<&Content>,
        style: &TextStyle,
    ) -> MathBox {
        let base_box = self.layout_node(base, style);

        let (script_math_size, factor) = match style.math_size {
            MathSize::Display | MathSize::Text => {
                (MathSize::Script, self.constants.script_percent_scale_down)
            }
            MathSize::Script => (
                MathSize::ScriptScript,
                self.constants.script_script_percent_scale_down
                    / self.constants.script_percent_scale_down,
            ),
            MathSize::ScriptScript => (MathSize::ScriptScript, 1.0),
        };
        let top_style = TextStyle {
            size: style.size * factor,
            math_script: true,
            math_size: script_math_size,
            ..style.clone()
        };
        let bottom_style = TextStyle { cramped: true, ..top_style.clone() };

        // **P992** — `Content::MathLimitsOverride` (`limits()`/`scripts()`)
        // é verificado ANTES do `self.block &&` exterior: `limits(body,
        // inline: true)` (default vanilla) empilha mesmo em modo inline —
        // diferente de `Content::MathOp { limits, .. }`, que continua
        // gated por `self.block` (ver nota P772w acima).
        let unwrapped_base = {
            let mut b = base;
            loop {
                match b {
                    Content::MathLimitsOverride(e) => b = &e.body,
                    Content::MathClassOverride(e) => b = &e.body,
                    Content::MathStyled(e) => b = &e.body,
                    Content::Styled(styled) => b = &styled.body,
                    _ => break,
                }
            }
            b
        };

        let is_limits = match base {
            Content::MathLimitsOverride(e) => e.limits && (e.inline || self.block),
            _ => {
                self.block
                    && match unwrapped_base {
                        Content::MathIdent(s) | Content::MathText(s) => {
                            let ch = s.chars().next().unwrap_or(' ');
                            (symbols::is_large_operator(ch)
                                && !symbols::is_integral_char(ch))
                                || symbols::is_limit_function(s.as_str())
                        }
                        Content::MathOp(e) => e.limits,
                        _ => false,
                    }
            }
        };

        // Resolução inteligente de t/b vs tr/br (paridade vanilla resolve_attach)
        let (t, tr) = if is_limits {
            if t.is_some() {
                (t, tr)
            } else {
                (tr, None)
            }
        } else if tr.is_some() {
            (t, tr)
        } else {
            (None, t)
        };

        let (b, br) = if is_limits {
            if b.is_some() {
                (b, br)
            } else {
                (br, None)
            }
        } else if br.is_some() {
            (b, br)
        } else {
            (None, b)
        };

        // Somente `Present` cria caixa. Em particular, markup vazio continua
        // presente e reserva `SpaceAfterScript`; `ExplicitNone` não o faz.
        let t_box = t.map(|c| self.layout_node(c, &top_style));
        let b_box = b.map(|c| self.layout_node(c, &bottom_style));
        let tl_box = tl.map(|c| self.layout_node(c, &top_style));
        let bl_box = bl.map(|c| self.layout_node(c, &bottom_style));
        let tr_box = tr.map(|c| self.layout_node(c, &top_style));
        let br_box = br.map(|c| self.layout_node(c, &bottom_style));

        // Extrair chars para consulta a MathGlyphKern
        let base_char: Option<char> = match unwrapped_base {
            Content::MathIdent(s) | Content::MathText(s) => s.chars().next(),
            Content::MathOp(e) => match &e.text {
                Content::Text(s) | Content::MathText(s) | Content::MathIdent(s) => {
                    if s == "sum" {
                        Some('∑')
                    } else if s == "product" {
                        Some('∏')
                    } else if s == "integral" {
                        Some('∫')
                    } else {
                        s.chars().next()
                    }
                }
                _ => None,
            },
            _ => None,
        };
        let extract_char = |c: Option<&Content>| -> Option<char> {
            match c {
                Some(Content::MathIdent(s)) | Some(Content::MathText(s)) => {
                    s.chars().next()
                }
                _ => None,
            }
        };
        let tl_char = extract_char(tl);
        let bl_char = extract_char(bl);
        let tr_char = extract_char(tr);
        let br_char = extract_char(br);

        let base_ascent = base_box.ascent;
        let base_descent = base_box.descent;
        let base_width = base_box.width;

        let is_op = match unwrapped_base {
            Content::MathOp(_) => true,
            Content::MathIdent(s) | Content::MathText(s) => s
                .chars()
                .next()
                .map(|ch| symbols::is_large_operator(ch) || symbols::is_integral_char(ch))
                .unwrap_or(false),
            _ => false,
        };
        // P1132d: no vanilla, `text_like` pertence ao tipo do fragmento.
        // Sequências/anexos/delimitados produzem FrameFragment (false), ainda
        // que não sejam operadores. Só os fragmentos textuais atómicos ficam
        // true; uma variante/assembly extensível (`Glyph`) força false.
        fn content_is_text_like(c: &Content) -> bool {
            match c {
                Content::MathIdent(_) | Content::MathText(_) | Content::MathOp(_) => true,
                Content::MathDelimited(e) => content_is_text_like(&e.body),
                Content::MathSequence(xs) | Content::Sequence(xs) => {
                    xs.iter().all(content_is_text_like)
                }
                Content::MathClassOverride(e) => content_is_text_like(&e.body),
                Content::MathLimitsOverride(e) => content_is_text_like(&e.body),
                Content::MathStyled(e) => content_is_text_like(&e.body),
                Content::Styled(styled) => content_is_text_like(&styled.body),
                // **P1133b** — espaçamento fraco de borda (`dif`) colapsa
                // antes do layout e não produz fragmento com `math_size`;
                // é neutro na agregação `all(fragment.is_text_like())`.
                Content::HSpace(e) if e.weak => true,
                _ => false,
            }
        }
        let has_extended_glyph = base_box.items.iter().any(|item| match item {
            FrameItem::Glyph { glyph_id, base_char, .. } => self
                .metrics
                .vertical_glyph_variants(*base_char, style)
                .variants
                .first()
                .map_or(true, |base| base.glyph_id != *glyph_id),
            _ => false,
        });
        // No vanilla, `extended_shape` é uma propriedade do glifo na fonte,
        // não apenas da variante escolhida. Operadores grandes continuam
        // não-text-like no inline mesmo usando o glifo base.
        let is_extended_shape_glyph = match unwrapped_base {
            Content::MathIdent(s) | Content::MathText(s) if s.chars().count() == 1 => {
                s.chars().next().is_some_and(symbols::is_large_operator)
            }
            _ => false,
        };
        let is_text_like = content_is_text_like(unwrapped_base)
            && !has_extended_glyph
            && !is_extended_shape_glyph;

        let glyph_ascent = self.metrics.text_edges(style.size, style).0.val().abs();
        let is_nested_attach = matches!(base, Content::MathAttach(_));
        let is_multi_letter_text_op = match unwrapped_base {
            Content::MathIdent(s) | Content::MathText(s) => s.chars().count() > 1,
            Content::MathOp(e) => match &e.text {
                Content::Text(s) | Content::MathText(s) | Content::MathIdent(s) => {
                    s.chars().count() > 1
                }
                _ => false,
            },
            _ => false,
        };
        let eff_base_ascent = if is_nested_attach && !is_op {
            base_ascent.min(glyph_ascent)
        } else {
            base_ascent
        };
        let eff_base_descent = if is_multi_letter_text_op || (is_nested_attach && !is_op)
        {
            0.0
        } else {
            base_descent
        };

        // Deslocamentos adaptativos de sub/sobrescrito (compute_script_shifts)
        let (shift_up, shift_down) = self.compute_script_shifts(
            eff_base_ascent,
            eff_base_descent,
            is_text_like,
            tl_box.as_ref(),
            tr_box.as_ref(),
            bl_box.as_ref(),
            br_box.as_ref(),
            style,
        );

        // Deslocamentos verticais de limites (compute_limit_shifts)
        let t_shift = t_box
            .as_ref()
            .map(|tb| {
                let upper_gap_min = self
                    .constants
                    .to_pt(self.constants.upper_limit_gap_min, style.size)
                    .val();
                let upper_rise_min = self
                    .constants
                    .to_pt(self.constants.upper_limit_baseline_rise_min, style.size)
                    .val();
                base_ascent + upper_rise_min.max(upper_gap_min + tb.descent)
            })
            .unwrap_or(0.0);

        let b_shift = b_box
            .as_ref()
            .map(|bb| {
                let lower_gap_min = self
                    .constants
                    .to_pt(self.constants.lower_limit_gap_min, style.size)
                    .val();
                let lower_drop_min = self
                    .constants
                    .to_pt(self.constants.lower_limit_baseline_drop_min, style.size)
                    .val();
                base_descent + lower_drop_min.max(lower_gap_min + bb.ascent)
            })
            .unwrap_or(0.0);

        let space_after_script = self
            .constants
            .to_pt(self.constants.space_after_script, style.size)
            .val();

        // Kerning dos 4 quadrantes
        let tl_kern = if let Some(ref tb) = tl_box {
            self.compute_math_kern(
                base_char,
                tl_char,
                0, // TopLeft
                base_ascent - shift_up,
                shift_up - tb.descent,
                style,
            )
        } else {
            0.0
        };

        let bl_kern = if let Some(ref bb) = bl_box {
            self.compute_math_kern(
                base_char,
                bl_char,
                1, // BottomLeft
                bb.ascent - shift_down,
                shift_down - base_descent,
                style,
            )
        } else {
            0.0
        };

        let tr_kern = if let Some(ref tb) = tr_box {
            self.compute_math_kern(
                base_char,
                tr_char,
                2, // TopRight
                base_ascent - shift_up,
                shift_up - tb.descent,
                style,
            )
        } else {
            0.0
        };

        let base_ic = if is_multi_letter_text_op {
            // **P1133c** — `MathOp("lim")` é FrameFragment no vanilla;
            // não herda a IC do `m` final para centrar limites.
            0.0
        } else {
            base_box
                .items
                .iter()
                .find_map(|i| match i {
                    FrameItem::Glyph { glyph_id, .. } => Some(
                        self.metrics
                            .italics_correction(*glyph_id, style.size, style)
                            .val(),
                    ),
                    FrameItem::TextShaped { glyphs, .. } => glyphs.last().map(|g| {
                        self.metrics
                            .italics_correction(g.glyph_id, style.size, style)
                            .val()
                    }),
                    FrameItem::Text { text, style: item_style, .. } => {
                        if item_style.math_text_item {
                            // P1293 — Content::Text directo é FrameFragment
                            // no modelo semântico math: a IC do fragmento é
                            // zero, ainda que o glifo tipográfico tenha IC.
                            Some(0.0)
                        } else {
                            text.chars().last().map(|c| {
                                self.metrics
                                    .char_italics_correction(c, style.size, style)
                                    .val()
                            })
                        }
                    }
                    _ => None,
                })
                .or_else(|| {
                    base_char.map(|c| {
                        self.metrics.char_italics_correction(c, style.size, style).val()
                    })
                })
                .unwrap_or(0.0)
        };
        let br_kern = if let Some(ref bb) = br_box {
            self.compute_math_kern(
                base_char,
                br_char,
                3, // BottomRight
                bb.ascent - shift_down,
                shift_down - base_descent,
                style,
            ) - base_ic
        } else {
            0.0
        };

        // Larguras de scripts
        let tl_pre = tl_box
            .as_ref()
            .map(|b| space_after_script + b.width + tl_kern)
            .unwrap_or(0.0);
        let bl_pre = bl_box
            .as_ref()
            .map(|b| space_after_script + b.width + bl_kern)
            .unwrap_or(0.0);

        let tr_post = tr_box
            .as_ref()
            .map(|b| space_after_script + b.width + tr_kern)
            .unwrap_or(0.0);
        let br_post = br_box
            .as_ref()
            .map(|b| space_after_script + b.width + br_kern)
            .unwrap_or(0.0);

        // Larguras de limits
        let delta = base_ic / 2.0;
        let (t_pre, t_post) = t_box
            .as_ref()
            .map(|tb| {
                let half = (tb.width - base_width) / 2.0;
                (half - delta, half + delta)
            })
            .unwrap_or((0.0, 0.0));

        let (b_pre, b_post) = b_box
            .as_ref()
            .map(|bb| {
                let half = (bb.width - base_width) / 2.0;
                (half + delta, half - delta)
            })
            .unwrap_or((0.0, 0.0));

        let pre_width = t_pre.max(b_pre).max(tl_pre).max(bl_pre).max(0.0);
        let post_width = t_post.max(b_post).max(tr_post).max(br_post).max(0.0);
        let total_width = pre_width + base_width + post_width;

        let mut ascent = base_ascent;
        let mut descent = base_descent;
        let mut items = Vec::new();

        // 1. Base
        for item in base_box.items {
            items.push(offset_item(item, Pt(pre_width), Pt(0.0)));
        }

        // 2. Pre-scripts
        if let Some(tb) = tl_box {
            ascent = ascent.max(shift_up + tb.ascent);
            let x_tl = pre_width - tl_pre + space_after_script;
            for item in tb.items {
                items.push(offset_item(item, Pt(x_tl), Pt(-shift_up)));
            }
        }

        if let Some(bb) = bl_box {
            descent = descent.max(shift_down + bb.descent);
            let x_bl = pre_width - bl_pre + space_after_script;
            for item in bb.items {
                items.push(offset_item(item, Pt(x_bl), Pt(shift_down)));
            }
        }

        // 3. Post-scripts
        if let Some(tb) = tr_box {
            ascent = ascent.max(shift_up + tb.ascent);
            let x_tr = pre_width + base_width + tr_kern;
            for item in tb.items {
                items.push(offset_item(item, Pt(x_tr), Pt(-shift_up)));
            }
        }

        if let Some(bb) = br_box {
            descent = descent.max(shift_down + bb.descent);
            let x_br = pre_width + base_width + br_kern;
            for item in bb.items {
                items.push(offset_item(item, Pt(x_br), Pt(shift_down)));
            }
        }

        // 4. Limits
        if let Some(tb) = t_box {
            ascent = ascent.max(t_shift + tb.ascent);
            let x_t = pre_width - t_pre;
            for item in tb.items {
                items.push(offset_item(item, Pt(x_t), Pt(-t_shift)));
            }
        }

        if let Some(bb) = b_box {
            descent = descent.max(b_shift + bb.descent);
            let x_b = pre_width - b_pre;
            for item in bb.items {
                items.push(offset_item(item, Pt(x_b), Pt(b_shift)));
            }
        }

        MathBox { width: total_width, ascent, descent, items }
    }

    /// P914 — Função auxiliar para calcular deslocamentos adaptativos de sub/sobrescritos.
    #[allow(clippy::too_many_arguments)]
    fn compute_script_shifts(
        &self,
        base_ascent: f64,
        base_descent: f64,
        is_text_like: bool,
        tl_box: Option<&MathBox>,
        tr_box: Option<&MathBox>,
        bl_box: Option<&MathBox>,
        br_box: Option<&MathBox>,
        style: &TextStyle,
    ) -> (f64, f64) {
        let size = style.size;

        let sup_shift_up_const = if style.cramped {
            self.constants.superscript_shift_up_cramped
        } else {
            self.constants.superscript_shift_up
        };
        let sup_shift_up = self.constants.to_pt(sup_shift_up_const, size).val();
        let sup_bottom_min = self
            .constants
            .to_pt(self.constants.superscript_bottom_min, size)
            .val();
        let sup_bottom_max_with_sub = self
            .constants
            .to_pt(self.constants.superscript_bottom_max_with_subscript, size)
            .val();
        let sup_drop_max = self
            .constants
            .to_pt(self.constants.superscript_baseline_drop_max, size)
            .val();
        let gap_min = self
            .constants
            .to_pt(self.constants.sub_superscript_gap_min, size)
            .val();
        let sub_shift_down =
            self.constants.to_pt(self.constants.subscript_shift_down, size).val();
        let sub_top_max =
            self.constants.to_pt(self.constants.subscript_top_max, size).val();
        let sub_drop_min = self
            .constants
            .to_pt(self.constants.subscript_baseline_drop_min, size)
            .val();

        let mut shift_up = 0.0_f64;
        let mut shift_down = 0.0_f64;

        if tl_box.is_some() || tr_box.is_some() {
            let drop_term =
                if is_text_like { 0.0 } else { (base_ascent - sup_drop_max).max(0.0) };
            let tl_descent = tl_box.map(|b| b.descent).unwrap_or(0.0);
            let tr_descent = tr_box.map(|b| b.descent).unwrap_or(0.0);
            shift_up = shift_up
                .max(sup_shift_up)
                .max(drop_term)
                .max(sup_bottom_min + tl_descent)
                .max(sup_bottom_min + tr_descent);
        }

        if bl_box.is_some() || br_box.is_some() {
            let drop_term =
                if is_text_like { 0.0 } else { (base_descent + sub_drop_min).max(0.0) };
            let bl_ascent = bl_box.map(|b| b.ascent).unwrap_or(0.0);
            let br_ascent = br_box.map(|b| b.ascent).unwrap_or(0.0);
            shift_down = shift_down
                .max(sub_shift_down)
                .max(drop_term)
                .max(bl_ascent - sub_top_max)
                .max(br_ascent - sub_top_max);
        }

        // Ajuste simultâneo para os pares de scripts (tl, bl) e (tr, br)
        for (sup, sub) in [(tl_box, bl_box), (tr_box, br_box)] {
            if let (Some(sup_b), Some(sub_b)) = (sup, sub) {
                let sup_bottom = shift_up - sup_b.descent;
                let sub_top = sup_b.descent - shift_down; // em coordenadas onde y cresce para baixo, sub_top é -shift_down + sub_b.ascent
                let gap = (shift_up + shift_down) - (sup_b.descent + sub_b.ascent);
                if gap < gap_min {
                    let increase = gap_min - gap;
                    let sup_only =
                        (sup_bottom_max_with_sub - sup_bottom).clamp(0.0, increase);
                    let rest = (increase - sup_only) / 2.0;
                    shift_up += sup_only + rest;
                    shift_down += rest;
                }
            }
        }

        (shift_up, shift_down)
    }

    /// P914 — Função auxiliar para calcular o kerning de duas alturas de correção.
    /// `quadrant`: 0 = TopLeft, 1 = BottomLeft, 2 = TopRight, 3 = BottomRight.
    fn compute_math_kern(
        &self,
        base_char: Option<char>,
        script_char: Option<char>,
        quadrant: u8,
        h_top_pt: f64,
        h_bot_pt: f64,
        style: &TextStyle,
    ) -> f64 {
        let base_kern = base_char
            .map(|c| self.metrics.math_kern(c, style))
            .unwrap_or_default();
        let script_kern = script_char
            .map(|c| self.metrics.math_kern(c, style))
            .unwrap_or_default();

        let (base_q_kern, script_inv_kern) = match quadrant {
            0 => (&base_kern.top_left, &script_kern.bottom_right),
            1 => (&base_kern.bottom_left, &script_kern.top_right),
            2 => (&base_kern.top_right, &script_kern.bottom_left),
            _ => (&base_kern.bottom_right, &script_kern.top_left),
        };

        let summed_at = |h_pt: f64| -> f64 {
            let h_du = h_pt * self.constants.upem / style.size.val().max(0.001);
            let bk = base_q_kern.kern_at(h_du);
            let sk = script_inv_kern.kern_at(h_du);
            self.constants.to_pt(bk + sk, style.size).val()
        };

        summed_at(h_top_pt).max(summed_at(h_bot_pt))
    }
}

#[cfg(test)]
mod smoke {
    use super::super::MathLayouter;
    use crate::compiler::layout::{FixedMetrics, FontMetrics};
    use crate::entities::{
        content::Content,
        layout_types::{Pt, TextStyle},
    };

    #[derive(Clone, Copy)]
    struct P1293IcMetrics;

    impl FontMetrics for P1293IcMetrics {
        fn advance(&self, text: &str, size: Pt, style: &TextStyle) -> Pt {
            FixedMetrics.advance(text, size, style)
        }

        fn vertical_metrics(&self, size: Pt, style: &TextStyle) -> (Pt, Pt) {
            FixedMetrics.vertical_metrics(size, style)
        }

        fn cap_height(&self, size: Pt, style: &TextStyle) -> Pt {
            FixedMetrics.cap_height(size, style)
        }

        fn text_edges(&self, size: Pt, style: &TextStyle) -> (Pt, Pt) {
            FixedMetrics.text_edges(size, style)
        }

        fn char_italics_correction(&self, c: char, size: Pt, _style: &TextStyle) -> Pt {
            let em = match c {
                'x' => 0.016,
                'f' => 0.079,
                'R' => 0.024,
                _ => 0.0,
            };
            size * em
        }
    }

    fn p1293_attach_width(
        base: Content,
        tr: Option<Content>,
        br: Option<Content>,
        block: bool,
    ) -> f64 {
        let style = TextStyle::regular(Pt(11.0));
        let layouter = MathLayouter::new(&P1293IcMetrics, block, &style);
        layouter
            .layout_attach(
                &base,
                None,
                None,
                None,
                None,
                tr.as_ref(),
                br.as_ref(),
                &style,
            )
            .width
    }

    #[test]
    fn module_compila_e_carrega() {}

    #[test]
    fn p1293_markup_vazio_presente_recebe_um_space_after_script() {
        let style = TextStyle::regular(Pt(12.0));
        let layouter = MathLayouter::new(&FixedMetrics, false, &style);
        let base = Content::MathIdent("x".into());
        let empty_markup = Content::Sequence([].into());
        let omitted =
            layouter.layout_attach(&base, None, None, None, None, None, None, &style);
        let spacing = layouter
            .constants
            .to_pt(layouter.constants.space_after_script, style.size)
            .val();

        for quadrant in 0..4 {
            let slots = match quadrant {
                0 => (Some(&empty_markup), None, None, None),
                1 => (None, Some(&empty_markup), None, None),
                2 => (None, None, Some(&empty_markup), None),
                _ => (None, None, None, Some(&empty_markup)),
            };
            let present = layouter.layout_attach(
                &base, None, None, slots.0, slots.1, slots.2, slots.3, &style,
            );
            assert!(
                (present.width - omitted.width - spacing).abs() < 1e-9,
                "quadrante {quadrant} deve reservar exatamente um SpaceAfterScript"
            );
        }
    }

    #[test]
    fn p1293_omissao_e_none_explicito_continuam_sem_spacing() {
        let style = TextStyle::regular(Pt(12.0));
        let layouter = MathLayouter::new(&FixedMetrics, false, &style);
        let base = Content::MathIdent("x".into());
        let omitted = layouter.layout_attach_slots(
            &base,
            &super::MathAttachSlot::Omitted,
            &super::MathAttachSlot::Omitted,
            &super::MathAttachSlot::Omitted,
            &super::MathAttachSlot::Omitted,
            &super::MathAttachSlot::Omitted,
            &super::MathAttachSlot::Omitted,
            &style,
        );
        let explicit_none = layouter.layout_attach_slots(
            &base,
            &super::MathAttachSlot::Omitted,
            &super::MathAttachSlot::Omitted,
            &super::MathAttachSlot::Omitted,
            &super::MathAttachSlot::Omitted,
            &super::MathAttachSlot::ExplicitNone,
            &super::MathAttachSlot::Omitted,
            &style,
        );
        assert_eq!(explicit_none.width, omitted.width);
        assert_eq!(explicit_none.items.len(), omitted.items.len());
    }

    #[test]
    fn p1293_textitem_br_usa_ic_semantica_zero_e_mathident_preserva_ic_metrica() {
        let br = || Content::MathIdent("q".into());
        let text_zero =
            p1293_attach_width(Content::Text("A".into()), None, Some(br()), false);
        assert_eq!(
            p1293_attach_width(Content::Text("1".into()), None, Some(br()), false),
            text_zero
        );

        let style = TextStyle::regular(Pt(11.0));
        let math_zero =
            p1293_attach_width(Content::MathIdent("A".into()), None, Some(br()), false);
        for c in ['x', 'f', 'R'] {
            let text_width = p1293_attach_width(
                Content::Text(c.to_string().into()),
                None,
                Some(br()),
                false,
            );
            assert!(
                (text_width - text_zero).abs() < 1e-9,
                "TextItem {c} deve fornecer IC semântica zero"
            );

            let math_width = p1293_attach_width(
                Content::MathIdent(c.to_string().into()),
                None,
                Some(br()),
                false,
            );
            let metric_ic =
                P1293IcMetrics.char_italics_correction(c, style.size, &style).val();
            assert!(
                (math_width - (math_zero - metric_ic)).abs() < 1e-9,
                "MathIdent {c} deve preservar a IC métrica"
            );
        }
    }

    #[test]
    fn p1293_ic_semantica_nao_compensa_tr_ausencia_e_preserva_full_display() {
        let one = || Content::MathIdent("q".into());
        for base in ["x", "f", "R", "K", "W", "RR"] {
            let content = || Content::Text(base.into());
            let no_post = p1293_attach_width(content(), None, None, false);
            let only_tr = p1293_attach_width(content(), Some(one()), None, false);
            let with_k = p1293_attach_width(
                content(),
                None,
                Some(Content::MathIdent("K".into())),
                false,
            );
            let with_w = p1293_attach_width(
                content(),
                None,
                Some(Content::MathIdent("W".into())),
                false,
            );
            let with_rr = p1293_attach_width(
                content(),
                None,
                Some(Content::MathSequence(
                    [Content::MathIdent("R".into()), Content::MathIdent("R".into())]
                        .into(),
                )),
                false,
            );
            assert!(only_tr > no_post);
            assert!(with_k > no_post && with_w > no_post && with_rr > with_k);
        }

        let full = |base: &str, block| {
            let style = TextStyle::regular(Pt(11.0));
            let layouter = MathLayouter::new(&P1293IcMetrics, block, &style);
            let one = Content::MathIdent("q".into());
            let dominant_br = Content::MathSequence(
                [
                    Content::MathIdent("q".into()),
                    Content::MathIdent("q".into()),
                    Content::MathIdent("q".into()),
                ]
                .into(),
            );
            layouter
                .layout_attach(
                    &Content::Text(base.into()),
                    Some(&one),
                    Some(&one),
                    Some(&one),
                    Some(&one),
                    Some(&one),
                    Some(&dominant_br),
                    &style,
                )
                .width
        };
        for block in [false, true] {
            let zero = full("A", block);
            for base in ["x", "f", "R"] {
                assert!(
                    (full(base, block) - zero).abs() < 1e-9,
                    "full attach TextItem {base} deve manter IC semântica zero"
                );
            }
        }
    }
}
