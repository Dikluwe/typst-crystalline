//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/compiler/layout/page_geometry.md
//! @prompt-hash b44b109b
//! @layer L1
use crate::entities::layout_types::{
    PageConfig, PageDimension, PageMarginSpec, PageMargins,
};
use crate::entities::page_geometry::{PageBinding, Paper};
pub(super) fn apply(
    c: &mut PageConfig,
    dir: crate::entities::dir::Dir,
    paper: Option<Paper>,
    flipped: Option<bool>,
    binding: Option<PageBinding>,
    width: Option<PageDimension>,
    height: Option<PageDimension>,
    margin: Option<PageMarginSpec>,
) {
    let dim = |d| match d {
        PageDimension::Auto => f64::INFINITY,
        PageDimension::Length(v) => v,
    };
    c.base_width = width
        .map(dim)
        .or_else(|| paper.map(Paper::width_pt))
        .unwrap_or(c.base_width);
    c.base_height = height
        .map(dim)
        .or_else(|| paper.map(Paper::height_pt))
        .unwrap_or(c.base_height);
    let f = flipped.unwrap_or(c.flipped);
    let (w, h) =
        if f { (c.base_height, c.base_width) } else { (c.base_width, c.base_height) };
    c.width = w;
    c.height = h;
    c.flipped = f;
    c.page_dir = dir;
    if let Some(b) = binding {
        c.binding = b;
    }
    if let Some(m) = margin {
        c.margin_spec = m.fold(c.margin_spec);
    }
    c.margin = PageMargins::resolve_for_page(
        c.margin_spec,
        c.auto_margin(),
        c.binding.resolve(dir),
        std::num::NonZeroUsize::MIN,
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn p1140_20_1_paper_override_e_flip() {
        let mut c = PageConfig::default();
        apply(
            &mut c,
            crate::entities::dir::Dir::LTR,
            Paper::from_name("us-letter"),
            Some(true),
            None,
            Some(PageDimension::Length(300.0)),
            None,
            None,
        );
        assert_eq!(c.height, 300.0);
        assert_eq!(c.width, Paper::from_name("us-letter").unwrap().height_pt());
    }
    #[test]
    fn p1140_20_1_margem_logica_por_paridade() {
        use std::num::NonZeroUsize;
        let s = PageMarginSpec {
            left: Some(10.0),
            right: Some(20.0),
            top: None,
            bottom: None,
            two_sided: Some(true),
        };
        let odd = PageMargins::resolve_for_page(
            s,
            5.0,
            PageBinding::Left,
            NonZeroUsize::new(1).unwrap(),
        );
        let even = PageMargins::resolve_for_page(
            s,
            5.0,
            PageBinding::Left,
            NonZeroUsize::new(2).unwrap(),
        );
        assert_eq!((odd.left, odd.right), (10.0, 20.0));
        assert_eq!((even.left, even.right), (20.0, 10.0));
    }
}

impl<'a, M: super::metrics::FontMetrics, S: crate::entities::image_sizer::ImageSizer>
    super::Layouter<'a, M, S>
{
    /// **P867** — calcula a largura real da página actual quando `width: auto`,
    /// baseando-se na extensão horizontal dos items já emitidos.
    pub(super) fn compute_page_width(&self) -> f64 {
        let mut content_right = super::helpers::line_content_right(
            self.regions
                .current
                .current_items
                .iter()
                .chain(self.regions.current.current_line.iter()),
            &self.metrics,
        );
        // **P1096** — equações de bloco pendentes de centragem carregam a
        // sua largura integral (incluindo trailing space_after_script).
        for (_, _, eq_width, applied_offset) in &self.pending_equation_centering {
            content_right = content_right.max(applied_offset + eq_width);
        }
        // **P987** — a linha de cada equação numerada pendente reserva
        // `eq_width + 2 × (number_width + gutter)`, `gutter = 0.5em`
        // (vanilla `add_equation_number`/`resize_equation`,
        // `typst-layout/src/math/mod.rs:209-330`). Sem esta reserva a página
        // encolhe ao conteúdo e o número fica sobreposto/fora da margem.
        let numbering_right = self
            .pending_equation_numbering
            .iter()
            .map(|(_, _, style, number_width, eq_width, applied_offset, _)| {
                let gutter = 0.5 * style.size.val();
                applied_offset + eq_width + 2.0 * (number_width + gutter)
            })
            .fold(f64::NEG_INFINITY, f64::max);
        (content_right.max(numbering_right) + self.page_config.margin.right)
            .max(self.page_config.margin.horizontal())
    }

    /// **P867** — calcula a altura real da página actual quando `height: auto`.
    /// O cursor_y já reflecte a posição vertical após o último flush; adiciona
    /// a margem inferior como aproximação do fundo do conteúdo.
    pub(super) fn compute_page_height(&self) -> f64 {
        let base_y = self.last_block_descent_y.unwrap_or(self.regions.current.cursor_y.0);
        (base_y + self.page_config.margin.bottom).max(self.page_config.margin.vertical())
    }
}
