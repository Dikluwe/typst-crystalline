//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/compiler/introspect/locatable.md
//! @prompt-hash 3958d0b5
//! @layer L1
//! @updated 2026-04-30
//!
//! `is_locatable` — função pura `&Content → bool`. P164 (M2 Introspection).
//!
//! Match exaustivo (sem `_ => false`): compilador força revisão quando
//! variant novo é adicionado a `Content`. Invariante:
//! `is_locatable(c) == extract_payload(c).is_some()` para todo c.

use crate::entities::content::Content;

/// Classifica se `content` é uma variante locatable (queryable pela
/// introspecção). M1 cobre 3 kinds: `Heading`, `Figure`, `Cite`.
///
/// Equivalente a `extract_payload(c).is_some()` mas mais barato — sem
/// construção de payload nem cálculo de hash.
pub fn is_locatable(content: &Content) -> bool {
    match content {
        Content::Strong(_) | Content::Emph(_) => true,
        // ── Locatable em M1 ──────────────────────────────────────────
        Content::Heading(_) => true,
        Content::Figure(_) => true,
        Content::Cite    { .. } => true,

        // ── Locatable em M9 (P169) — Metadata é queriable ──────────
        Content::Metadata(_) => true,

        // ── Locatable em M9 (P171) — State e StateUpdate ───────────
        Content::State(_) => true,
        Content::StateUpdate(_) => true,

        // ── Locatable em P240 (M9d/M7+1) — StateDisplay. Walk emite
        // tag para que `apply_state_displays` pre-renderize Content
        // resultado callback pós-fixpoint; layout arm consome via
        // `state_display_value`.
        Content::StateDisplay(_) => true,

        // ── Locatable em P241 (M9d/M7+2) — CounterDisplayCallback
        // paralelo StateDisplay. Walk emite tag; `apply_counter_displays`
        // pré-renderiza Content via `apply_func(callback,
        // [Value::Array(counter_state)], ctx, engine)` pós-fixpoint;
        // layout arm consome via `counter_display_value`.
        // Distinto de `Content::CounterDisplay { kind }` legacy
        // (não-locatable; single-pass Layouter directo).
        Content::CounterDisplayCallback(_) => true,

        // ── Locatable em P506 — ContextBlock (delayed evaluation via
        // `context { expr }`). Walk emite tag para capturar a Location
        // onde o bloco aparece; expansão pós-introspecção avalia o closure.
        Content::ContextBlock(_) => true,

        // ── Locatable em P178 — Outline fecha lacuna #7 ────────────
        Content::Outline(_) => true,
        Content::OutlineEntry(_) => true,

        // ── Locatable em P181D — Bibliography (decisão P181A
        // cláusula 4 = Opção β walk puro). `from_tags` arm popula
        // `BibStore` (P181E pendente). Suporta plano P181 para
        // fechar lacuna #6.
        Content::Bibliography(_) => true,

        // ── Locatable em P182C — SetHeadingNumbering emite
        // `StateUpdate { key: "numbering_active:heading", ... }` via
        // `extract_payload`. `from_tags` arm `StateUpdate` (P171/P173)
        // popula `StateRegistry`. Suporta plano P182 para fechar
        // lacuna #4. Walk arm canonical em `introspect.rs:455–457`
        // continua write paralelo legacy (M6 elimina).

        // ── Locatable em P199B — SetEquationNumbering emite
        // `StateUpdate { key: "numbering_active:equation", ... }` via
        // `extract_payload`. Reusa arm `from_tags::StateUpdate`
        // (P171/P173) genérica. Materializa Reserva 1 (E1 P189B).
        // Cenário α por construção (ADR-0069) — caminho Introspector
        // activa imediatamente porque toda infraestrutura downstream
        // já estava pronta (Layouter equation.rs:32-33
        // substitution-with-fallback adormecida). Walk arm canonical
        // continua write paralelo legacy (M6 elimina).

        // ── Locatable em P186D — Equation. Combinado com arm em
        // `extract_payload` (P186C) repõe invariante
        // `is_locatable ↔ extract_payload.is_some()`. `from_tags`
        // arm Equation (P186E) gate `block && state numbering_active:equation`
        // — counter dormente em produção até `Content::SetEquationNumbering`
        // (passo dedicado, fora da série P186). Suporta C2
        // desbloqueio per ADR-0068 (eixo 2 P183C); consumer migra
        // em P188.
        Content::Equation(_) => true,

        // ── Locatable em P198C — CounterUpdate (cenário β-promote
        // ADR-0069). `extract_payload` emite
        // `ElementPayload::CounterUpdate { key, action }` pré-recursão;
        // `from_tags` arm aplica a `CounterRegistry` via `apply_at`
        // (flat) ou `apply_hierarchical_at` (key="heading"). Walk
        // arm legacy (E6 P189B) preservado como write paralelo M5
        // porque `compute_*` helpers leem `state.flat`/`hierarchical`
        // durante walk; cleanup orgânico em M6.
        Content::CounterUpdate(_) => true,

        // ── Locatable em P461 — Table. Counter flat `"table"` populado
        // quando caption + `table.numbering` presentes na chain;
        // `extract_payload` emite `ElementPayload::Table`. Desbloqueia
        // label/ref para tables em Trilha 2.
        Content::Table(_) => true,

        // ── Locatable em P1016 — Footnote. Counter flat `"footnote"`
        // avança uma vez por nota (sem gate, ao contrário de Table);
        // `extract_payload` emite `ElementPayload::Footnote`. Substitui
        // `Layouter::footnote_counter`, e desbloqueia `counter(footnote)`
        // (paridade vanilla, ver `compiler/introspect.md` §P1016). Revoga
        // o scope-out de P295 Fase 1.
        Content::Footnote(_) => true,

        // ── Lote F-1 (P334): a fronteira dinâmica é locatável SE o
        // elemento de utilizador declarar um `element_kind`. Mantém o
        // invariante `is_locatable ↔ extract_payload.is_some()` (o arm de
        // `extract_payload` despacha `e.to_payload()`).
        Content::Dynamic(e) => e.dyn_element_kind().is_some(),

        // ── Não-locatable ──────────────────────────────────────────
        Content::Empty
        | Content::Text(_)
        | Content::Space | Content::SpaceFromNewline
        // P622: Parbreak não é locatable — é cola estrutural.
        | Content::Parbreak
        | Content::PageRun(_)
        // P863: Par é contentor de parágrafo; não é locatable.
        | Content::Par { .. }
        | Content::Sequence(_)
        | Content::Raw(_)
        | Content::ListItem(_)
        | Content::EnumItem(_)
        | Content::Link(_)
        | Content::MathSequence(_)
        | Content::MathIdent(_)
        | Content::MathText(_)
        | Content::MathFrac(_)
        | Content::MathAttach(_)
        | Content::MathPrimes(_)
        | Content::MathRoot(_)
        | Content::MathStretch(_)
        | Content::MathDelimited(_)
        | Content::MathLr(_)
        | Content::MathMid(_)
        | Content::MathOverbrace(_)
        | Content::MathUnderbrace(_)
        | Content::MathUnderbracket(_)
        | Content::MathUnderparen(_)
        | Content::MathUndershell(_)
        | Content::MathOverbracket(_)
        | Content::MathOverparen(_)
        | Content::MathOvershell(_)
        | Content::MathAlignPoint(_)
        | Content::Linebreak(_)
        | Content::MathMatrix(_)
        | Content::MathCases(_)
        | Content::Label(_)
        | Content::Ref(_)
        | Content::CounterDisplay(_)
        | Content::Image(_)
        | Content::Shape { .. }
        | Content::Curve(_)
        | Content::Transform(_)
        | Content::Grid(_)
        | Content::SetPage(_)
        | Content::Align(_)
        | Content::Place(_)
        | Content::Flush(_)
        | Content::Styled(_)
        | Content::Divider(_)
        | Content::Terms(_)
        | Content::TermItem(_)
        | Content::Quote(_)
        // P284 — text decoration: não-locatable (cosmético inline; sem
        // identidade observable, paridade Quote/Link).
        | Content::Underline(_)
        | Content::Strike(_)
        | Content::Overline(_)
        // P408 — SmallCaps é não-locatable (stub transparente; cosmtico inline).
        | Content::SmallCaps { .. }
        // P287 — SmartQuote leaf não-locatable (glyph único; sem identidade
        // queryable; paridade Space/Linebreak).
        | Content::SmartQuote(_)
        | Content::Pad(_)
        | Content::Hide(_)
        | Content::HSpace(_)
        | Content::VSpace(_)
        | Content::Pagebreak(_)
        // P220: Colbreak não-locatable (event leaf; paridade Pagebreak).
        | Content::Colbreak(_)
        | Content::Stack(_)
        | Content::Boxed(_)
        | Content::Block(_)
        | Content::TableCell(_)
        | Content::TableHeader { .. }
        | Content::TableFooter { .. }
        // P224 — Grid refino + variants novos não-locatable (paridade
        // Table*; events estructurais sem identidade observable).
        | Content::GridHeader { .. }
        | Content::GridFooter { .. }
        | Content::GridCell(_)
        // Passo 512 — linhas em grid/table não-locatable.
        | Content::GridHLine(_)
        | Content::GridVLine(_)
        | Content::TableHLine(_)
        | Content::TableVLine(_)
        | Content::Repeat(_)
        // P217 — Columns container não-locatable (transparente para
        // introspect; consumer multi-region em P219).
        | Content::Columns(_)
        // P296 — Math accent/cancel não-locatable (paralelo
        // MathFrac/MathRoot/MathDelimited; math structural inerte).
        | Content::MathAccent(_)
        | Content::MathCancel(_)
        | Content::MathUnderline(_)
        | Content::MathOverline(_)
        | Content::MathVec(_)
        // P772y — Math class override não-locatable (paralelo P296/P298).
        | Content::MathClassOverride(_)
        // P992 — Math limits override não-locatable (limits()/scripts()).
        | Content::MathLimitsOverride(_)
        // P297 — Math underover não-locatable (paralelo P296).
        | Content::MathUnderover(_)
        // P298 — Math op não-locatable.
        | Content::MathOp(_)
        // P311b.2 — MathStyled não-locatable (math structural; wrap glyph).
        | Content::MathStyled(_)
        // P397 — Document/Asset são metadata/resources; não queryable.
        // P765a — Title é markup estrutural, não queryable.
        | Content::Title(_)
        | Content::Document { .. }
        | Content::Asset { .. }
        | Content::PdfAttach(_)
        | Content::PdfArtifact(_)
        | Content::HtmlElem(_)
        | Content::HtmlFrame(_)
        // P1473 — `figure.caption`/`footnote.entry`, escopo reduzido:
        // construção sem síntese/realização, não participam da
        // introspecção nesta fatia (nenhuma delas emite payload).
        | Content::FigureCaption(_)
        | Content::FootnoteEntry(_) => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn p1339_own_emphasis_occurrences_are_locatable() {
        for content in [Content::strong(Content::Empty), Content::emph(Content::Empty)] {
            assert!(is_locatable(&content));
            assert!(crate::compiler::introspect::extract_payload::extract_payload(
                &content
            )
            .is_some());
        }
        assert!(!is_locatable(&Content::text("plain")));
    }
    use crate::compiler::introspect::extract_payload::extract_payload;
    use ecow::EcoString;

    // ── Cobertura locatable ──────────────────────────────────────────

    #[test]
    fn heading_e_locatable() {
        let c = Content::heading(1, Content::Empty);
        assert!(is_locatable(&c));
    }

    #[test]
    fn figure_e_locatable() {
        let c = Content::figure(Content::Empty, None, None, None);
        assert!(is_locatable(&c));
    }

    #[test]
    fn cite_e_locatable() {
        let c = Content::cite("k".to_string(), None, None);
        assert!(is_locatable(&c));
    }

    // ── Cobertura não-locatable ─────────────────────────────────────

    #[test]
    fn text_nao_e_locatable() {
        let c = Content::Text(EcoString::from("plain"));
        assert!(!is_locatable(&c));
    }

    #[test]
    fn empty_nao_e_locatable() {
        assert!(!is_locatable(&Content::Empty));
    }

    #[test]
    fn space_nao_e_locatable() {
        for space in [Content::Space, Content::SpaceFromNewline] {
            assert!(!is_locatable(&space));
            assert!(extract_payload(&space).is_none());
        }
    }

    #[test]
    fn sequence_nao_e_locatable() {
        let c = Content::Sequence(std::sync::Arc::from(vec![Content::Empty]));
        assert!(!is_locatable(&c));
    }

    #[test]
    fn labelled_nao_e_locatable_mesmo_que_target_seja() {
        // Labelled em si não é locatable — o target é (via wrapping
        // mechanism em walk). Esta é uma propriedade da função pura
        // is_locatable: olha apenas para o nó actual, não para
        // children.
        let c = Content::label_auto("x".to_string(), Content::heading(1, Content::Empty));
        assert!(!is_locatable(&c));
    }

    // ── Invariante: is_locatable(c) == extract_payload(c).is_some() ──

    fn build_minimal_for_each_variant() -> Vec<Content> {
        // Constrói representante de cada bucket relevante. Não cobre
        // todas as 56 variants — uma instância por bucket é suficiente
        // para verificar a invariante (a invariante é estrutural sobre
        // o match em ambas as funções).
        vec![
            // Locatable (4)
            Content::heading(1, Content::Empty),
            Content::figure(Content::Empty, None, None, None),
            Content::cite("k", None, None),
            // P461: Table passa a locatable.
            Content::table(Vec::new(), Vec::new(), Vec::new()),
            // Não-locatable: amostra representativa
            Content::Empty,
            Content::Text(EcoString::from("t")),
            Content::Space,
            Content::Sequence(std::sync::Arc::from(vec![Content::Empty])),
            Content::label_auto("x".to_string(), Content::Empty),
            Content::reference("y"),
            Content::outline(),
            Content::linebreak(),
            Content::divider(),
            Content::math_align_point(),
            Content::list_item(Content::Empty),
            // Passo 513 — Curve não-locatable.
            Content::curve_move(
                crate::entities::layout_types::Length::pt(0.0),
                crate::entities::layout_types::Length::pt(0.0),
            ),
            // P186D: Equation cobertura no test de invariante.
            // Lacuna pré-existente — Equation estava omitida do
            // helper, escondendo divergências entre is_locatable e
            // extract_payload se houvesse erro de sincronização.
            Content::equation(Content::Empty, true),
        ]
    }

    #[test]
    fn invariante_is_locatable_equivale_extract_payload_is_some() {
        for c in build_minimal_for_each_variant() {
            assert_eq!(
                is_locatable(&c),
                extract_payload(&c).is_some(),
                "invariante violada para variant {c:?}"
            );
        }
    }

    // ── P169 (M9 sub-passo 1) — Metadata locatable ───────────────────────

    #[test]
    fn metadata_e_locatable() {
        let c = Content::metadata(crate::entities::value::Value::Int(42));
        assert!(is_locatable(&c));
        // Invariante: extract_payload deve produzir Some.
        assert!(extract_payload(&c).is_some());
    }

    // ── P181D — Bibliography locatable ───────────────────────────────────

    #[test]
    fn bibliography_e_locatable() {
        let c = Content::bibliography(vec![], None);
        assert!(is_locatable(&c));
        // Invariante: extract_payload deve produzir Some.
        assert!(extract_payload(&c).is_some());
    }

    // Lote F-2 S5 (P335): `set_heading_numbering_e_locatable` removido — a
    // variante saiu (numeração via chain léxica; já não é locatável/marcador).
}
