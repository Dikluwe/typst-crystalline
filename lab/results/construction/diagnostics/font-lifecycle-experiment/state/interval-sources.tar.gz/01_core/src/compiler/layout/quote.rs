//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/compiler/layout/quote.md
//! @prompt-hash 2d56516d
//! @layer L1
//! @updated 2026-06-19
//!
//! Atomização (ADR-0109, P381): o layout de `Quote` movido do monólito
//! `layout_content` para o arquivo da feature (forma B). Content-preserving.

use crate::entities::content::Content;
use crate::entities::elements::quote::QuoteElem;
use crate::entities::layout_types::Pt;

use super::{FontMetrics, ImageSizer, Layouter};

/// Layout de `quote(...)`: aspas lang-aware (se `quotes`), body, e atribuição
/// (`— ...`). Modo bloco indenta e força nova linha; inline fica em-linha.
pub(super) fn layout<M: FontMetrics, S: ImageSizer>(
    layouter: &mut Layouter<M, S>,
    e: &QuoteElem,
) {
    use crate::compiler::lang::quotes::{localize_quotes, DEFAULT_QUOTES};
    let lang = layouter.chain.lang();
    // **P1055** — paridade vanilla `lab/typst-original/crates/typst-library/src/model/quote.rs:75-95`:
    // em modo bloco, aspas inteligentes padrão são suprimidas.
    let (open, close) = if e.quotes && !e.block {
        match &lang {
            Some(l) => localize_quotes(l),
            None => DEFAULT_QUOTES,
        }
    } else {
        ("", "")
    };
    if e.block {
        if layouter.regions.current.cursor_x.0 > layouter.page_config.margin.left {
            layouter.flush_line();
        }
        let margin_pt = Pt(layouter.page_config.margin.left);
        // ref: lab/typst-original/crates/typst-library/src/model/quote.rs:80
        // **P1055** — paridade vanilla: indent padrão de quote bloco é 1.0em (não 1.5em).
        layouter.regions.current.cursor_x = margin_pt + layouter.style.size;
        if !open.is_empty() {
            layouter.layout_content(&Content::text(open));
        }
        layouter.layout_content(&e.body);
        if !close.is_empty() {
            layouter.layout_content(&Content::text(close));
        }
        if let Some(a) = &e.attribution {
            layouter.flush_line();
            layouter.regions.current.cursor_x = margin_pt + layouter.style.size;
            layouter.layout_content(&Content::text("— "));
            layouter.layout_content(a);
        }
        layouter.flush_line();
        layouter.regions.current.cursor_x = margin_pt;
    } else {
        if !open.is_empty() {
            layouter.layout_content(&Content::text(open));
        }
        layouter.layout_content(&e.body);
        if !close.is_empty() {
            layouter.layout_content(&Content::text(close));
        }
        if let Some(a) = &e.attribution {
            layouter.layout_content(&Content::text(" — "));
            layouter.layout_content(a);
        }
    }
}
