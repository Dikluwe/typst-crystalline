//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/compiler/eval.md
//! @prompt-hash aaaa7453
//! @layer L1
//! @updated 2026-09-21
//!
//! Dispatcher central do eval: `EvalContext` struct + impl, `pub fn eval`
//! entry point, `eval_markup` iterator, `eval_expr` dispatcher delegando
//! cada armo para o submódulo do respectivo domínio (ADR-0037 Regra 4,
//! completada no Passo 96.2).
//!
//! Armos triviais (literais `Int`/`Float`/`Bool`/etc., `Ref`/`Label`/
//! `Parenthesized`) permanecem inline; armos que contêm scoping
//! cross-cutting (`CodeBlock`, `ContentBlock`) também, por não
//! pertencerem a nenhum cluster em particular.

use std::cell::RefCell;
use std::collections::HashMap;
use std::sync::Arc;

use comemo::{Track, Tracked, TrackedMut};
use ecow::EcoString;
use hayagriva::citationberg::IndependentStyle;

use crate::compiler::eval::operators::error_formatting::vanilla_type_name;
use crate::compiler::layout::FixedMetrics;
use crate::compiler::scopes::Scopes;
use crate::contracts::world::{SysInputs, World};
#[cfg(test)]
use crate::entities::ast::expr::UnOp;
use crate::entities::ast::expr::{ArrayItem, BinOp, Expr};
use crate::entities::ast::markup::Label as AstLabel;
use crate::entities::ast::AstNode;
use crate::entities::content::Content;
#[cfg(test)]
use crate::entities::counter_update::CounterUpdate as CounterAction;
use crate::entities::document_info::DocumentInfo;
use crate::entities::elements::bibliography::BibliographyElem;
use crate::entities::elements::context_block::ContextBlockElem;
use crate::entities::engine::Engine;
use crate::entities::file_id::FileId;
use crate::entities::font_book::FontBook;
use crate::entities::func::{ClosureRepr, Func};
use crate::entities::module::Module;
use crate::entities::package_spec::PackageSpec;
use crate::entities::path::RootedPath;
use crate::entities::scope::Scope;
use crate::entities::show::{RuleId, ShowRule};
use crate::entities::source::Source;
use crate::entities::source_result::{SourceDiagnostic, SourceResult};
use crate::entities::span::Span;
use crate::entities::style_chain::StyleChain;
use crate::entities::syntax_kind::SyntaxKind;
use crate::entities::syntax_node::{SyntaxErrorKind, SyntaxNode};
use crate::entities::value::{Type, Value};
use crate::entities::world_types::{
    Bytes, Datetime, FileResult, Font, Library, Route, Routines, Sink, Traced,
};

// Submódulos por domínio (Passo 96.1, ADR-0037).
pub(crate) mod cast;
pub(crate) mod font_dict;
mod math;
pub(crate) mod operators;
pub use cast::{cast_length, CastError};
pub(crate) mod flow;
pub use flow::FlowEvent;
pub(crate) mod call_dispatch;
pub(crate) mod closures;
mod control_flow;
pub use call_dispatch::apply_func;
pub(crate) mod bibliography;
pub mod bibtex;
pub(crate) mod bindings;
mod markup;
mod modules;
pub(crate) mod repr;
pub(crate) mod table;

/// P1406 — entrypoint L1 para a fase pós-introspecção de outlines.
pub fn realize_outlines(
    content: Content,
    introspector: &crate::entities::introspector::TagIntrospector,
    ctx: &mut EvalContext,
    engine: &mut Engine<'_>,
) -> SourceResult<Content> {
    rules::realize_outlines(content, introspector, ctx, engine)
}

/// Representação morfológica pública e estreita de `Stroke` para consumidores
/// que possuem uma branch nominal do tipo. Não é fallback genérico de `Value`.
pub fn repr_stroke_value(stroke: &crate::entities::geometry::Stroke) -> String {
    repr::repr_stroke(stroke)
}

/// Representação morfológica pública usada por serializers estruturados.
///
/// A classificação entre valores estruturais e fallback textual pertence ao
/// formatter consumidor; esta fachada apenas expõe o `repr` total de L1.
pub fn repr_value_for_serialization(value: &crate::entities::value::Value) -> String {
    repr::repr_value(value)
}

/// **P1469** (escopo reduzido — contrato de linguagem) — expõe a mesma
/// formatação de diagnóstico que o braço `format.pdf` de `rules.rs` usa
/// para o conflito documental `standard`, reaproveitada pelo gate CLI-only
/// de `04_wiring/src/main.rs` (`wiring.md` P1469: "mesmo texto que
/// `compiler/eval/rules.rs` P1469 usa para o caso documental — é a mesma
/// função de validação, reaproveitada").
pub fn pdf_standards_conflict_diagnostic(
    conflict: crate::entities::document_format_options::PdfStandardsConflict,
) -> SourceDiagnostic {
    rules::pdf_standards_conflict_diagnostic(Span::detached(), conflict)
}
pub(crate) mod rules;
pub(crate) mod selector_matching;
pub(crate) mod show_rule_termination;

#[cfg(test)]
mod p1339_observer_local_tests {
    use super::*;

    struct MemoryWorld {
        library: Library,
        book: FontBook,
    }
    impl World for MemoryWorld {
        fn library(&self) -> &Library {
            &self.library
        }
        fn book(&self) -> &FontBook {
            &self.book
        }
        fn main(&self) -> FileId {
            FileId::from_raw(std::num::NonZeroU16::new(1).unwrap())
        }
        fn source(&self, _: FileId) -> FileResult<Source> {
            Err(crate::entities::world_types::FileError::NotFound)
        }
        fn file(&self, _: FileId) -> FileResult<Bytes> {
            Err(crate::entities::world_types::FileError::NotFound)
        }
        fn font(&self, _: usize) -> Option<Font> {
            None
        }
        fn today(
            &self,
            _: Option<crate::entities::duration::Duration>,
        ) -> Option<Datetime> {
            None
        }
    }

    #[test]
    fn context_read_replay_uses_captured_context() {
        let world = MemoryWorld { library: Library::new(), book: FontBook::new() };
        let metrics = FixedMetrics;
        let route = Route::root().with_id(world.main());
        let mut styles = StyleChain::default_chain();
        let mut rules: Arc<[ShowRule]> = Arc::from([]);
        let mut guards = Vec::new();
        let mut sink = Sink::new();
        let mut tracked = sink.track_mut();
        let mut engine = Engine {
            world: &world,
            font_metrics: &metrics,
            route: route.track(),
            styles: &mut styles,
            show_rules: &mut rules,
            active_guards: &mut guards,
            current_file: world.main(),
            sink: &mut tracked,
        };
        let mut ctx = EvalContext::new();
        let location = crate::entities::locator::Locator::new().next();
        ctx.in_context = true;
        ctx.current_location = Some(location);
        ctx.replace_context_read_file(Some(world.main()));
        let state = crate::entities::state::State {
            key: "read".into(),
            init: Box::new(Value::Int(1)),
        };
        let body =
            crate::compiler::stdlib::state::state_get(&state, &ctx, Span::detached());
        assert_eq!(
            body.observation_relation(&Ok(Value::Int(1))),
            ObservationRelation::Same
        );
        let mut candidate = crate::entities::introspector::TagIntrospector::empty();
        // A captured request must not be replayed under subsequently changed
        // ambient location/context flags.
        ctx.in_context = false;
        ctx.current_location = None;
        assert_eq!(ctx.context_reads_valid_for(&candidate, &mut engine).unwrap(), true);
        candidate.state.init("read".into(), Value::Int(2), location);
        assert_eq!(ctx.context_reads_valid_for(&candidate, &mut engine).unwrap(), false);
        assert_eq!(ctx.context_reads.borrow().reads.len(), 1);
        assert_eq!(
            body.observation_relation(&Ok(Value::Int(1))),
            ObservationRelation::Same
        );
        assert!(comemo::internal::to_parts_mut_ref(engine.sink).0.is_empty());
    }

    #[test]
    fn observation_relation_ieee_and_recursive_fields() {
        let nan = Value::Float(f64::from_bits(0x7ff8000000001234));
        assert_eq!(nan.observation_relation(&nan.clone()), ObservationRelation::Same);
        assert_eq!(
            Value::Float(0.0).observation_relation(&Value::Float(-0.0)),
            ObservationRelation::Different
        );
        let a = Value::Content(Content::metadata(nan.clone()));
        let b = Value::Content(Content::metadata(Value::Float(f64::from_bits(
            0x7ff8000000001235,
        ))));
        assert_eq!(a.observation_relation(&a.clone()), ObservationRelation::Same);
        assert_eq!(a.observation_relation(&b), ObservationRelation::Different);
    }

    #[test]
    fn context_read_records_before_selection_and_preserves_error() {
        let ctx = EvalContext::new();
        let result = Err(vec![SourceDiagnostic::error(Span::detached(), "read failed")]);
        let returned = ctx.observe_context_read(
            ContextReadRequest::Here,
            Span::detached(),
            result.clone(),
        );
        assert_eq!(returned.observation_relation(&result), ObservationRelation::Same);
        assert!(!ctx.has_filtered_counter_reads());
        assert_eq!(ctx.context_reads.borrow().reads.len(), 1);
    }
}

mod observation;
#[cfg(test)]
pub(crate) use observation::{
    p1436_math_lr_observation_differs, p1437_math_mid_observation_differs,
    p1439_math_overbrace_observation_differs, p1440_math_overbracket_observation_differs,
    p1441_math_overline_observation_differs, p1442_math_overparen_observation_differs,
    p1443_math_overshell_observation_differs, p1444_math_primes_observation_differs,
    p1448_math_underbrace_observation_differs,
    p1449_math_underbracket_observation_differs,
    p1450_math_underparen_observation_differs, p1451_math_undershell_observation_differs,
};
use observation::{ObservationEq, ObservationRelation};

/// Closed vocabulary of causal reads. It is deliberately separate from the
/// language's equality and from the introspector's stores.
#[derive(Clone)]
pub(crate) enum ContextReadRequest {
    CounterFold {
        key: crate::entities::counter::CounterKey,
    },
    CounterAt {
        key: crate::entities::counter::CounterKey,
        location: crate::entities::location::Location,
    },
    CounterLabelAt {
        key: crate::entities::counter::CounterKey,
        label: crate::entities::label::Label,
    },
    CounterFinal {
        key: crate::entities::counter::CounterKey,
    },
    CounterTotal {
        key: crate::entities::counter::CounterKey,
    },
    CounterResolve {
        value: Value,
    },
    CounterLegacyAt {
        key: String,
        label: crate::entities::label::Label,
    },
    CounterLegacyFinal {
        key: String,
    },
    StateGet {
        state: crate::entities::state::State,
    },
    StateDisplay {
        state: crate::entities::state::State,
    },
    StateAt {
        state: crate::entities::state::State,
        location: crate::entities::location::Location,
    },
    StateFinal {
        state: crate::entities::state::State,
    },
    StateResolveLabel {
        label: crate::entities::label::Label,
    },
    StateLegacyAt {
        key: String,
        label: crate::entities::label::Label,
    },
    StateLegacyFinal {
        key: String,
    },
    Query {
        selector: crate::entities::selector::Selector,
    },
    Locate {
        selector: crate::entities::selector::Selector,
    },
    Here,
    LocationPage {
        location: crate::entities::location::Location,
    },
    LocationPosition {
        location: crate::entities::location::Location,
    },
    LocationPageNumbering {
        location: crate::entities::location::Location,
    },
    OutlineEntryPage {
        location: crate::entities::location::Location,
    },
    OutlineEntryIndented {
        entry: crate::entities::content::Content,
        prefix: Value,
        inner: Value,
        gap: crate::entities::layout_types::Length,
    },
}

#[derive(Clone)]
struct ContextRead {
    request: ContextReadRequest,
    span: Span,
    current_file: Option<FileId>,
    location: Option<crate::entities::location::Location>,
    in_context: bool,
    target: EvalTarget,
    features: crate::entities::compiler_features::Features,
    styles: Arc<StyleChain>,
    show_rules: Arc<[ShowRule]>,
    active_guards: Vec<RuleId>,
    result: SourceResult<Value>,
}

struct ContextReads {
    selected: bool,
    replaying: bool,
    styles: StyleChain,
    show_rules: Arc<[ShowRule]>,
    active_guards: Vec<RuleId>,
    current_file: Option<FileId>,
    reads: Vec<Arc<ContextRead>>,
}

impl ContextReads {
    fn new() -> Self {
        Self {
            selected: false,
            replaying: false,
            styles: StyleChain::default_chain(),
            show_rules: Arc::from([]),
            active_guards: Vec::new(),
            current_file: None,
            reads: Vec::new(),
        }
    }
}

impl EvalContext {
    pub(crate) fn replace_context_read_styles(&self, styles: StyleChain) -> StyleChain {
        std::mem::replace(&mut self.context_reads.borrow_mut().styles, styles)
    }

    pub(crate) fn replace_context_read_rules(
        &self,
        rules: Arc<[ShowRule]>,
        guards: Vec<RuleId>,
    ) -> (Arc<[ShowRule]>, Vec<RuleId>) {
        let mut log = self.context_reads.borrow_mut();
        (
            std::mem::replace(&mut log.show_rules, rules),
            std::mem::replace(&mut log.active_guards, guards),
        )
    }

    pub(crate) fn replace_context_read_file(
        &self,
        file: Option<FileId>,
    ) -> Option<FileId> {
        std::mem::replace(&mut self.context_reads.borrow_mut().current_file, file)
    }

    pub(crate) fn mark_filtered_counter_read(
        &self,
        key: &crate::entities::counter::CounterKey,
    ) {
        fn contains_element(selector: &crate::entities::selector::Selector) -> bool {
            use crate::entities::selector::Selector;
            match selector {
                Selector::Element { .. } => true,
                Selector::And(items) | Selector::Or(items) => {
                    items.iter().any(contains_element)
                }
                Selector::Where { base, .. } => contains_element(base),
                Selector::Within { base, ancestor } => {
                    contains_element(base) || contains_element(ancestor)
                }
                Selector::Before { base, end, .. } => {
                    contains_element(base) || contains_element(end)
                }
                Selector::After { base, start, .. } => {
                    contains_element(base) || contains_element(start)
                }
                Selector::Kind(_)
                | Selector::Label(_)
                | Selector::Location(_)
                | Selector::Regex(_) => false,
            }
        }
        if let crate::entities::counter::CounterKey::Selector(selector) = key {
            if contains_element(selector) {
                self.context_reads.borrow_mut().selected = true;
            }
        }
    }

    pub(crate) fn observe_context_read(
        &self,
        request: ContextReadRequest,
        span: Span,
        result: SourceResult<Value>,
    ) -> SourceResult<Value> {
        let mut log = self.context_reads.borrow_mut();
        if !log.replaying {
            let styles = Arc::new(log.styles.clone());
            let current_file = log.current_file;
            let show_rules = log.show_rules.clone();
            let active_guards = log.active_guards.clone();
            log.reads.push(Arc::new(ContextRead {
                request,
                span,
                current_file,
                location: self.current_location,
                in_context: self.in_context,
                target: self.target,
                features: self.features,
                styles,
                show_rules,
                active_guards,
                result: result.clone(),
            }));
        }
        result
    }

    pub fn has_filtered_counter_reads(&self) -> bool {
        self.context_reads.borrow().selected
    }
    /// P1493 — indica demanda causal efetivamente observada por posição HTML.
    #[doc(hidden)]
    pub fn has_location_position_reads(&self) -> bool {
        self.context_reads.borrow().reads.iter().any(|read| {
            matches!(&read.request, ContextReadRequest::LocationPosition { .. })
        })
    }

    fn replay_context_read(
        &self,
        read: &Arc<ContextRead>,
        candidate: &crate::entities::introspector::TagIntrospector,
        engine: &mut Engine<'_>,
    ) -> SourceResult<Value> {
        let mut ctx = EvalContext::new();
        ctx.introspector = candidate.clone();
        ctx.current_location = read.location;
        ctx.in_context = read.in_context;
        ctx.target = read.target;
        ctx.features = read.features;
        ctx.full_error = self.full_error;
        ctx.max_loop_iterations = self.max_loop_iterations;
        ctx.context_reads.borrow_mut().replaying = true;
        ctx.replace_context_read_styles((*read.styles).clone());
        let mut styles = (*read.styles).clone();
        let mut rules = read.show_rules.clone();
        let mut guards = read.active_guards.clone();
        let mut sink = Sink::new();
        let mut sink_tracked = sink.track_mut();
        let mut transaction = Engine {
            world: engine.world,
            font_metrics: engine.font_metrics,
            route: engine.route,
            styles: &mut styles,
            show_rules: &mut rules,
            active_guards: &mut guards,
            current_file: read.current_file.unwrap_or(engine.current_file),
            sink: &mut sink_tracked,
        };
        use ContextReadRequest::*;
        let result = match &read.request {
            CounterFold { .. }
            | CounterAt { .. }
            | CounterLabelAt { .. }
            | CounterFinal { .. }
            | CounterTotal { .. }
            | CounterResolve { .. }
            | CounterLegacyAt { .. }
            | CounterLegacyFinal { .. } => {
                crate::compiler::stdlib::counter::replay_context_read(
                    &read.request,
                    &mut ctx,
                    &mut transaction,
                    read.span,
                )
            }
            StateGet { .. }
            | StateDisplay { .. }
            | StateAt { .. }
            | StateFinal { .. }
            | StateResolveLabel { .. }
            | StateLegacyAt { .. }
            | StateLegacyFinal { .. } => {
                crate::compiler::stdlib::state::replay_context_read(
                    &read.request,
                    &mut ctx,
                    &mut transaction,
                    read.span,
                )
            }
            Query { selector } | Locate { selector } => {
                let mut args = crate::entities::args::Args::positional(Vec::new());
                args.span = read.span;
                args.items.push(Value::Selector(selector.clone()));
                let call = if matches!(read.request, Query { .. }) {
                    crate::compiler::stdlib::native_query
                } else {
                    crate::compiler::stdlib::native_locate
                };
                call(&mut ctx, &args, transaction.world, transaction.current_file)
            }
            Here => {
                let mut args = crate::entities::args::Args::positional(Vec::new());
                args.span = read.span;
                crate::compiler::stdlib::native_here(
                    &mut ctx,
                    &args,
                    transaction.world,
                    transaction.current_file,
                )
            }
            LocationPage { location } => call_dispatch::eval_location_method(
                *location, "page", &mut ctx, read.span,
            ),
            LocationPosition { location } => call_dispatch::eval_location_method(
                *location, "position", &mut ctx, read.span,
            ),
            LocationPageNumbering { location } => call_dispatch::eval_location_method(
                *location,
                "page-numbering",
                &mut ctx,
                read.span,
            ),
            OutlineEntryPage { location } => {
                let mut scopes = crate::compiler::scopes::Scopes::new(None);
                crate::compiler::stdlib::realize_outline_entry_page(
                    *location,
                    read.span,
                    &mut scopes,
                    &mut ctx,
                    &mut transaction,
                )
            }
            OutlineEntryIndented { entry, prefix, inner, gap } => {
                let mut scopes = crate::compiler::scopes::Scopes::new(None);
                let mut named = indexmap::IndexMap::default();
                named.insert("gap".into(), Value::Length(*gap));
                let args = crate::entities::args::Args::from_parts(
                    vec![Value::Content(entry.clone()), prefix.clone(), inner.clone()],
                    named,
                    read.span,
                );
                crate::compiler::stdlib::native_outline_entry_indented(
                    &mut ctx,
                    &args,
                    transaction.world,
                    transaction.current_file,
                    &mut scopes,
                    &mut transaction,
                )
            }
        };
        result
    }

    pub fn context_reads_valid_for(
        &self,
        candidate: &crate::entities::introspector::TagIntrospector,
        engine: &mut Engine<'_>,
    ) -> SourceResult<bool> {
        let reads = self.context_reads.borrow().reads.clone();
        let mut valid = true;
        for read in &reads {
            let result = self.replay_context_read(read, candidate, engine);
            if read.result.observation_relation(&result) != ObservationRelation::Same {
                valid = false;
                break;
            }
        }
        Ok(valid)
    }

    pub fn context_nonconvergence_diagnostics(
        &self,
        history: &[crate::entities::introspector::TagIntrospector],
        engine: &mut Engine<'_>,
    ) -> SourceResult<Vec<SourceDiagnostic>> {
        if history.len() < 2 {
            return Ok(Vec::new());
        }
        let reads = self.context_reads.borrow().reads.clone();
        let mut diagnostics = Vec::new();
        for read in &reads {
            // Fullfold and lookup-resolution are dependencies of projections,
            // not additional user-facing value queries.
            let (name, counter) = match &read.request {
                ContextReadRequest::CounterAt { key, .. }
                | ContextReadRequest::CounterLabelAt { key, .. }
                | ContextReadRequest::CounterFinal { key }
                | ContextReadRequest::CounterTotal { key } => {
                    let name = match key {
                        crate::entities::counter::CounterKey::Page => {
                            "the page counter".to_owned()
                        }
                        _ => format!(
                            "`{}`",
                            repr::repr_value(&Value::Counter(
                                crate::entities::counter::Counter { key: key.clone() }
                            ))
                        ),
                    };
                    (name, true)
                }
                ContextReadRequest::StateGet { state }
                | ContextReadRequest::StateDisplay { state }
                | ContextReadRequest::StateAt { state, .. }
                | ContextReadRequest::StateFinal { state } => (
                    format!(
                        "`state({})`",
                        repr::repr_value(&Value::Str(state.key.clone()))
                    ),
                    false,
                ),
                ContextReadRequest::CounterFold { .. }
                | ContextReadRequest::CounterResolve { .. }
                | ContextReadRequest::CounterLegacyAt { .. }
                | ContextReadRequest::CounterLegacyFinal { .. }
                | ContextReadRequest::StateResolveLabel { .. }
                | ContextReadRequest::StateLegacyAt { .. }
                | ContextReadRequest::StateLegacyFinal { .. }
                | ContextReadRequest::Query { .. }
                | ContextReadRequest::Locate { .. }
                | ContextReadRequest::Here
                | ContextReadRequest::LocationPage { .. }
                | ContextReadRequest::LocationPosition { .. }
                | ContextReadRequest::LocationPageNumbering { .. }
                | ContextReadRequest::OutlineEntryPage { .. } => continue,
                ContextReadRequest::OutlineEntryIndented { .. } => continue,
            };
            let projections: Vec<_> = history
                .iter()
                .map(|snapshot| self.replay_context_read(read, snapshot, engine))
                .collect();
            let last = projections.len() - 1;
            if projections[last - 1].observation_relation(&projections[last])
                != ObservationRelation::Different
            {
                continue;
            }
            let mut hint = String::from("the following values were observed:");
            for (index, projection) in projections.iter().enumerate() {
                let iteration = if index == last {
                    "final".to_owned()
                } else {
                    format!("run {}", index + 1)
                };
                let rendered = match projection {
                    Ok(Value::Array(values)) if counter => {
                        values.iter().map(repr::repr_value).collect::<Vec<_>>().join(", ")
                    }
                    Ok(value) if counter => repr::repr_value(value),
                    Ok(value) => format!("`{}`", repr::repr_value(value)),
                    Err(_) => "(errored)".to_owned(),
                };
                hint.push_str(&format!("\n- {iteration}: {rendered}"));
            }
            let mut diagnostic = SourceDiagnostic::warning(
                read.span,
                format!("value of {name} did not converge"),
            )
            .with_hint(hint);
            if !counter {
                diagnostic = diagnostic
                    .with_hint("see https://typst.app/help/state-convergence for help");
            }
            diagnostics.push(diagnostic);
        }
        Ok(diagnostics)
    }
}

/// Contexto de execução partilhado durante eval().
///
/// Limite de segurança para prevenir loops infinitos:
/// - `max_loop_iterations`: limite total global de iterações. Um contador
///   local por loop permite "loop-bombing" (milhares de loops pequenos que
///   colectivamente travam o motor). Counter global impede isso: 1.000.000
///   iterações falham em segundos independentemente da distribuição.
///
/// A profundidade de chamadas **não** é verificada aqui — é verificada pelo
/// `Route<'a>` através de `route.check_call_depth()` em `apply_closure`
/// (Passo 93, ADR-0033 paridade com vanilla, `MAX_CALL_DEPTH = 80`). O
/// campo antigo `depth`/`max_call_depth`/`enter_call`/`leave_call` foi
/// removido (DEBT-45 parcialmente pago).
///
/// A rota de compilação (`Route<'a>`) **não** é campo do contexto — é
/// passada como parâmetro `route: Tracked<'r, Route<'r>>` às funções
/// `eval_*` que participam na recursão. Paridade estrutural com o vanilla
/// e primeira aplicação concreta da ADR-0036 (atomização progressiva,
/// Passo 92). O campo `route: Vec<FileId>` + API `with_route_id` do Passo
/// 90 foram eliminados no Passo 92 (DEBT-44 fechado).
///
/// A cadeia de estilos (`StyleChain`) **também não** é campo do contexto
/// desde o Passo 94 — propaga-se como `&mut StyleChain` nas funções
/// `eval_*`. Cada bloco de scoping (`CodeBlock`, `ContentBlock`,
/// `Strong`/`Emph`/`Heading`, corpo de closure) cria uma cópia local
/// (`let mut local_styles = styles.clone()` ou `styles.push(delta)`),
/// eliminando o antigo par save/restore sobre um campo partilhado.
/// Segunda aplicação concreta da ADR-0036.
pub struct EvalContext {
    context_reads: RefCell<ContextReads>,
    pub target: EvalTarget,
    pub features: crate::entities::compiler_features::Features,
    // ADR-0036 Regra 4: contador monotónico global — limite de segurança
    // anti-loop-bombing, independente do fluxo de controlo.
    pub loop_iterations: usize,
    // ADR-0036 Regra 4: limite estático — configuração da execução, sem
    // semântica de fluxo.
    pub max_loop_iterations: usize,
    // ADR-0036 Regra 4: alocador monotónico para IDs de ShowRule (Passo 70)
    // — gera valores únicos durante a sessão de eval, não depende de fluxo.
    //
    // Ficaram fora do contexto em passos anteriores (todos como parâmetros
    // explícitos das funções `eval_*`, agora agregados em `Engine<'a>` no
    // Passo 109, ADR-0044):
    // - `world` (Passo 109) — `&'a dyn World` em `Engine`.
    // - `route` (Passo 92) — `Tracked<'r, Route<'r>>`.
    // - `styles` (Passo 94) — `&mut StyleChain`.
    // - `show_rules` + `active_guards` (Passo 95).
    // - `current_file` + `figure_numbering` (Passo 98).
    // - `sink` (Passo 107).
    pub next_rule_id: crate::entities::show::RuleId,

    /// Snapshot do `TagIntrospector` da iteração de fixpoint anterior
    /// (P174 / M7 sub-passo 1). Default: `TagIntrospector::empty()` —
    /// primeira iteração não vê resultados anteriores. `run_fixpoint`
    /// actualiza este field entre iterações; features stdlib P175+
    /// (`query`, `here`, `counter.at`) leem daqui.
    ///
    /// **Read-only no eval**: stdlib lê, nunca escreve. Mutação
    /// exclusiva por `run_fixpoint`.
    pub introspector: crate::entities::introspector::TagIntrospector,

    /// **P208B (M9c)** — `Location` "actual" disponível durante eval,
    /// para suportar stdlib `here()` (P208B) e `locate()` (P208C).
    ///
    /// **Infra minimal**: `Default = None`. Cristalino single-pass +
    /// fixpoint não avança `current_location` automaticamente no eval
    /// walk (divergência arquitectónica vs vanilla `Tracked<Context>`
    /// per P205A.div-1). Caller que conhece a Location actual (ex.:
    /// futuro show-rule para `Content::Context` block análogo a
    /// vanilla `ContextElem`, ou tests sintéticos) escreve este field
    /// directamente via `with_current_location` antes de invocar
    /// eval/stdlib. `here()` lê este field e devolve
    /// `Value::Location(loc)`; se `None`, erro contextual coerente.
    ///
    /// Mecanismo de captura no eval walk (sub-mecanismo i avançado)
    /// fica deferred — emerge naturalmente quando `Content::Context`
    /// block for materializado (sub-passo dedicado pós-P208).
    pub current_location: Option<crate::entities::location::Location>,

    /// **P350c — flag de "erro completo" (capacidade interna)**. Quando ligada,
    /// o erro de recursão de `#show` (teto, `apply_show_rules`) ganha um **3º hint**
    /// classificando **cíclico** (uma morfologia do caminho repetiu — fato medido
    /// pelo `==` do P345) ou **não-convergente** (teto sem repetição). A **mensagem
    /// base** e os 2 hints do vanilla **não mudam**; o 3º hint só aparece com a flag.
    /// **Caminho quente intacto**: o histórico de morfologias só é alocado quando
    /// esta flag está ligada (atrás do `if`). **L1 não lê env** — recebe o booleano
    /// já resolvido (via `eval_with_full_error`; origem em `RunIntent`, fio L4→L1
    /// interno + parsing CLI = débito P350c). Default `false` (= comportamento
    /// byte-idêntico ao vanilla).
    pub full_error: bool,

    /// **P498 — separação entre conteúdo original (para introspecção) e output
    /// de show-rules (para layout/render)**. Quando `false`, `intercept_content`
    /// não aplica show-rules, produzindo a árvore original de elementos locatable.
    /// O entrypoint `eval` corre duas passagens: uma com `false` (captura original)
    /// e outra com `true` (render real). Default `true`.
    pub apply_show_rules: bool,

    /// **P506 — indica que o eval está a correr dentro da expansão de um
    /// `context { ... }`. Quando `true`, métodos `.get()` e `.display()` de
    /// `state`/`counter` podem consultar o introspector e a localização actual.
    pub in_context: bool,

    /// **P506 — contador monotónico para IDs de `ContextBlock`. Garante
    /// identificadores estáveis entre a criação em eval e a expansão
    /// pós-introspecção.
    pub next_context_id: u64,

    /// **P429 (DEBT-63)** — styles CSL resolvidos em eval time, indexados pela
    /// chave determinística do `BibliographyElem` correspondente. Transporta-se
    /// para o `Module` no fim do eval e depois para o `BibStore` do
    /// `TagIntrospector` no pipeline (L3), evitando que o elemento guarde cache
    /// de estado computado.
    pub bibliography_styles: HashMap<u64, Arc<IndependentStyle>>,

    /// **P536** — metadados do documento definidos por `#set document(...)`.
    /// Transporta-se para o `Module` no fim do eval e depois para o
    /// exportador PDF (`/Info`).
    pub document_info: DocumentInfo,

    /// **P635 — evento de controlo de fluxo activo**. Equivalente a `vm.flow`
    /// do vanilla (`typst-eval/src/vm.rs:20`). Propagado de `eval_expr` para
    /// ciclos, funções e o entrypoint.
    pub flow: Option<FlowEvent>,
}

impl EvalContext {
    pub fn new() -> Self {
        Self {
            context_reads: RefCell::new(ContextReads::new()),
            target: EvalTarget::Paged,
            features: crate::entities::compiler_features::Features::default(),
            loop_iterations: 0,
            max_loop_iterations: 1_000_000,
            next_rule_id: 0,
            introspector: crate::entities::introspector::TagIntrospector::empty(),
            current_location: None,
            full_error: false,
            apply_show_rules: true,
            in_context: false,
            next_context_id: 0,
            bibliography_styles: HashMap::new(),
            document_info: DocumentInfo::empty(),
            flow: None,
        }
    }

    /// **P506** — gera um ID estável para `ContextBlockElem`.
    pub fn next_context_id(&mut self) -> u64 {
        let id = self.next_context_id;
        self.next_context_id += 1;
        id
    }

    /// **P429 (DEBT-63)** — regista o style CSL resolvido para o
    /// `BibliographyElem` indicado, usando a sua chave determinística.
    pub fn register_bibliography_style(
        &mut self,
        elem: &BibliographyElem,
        style: Arc<IndependentStyle>,
    ) {
        self.bibliography_styles.insert(elem.style_key(), style);
    }

    /// **P208B (M9c)** — Setter conveniente para `current_location`.
    /// Usado em tests sintéticos e por consumers futuros que conhecem
    /// a Location actual antes de invocar eval/stdlib `here()`.
    pub fn with_current_location(
        mut self,
        location: crate::entities::location::Location,
    ) -> Self {
        self.current_location = Some(location);
        self
    }

    /// Incrementa o contador de iterações e retorna Err se o limite foi atingido.
    pub fn tick_loop(&mut self, span: Span) -> SourceResult<()> {
        self.loop_iterations += 1;
        if self.loop_iterations > self.max_loop_iterations {
            Err(vec![SourceDiagnostic::error(
                span,
                format!(
                    "limite de iterações de loop atingido ({}) — \
                     possível loop infinito",
                    self.max_loop_iterations
                ),
            )])
        } else {
            Ok(())
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EvalTarget {
    Paged,
    Html,
    Bundle,
}

/// Avalia um ficheiro Typst e retorna o módulo resultante (flag de erro completo
/// **desligada** — comportamento byte-idêntico ao vanilla). **Delegado** de
/// `eval_with_full_error` (P350c): mantém a assinatura estável para os ~165 callers
/// (produção L3 + testes) — a capacidade da flag entra pela sibling, não por aqui.
pub fn eval(
    routines: &Routines,
    world: &dyn World,
    traced: Tracked<Traced>,
    sink: TrackedMut<Sink>,
    route: Tracked<Route>,
    source: &Source,
    registry: &crate::entities::element_registry::ElementRegistry,
) -> SourceResult<Module> {
    eval_with_full_error(routines, world, traced, sink, route, source, registry, false)
}

/// Avalia uma expressão Typst isolada em modo code e scope fresco.
pub fn eval_expression(
    world: &dyn World,
    expression: &str,
) -> (SourceResult<Value>, Vec<SourceDiagnostic>) {
    eval_expression_with_features(
        world,
        expression,
        crate::entities::compiler_features::Features::default(),
    )
}

/// Disponibiliza a Source já analisada, sem modificar o World chamador.
struct ExpressionWorld<'a> {
    inner: &'a dyn World,
    source: &'a Source,
}

impl World for ExpressionWorld<'_> {
    fn library(&self) -> &Library {
        self.inner.library()
    }
    fn book(&self) -> &FontBook {
        self.inner.book()
    }
    fn main(&self) -> FileId {
        self.inner.main()
    }
    fn source(&self, id: FileId) -> FileResult<Source> {
        if id == self.source.id() {
            Ok(self.source.clone())
        } else {
            self.inner.source(id)
        }
    }
    fn file(&self, id: FileId) -> FileResult<Bytes> {
        self.inner.file(id)
    }
    fn resolve_path(&self, file: FileId, path: &str) -> Result<RootedPath, String> {
        self.inner.resolve_path(file, path)
    }
    fn read_path(&self, path: &RootedPath) -> Result<Arc<Vec<u8>>, String> {
        self.inner.read_path(path)
    }
    fn include_path(&self, path: &RootedPath) -> Result<Source, String> {
        self.inner.include_path(path)
    }
    fn read_bytes(&self, file: FileId, path: &str) -> Result<Arc<Vec<u8>>, String> {
        self.inner.read_bytes(file, path)
    }
    fn include_source(&self, file: FileId, path: &str) -> Result<Source, String> {
        self.inner.include_source(file, path)
    }
    fn resolve_package(&self, spec: &PackageSpec) -> Result<Source, String> {
        self.inner.resolve_package(spec)
    }
    fn inputs(&self) -> SysInputs {
        self.inner.inputs()
    }
    fn plugin_host(&self) -> Option<Arc<dyn crate::contracts::plugin_host::PluginHost>> {
        self.inner.plugin_host()
    }
    fn font(&self, index: usize) -> Option<Font> {
        self.inner.font(index)
    }
    fn candidates_for_char(&self, c: char) -> Vec<usize> {
        self.inner.candidates_for_char(c)
    }
    fn today(
        &self,
        offset: Option<crate::entities::duration::Duration>,
    ) -> Option<Datetime> {
        self.inner.today(offset)
    }
}

pub fn eval_expression_with_features(
    world: &dyn World,
    expression: &str,
    features: crate::entities::compiler_features::Features,
) -> (SourceResult<Value>, Vec<SourceDiagnostic>) {
    eval_expression_with_features_and_introspector(
        world,
        expression,
        features,
        &crate::entities::introspector::TagIntrospector::empty(),
    )
}

/// Avalia uma expressão com o snapshot contextual de um documento compilado.
pub fn eval_expression_with_features_and_introspector(
    world: &dyn World,
    expression: &str,
    features: crate::entities::compiler_features::Features,
    introspector: &crate::entities::introspector::TagIntrospector,
) -> (SourceResult<Value>, Vec<SourceDiagnostic>) {
    let inputs = world.inputs();
    let mut global = Scope::new();
    let stdlib = make_stdlib_with_features(&inputs, features);
    global.define("std", Value::Module(Module::new("global", stdlib.clone())));
    for (name, binding) in stdlib.iter() {
        global.define(name, binding.value().clone());
    }
    for (name, value) in crate::compiler::stdlib::predefined_color_bindings() {
        global.define(name.as_str(), value);
    }
    global.define(
        "text",
        Value::Func(Func::native("text", crate::compiler::stdlib::native_text)),
    );
    let library = Library::with_global(global);
    let mut scopes = Scopes::new(Some(&library));
    let mut ctx = EvalContext::new();
    ctx.features = features;
    ctx.introspector = introspector.clone();
    let mut styles = StyleChain::default_chain();
    let mut show_rules: Arc<[ShowRule]> = Arc::from([]);
    let mut active_guards = Vec::new();
    let current_file = world.main();
    let source = Source::new_with_parser(
        current_file,
        expression.to_string(),
        crate::compiler::parse::parse_code,
    );
    let expression_world = ExpressionWorld { inner: world, source: &source };
    let route = Route::root().with_id(current_file);
    let fixed_metrics = FixedMetrics;
    let mut sink = Sink::new();
    let result = {
        let mut tracked_sink = sink.track_mut();
        let mut engine = Engine {
            world: &expression_world,
            font_metrics: &fixed_metrics,
            route: route.track(),
            styles: &mut styles,
            show_rules: &mut show_rules,
            active_guards: &mut active_guards,
            current_file,
            sink: &mut tracked_sink,
        };
        if source.root().erroneous() {
            Err(source
                .root()
                .errors()
                .into_iter()
                .map(|error| {
                    let mut diagnostic =
                        SourceDiagnostic::error(error.span, error.message.to_string());
                    diagnostic.hints =
                        error.hints.iter().map(|hint| hint.to_string()).collect();
                    diagnostic
                })
                .collect())
        } else {
            (|| -> SourceResult<Value> {
                let mut last = Value::None;
                for child in source.root().children() {
                    if let Some(expr) = Expr::from_untyped(child) {
                        last = eval_expr(expr, &mut scopes, &mut ctx, &mut engine)?;
                    }
                }
                Ok(last)
            })()
        }
    };
    (result, sink.into_diagnostics())
}

/// Como [`eval`], mas com a flag de **erro completo** (P350c) explícita. Quando
/// `full_error` está ligada, o erro de recursão de `#show` ganha um 3º hint
/// classificando cíclico/não-convergente (ver [`EvalContext::full_error`]). A
/// origem do booleano é `RunIntent` (L2), via o caminho **interno** de L3 — a
/// assinatura **pública** de L3 (`compile_to_pdf_bytes`) **não** muda; o parsing
/// da CLI + o fio `RunIntent`→L3-interno são **débito** (P350c). L1 recebe o
/// booleano já resolvido (não lê env).
///
/// Travessia AST parcial: literais, Ident, Let, CodeBlock, Binary, Unary,
/// Conditional, WhileLoop, ForLoop, Closure, FuncCall. **Invariante**: não importa
/// nada de `03_infra`; acesso ao world sempre via `World` (L1).
pub fn eval_with_full_error(
    _routines: &Routines,
    world: &dyn World,
    _traced: Tracked<Traced>,
    mut sink: TrackedMut<Sink>,
    _route: Tracked<Route>,
    source: &Source,
    // Lote F-3 inc-2: o threading registry→escopo que o F-1 deferiu. Elementos
    // de utilizador registados entram no escopo como funções (`#name(args)`).
    // Em produção é vazio até pacotes registarem elementos; testes injetam.
    registry: &crate::entities::element_registry::ElementRegistry,
    // P350c: flag de erro completo, já resolvida (origem `RunIntent`; L1 não lê env).
    full_error: bool,
) -> SourceResult<Module> {
    eval_with_full_error_and_target(
        _routines,
        world,
        _traced,
        sink,
        _route,
        source,
        registry,
        full_error,
        EvalTarget::Paged,
    )
}

pub fn eval_with_full_error_and_target(
    _routines: &Routines,
    world: &dyn World,
    _traced: Tracked<Traced>,
    mut sink: TrackedMut<Sink>,
    _route: Tracked<Route>,
    source: &Source,
    registry: &crate::entities::element_registry::ElementRegistry,
    full_error: bool,
    target: EvalTarget,
) -> SourceResult<Module> {
    eval_with_full_error_target_and_features(
        _routines,
        world,
        _traced,
        sink,
        _route,
        source,
        registry,
        full_error,
        target,
        crate::entities::compiler_features::Features::default(),
    )
}

pub fn eval_with_full_error_target_and_features(
    _routines: &Routines,
    world: &dyn World,
    _traced: Tracked<Traced>,
    mut sink: TrackedMut<Sink>,
    _route: Tracked<Route>,
    source: &Source,
    registry: &crate::entities::element_registry::ElementRegistry,
    full_error: bool,
    target: EvalTarget,
    features: crate::entities::compiler_features::Features,
) -> SourceResult<Module> {
    let root = source.root();

    // **P786a** — propagação integral de erros de sintaxe (revoga a
    // filtragem selectiva de P648/P649, que só propagava
    // `InvalidHexNumber`/`InvalidUnicodeCodepoint`). O survey empírico
    // deste passo (20 construções válidas, teste
    // `p786a_valid_constructs_without_error_nodes`) mostrou zero falsos
    // positivos no parser actual — `#` em código é erro genuíno (o
    // vanilla 0.15.0 também o rejeita, exit 1 + 2 hints). Warnings de
    // markup (`NoTextWithin*`, produzidos em `parse/markup.rs`) seguem
    // para o sink como warning e **não abortam** (T1 — paridade vanilla:
    // `warning: no text within stars` + hint, exit 0). Hints dos
    // `SyntaxError` são propagados em ambos os caminhos.
    let mut syntax_errors: Vec<SourceDiagnostic> = Vec::new();
    for e in root.errors() {
        let is_warning = matches!(
            e.kind,
            SyntaxErrorKind::NoTextWithinStars | SyntaxErrorKind::NoTextWithinUnderscores
        );
        if is_warning {
            sink.warn_note(
                e.span,
                e.message.as_str(),
                e.hints.first().map_or("", |h| h.as_str()),
            );
        } else {
            let mut diag = SourceDiagnostic::error(e.span, e.message.to_string());
            for h in &e.hints {
                diag = diag.with_hint(h.as_str());
            }
            syntax_errors.push(diag);
        }
    }
    if !syntax_errors.is_empty() {
        return Err(syntax_errors);
    }

    // Passo 106 (ADR-0043): canal de warnings activo. Pilot: emitir nota
    // quando o ficheiro fonte está vazio. Prova de vida do canal — o
    // caller lê `sink.into_diagnostics()` após este retorno.
    if source.text().is_empty() {
        sink.warn_note(
            crate::entities::span::Span::detached(),
            "ficheiro vazio: sem conteúdo",
            "",
        );
    }

    // P498 — passagem dupla do eval:
    // 1. `apply_show_rules = false`: produz o conteúdo original (pré-show-rules)
    //    para alimentar a introspecção. Espelha o modelo vanilla, onde o
    //    Introspector vê os elementos antes da realização das show-rules.
    // 2. `apply_show_rules = true`: produz o output renderizado para layout/PDF.
    //
    // O scope, as definições de stdlib e as show-rules registadas são idênticos
    // nas duas passagens; só a aplicação das show-rules difere.
    //
    // P694 — `sys.inputs` vem do ambiente via `World::inputs()` (default vazio);
    // lido uma vez e partilhado pelas duas passagens.
    let inputs = world.inputs();
    let mut run_pass = |apply_show_rules: bool,
                        pass_sink: &mut TrackedMut<Sink>|
     -> SourceResult<(
        Value,
        Scope,
        HashMap<u64, Arc<IndependentStyle>>,
        DocumentInfo,
    )> {
        let mut ctx = EvalContext::new();
        ctx.target = target;
        ctx.features = features;
        ctx.full_error = full_error; // P350c: flag resolvida (default false via `eval`)
        ctx.apply_show_rules = apply_show_rules; // P498

        // Route raiz com o FileId do ficheiro principal — primeira aplicação da
        // ADR-0036 (Passo 92), agora campo do Engine (ADR-0044, Passo 109).
        let route = Route::root().with_id(source.id());
        let mut styles = StyleChain::default_chain();
        let mut show_rules: Arc<[ShowRule]> = Arc::from([]);
        let mut active_guards: Vec<RuleId> = Vec::new();
        let current_file = source.id();

        // P772n — stdlib/cores/`std`/`text`/elementos de utilizador deixam de
        // ser achatados em `scopes.top` (o que os tornava mutáveis sem erro,
        // P772l §2.3). Constrói-se um `Scope` próprio, embrulhado em
        // `Library::with_global`, e passado como `base` — só alcançável por
        // leitura (`Scopes::get`), nunca por `Scopes::get_mut`. Ver
        // `rules/eval.md` §P772n.
        let mut global = Scope::new();
        let stdlib = make_stdlib_with_features(&inputs, features);
        // P709 — `std`: clone independente da stdlib, tirado ANTES de ser
        // espalhada em `global`, dá acesso à versão não-sombreada mesmo que
        // o documento redefina `length`/`calc`/etc. (paridade vanilla,
        // `Library::std = Binding::detached(global.clone())`). Sombreável
        // como qualquer outro nome (medido: `#let std = "oops"` funciona
        // no vanilla) — por isso um binding normal, sem mecanismo especial.
        global.define("std", Value::Module(Module::new("global", stdlib.clone())));
        for (name, binding) in stdlib.iter() {
            global.define(name, binding.value().clone());
        }
        // P492 — cores predefinidas (red, blue, green, ...) como atalhos globais.
        for (name, value) in crate::compiler::stdlib::predefined_color_bindings() {
            global.define(name.as_str(), value);
        }
        // P492 — constructor `text(...)` no scope global (usado em show-rules, etc.).
        global.define(
            "text",
            Value::Func(crate::entities::func::Func::native(
                "text",
                crate::compiler::stdlib::native_text,
            )),
        );
        // Lote F-3 inc-2: elementos de utilizador registados entram no escopo como
        // funções (`#name(args)` → `Content::Dynamic` via o construtor do registry).
        // Mesmo escopo base que os nativos (document-wide); `#set`/`#show` léxicos
        // por cima seguem o padrão `local_styles` (F-2).
        for name in registry.names() {
            if let Some(ctor) = registry.ctor(name) {
                global.define(
                    name.as_str(),
                    Value::Func(Func::element(name.as_str(), ctor)),
                );
            }
        }
        let library = Library::with_global(global);
        let mut scopes = Scopes::new(Some(&library));

        // ADR-0044 (Passo 109): agregar os 8 campos num `Engine<'_>` e passar
        // `&mut engine` às funções internas em vez de 8 parâmetros individuais.
        // Reborrow do `sink` encurta o lifetime inner do `TrackedMut` ao da
        // stack frame local, permitindo que `Engine<'a>` tenha um único `'a`.
        let fixed_metrics = FixedMetrics;
        let mut local_sink = TrackedMut::reborrow_mut(&mut *pass_sink);
        let mut engine = Engine {
            world,
            font_metrics: &fixed_metrics,
            route: route.track(),
            styles: &mut styles,
            show_rules: &mut show_rules,
            active_guards: &mut active_guards,
            current_file,
            sink: &mut local_sink,
        };

        let content_val = eval_markup(root, &mut scopes, &mut ctx, &mut engine)?;
        if let Some(flow) = ctx.flow {
            return Err(vec![flow.forbidden()]);
        }
        let module_scope = scopes.exit();
        Ok((content_val, module_scope, ctx.bibliography_styles, ctx.document_info))
    };

    // Passo 1: captura do conteúdo original (pré-show-rules).
    // Usa o mesmo sink principal para que warnings emitidos antes de um erro
    // cheguem ao caller (dedup por (span, message) previne duplicação com passo 2).
    let (original_val, _, _, _) = run_pass(false, &mut sink)?;
    let original_content = match original_val {
        Value::Content(c) => Some(c),
        _ => None,
    };

    // Passo 2: eval normal (com show-rules) — este é o resultado oficial.
    let (rendered_val, module_scope, bibliography_styles, document_info) =
        run_pass(true, &mut sink)?;
    let rendered_content = match rendered_val {
        // **P537b** — ligar `#set page(columns: N)` ao consumer `Content::Columns`.
        Value::Content(c) => Some(c.wrap_page_columns()),
        _ => None,
    };

    let mut module = Module::new(source.id().into_raw().get().to_string(), module_scope);
    module.set_content(rendered_content);
    module.set_introspection_content(original_content);
    // P429 (DEBT-63): transportar styles resolvidos do eval para o Module,
    // de onde o pipeline os injectará no BibStore do TagIntrospector.
    module.set_bibliography_styles(bibliography_styles);
    // P536: transportar metadados do documento para o Module.
    module.set_document_info(document_info);
    Ok(module)
}

pub(crate) fn eval_markup(
    node: &SyntaxNode,
    scopes: &mut Scopes<'_>,
    ctx: &mut EvalContext,
    engine: &mut Engine<'_>,
) -> SourceResult<Value> {
    eval_markup_impl(node, scopes, ctx, engine, true)
}

/// Um ContentBlock ainda é um valor: conserva os espaços brutos até entrar
/// num fluxo de markup. Os demais corpos são realizados no próprio escopo.
fn eval_markup_impl(
    node: &SyntaxNode,
    scopes: &mut Scopes<'_>,
    ctx: &mut EvalContext,
    engine: &mut Engine<'_>,
    normalize_spaces: bool,
) -> SourceResult<Value> {
    let mut parts: Vec<Content> = Vec::new();
    // P1494: snapshots por ocorrência, sem retroatividade de regras textuais.
    let mut textual_snapshots: Vec<rules::TextualSnapshot> = Vec::new();

    // Passo 445: smart quotes context-aware em markup.
    // O lexer marca `"` e `'` como `SyntaxKind::SmartQuote`; o eval decide
    // open/close/apostrophe com base nos caracteres adjacentes e no `text.lang`.
    // Aspas duplas e simples são resolvidas independentemente.
    let src = node.clone().into_text();
    let src_str = src.as_str();
    let mut byte_offset = 0_usize;

    fn is_opening_context(c: Option<char>) -> bool {
        c.is_none()
            || c.unwrap().is_whitespace()
            || matches!(c.unwrap(), '(' | '[' | '{' | '<')
    }
    fn is_word_char(c: Option<char>) -> bool {
        c.is_some_and(|c| c.is_alphanumeric())
    }

    // β1 fatia 1 (P339, §3a.8) + F-item3 (P368, §3a.11): snapshot do **delta
    // completo** à entrada deste corpo, para detectar um `#set` local (numbering,
    // prop de elemento de usuário, ou estilo tipado como `text.bold`) e embrulhar
    // o resto do escopo léxico num `Content::Styled` (transporte aditivo
    // `StyledElem`-scoped). Generaliza o antigo snapshot só-de-custom.
    // P373 (§3a.14): correção do transporte — **wraps aninhados por escopo léxico**
    // (espelho do `styled_with_map` por-`#set` do vanilla, recursivo). Rastreia cada
    // **fronteira de `#set`** (mudança do delta vs o estado corrente) com o delta
    // QUE ESTE `#set` introduziu; no fim, fold de dentro para fora produz o
    // aninhamento. Conserta o bug single-wrap-final-collapse (P372): `#set`
    // sequenciais da mesma chave deixam de colapsar para o valor final.
    // P431 (DEBT-50): o delta agora inclui origem (`from_strong`/`from_emph`),
    // propagada pelo `StyleDelta` e embrulhada via `diff_styles`.
    let snap_delta = engine.styles.collapse();
    let mut running_delta = snap_delta.clone();
    let mut boundaries: Vec<(usize, crate::entities::style::Styles)> = Vec::new();

    for child in node.children() {
        let snapshot = rules::TextualSnapshot::capture(engine);
        match child.kind() {
            SyntaxKind::Text => {
                // F-5b fatia 2 (P373): o render não é mais assado no node — viaja
                // na chain (custom), resolvido no layout.
                let text_node = Content::Text(child.text().as_str().into());
                append_markup_sequence(
                    &mut parts,
                    rules::intercept_text_element(text_node, ctx, engine)?,
                );
            }
            // Passo 445 — SmartQuote: emite glyph localizado consoante
            // open/close (contexto adjacente) e `text.lang`/`smartquote` activo.
            SyntaxKind::SmartQuote => {
                let raw = child.text();
                let is_double = raw.as_str() == "\"";
                let lang = engine.styles.lang();

                let enabled = match engine.styles.custom("smartquote.enabled") {
                    Some(Value::Bool(b)) => *b,
                    _ => true,
                };

                let quote_node = if !enabled {
                    Content::Text(raw.as_str().into())
                } else {
                    let off = byte_offset;
                    let prev = src_str[..off].chars().last();
                    let next = src_str[off + child.len()..].chars().next();
                    let alternative = match engine.styles.custom("smartquote.alternative")
                    {
                        Some(Value::Bool(value)) => *value,
                        _ => false,
                    };
                    let configured = engine
                        .styles
                        .custom("smartquote.quotes")
                        .map(|value| {
                            crate::compiler::lang::quotes::parse_smartquote_quotes(
                                value,
                                child.span(),
                            )
                        })
                        .transpose()?;
                    let pair = crate::compiler::lang::quotes::resolve_smartquote_pair(
                        lang.as_ref(),
                        alternative,
                        configured.as_ref(),
                        is_double,
                    );
                    let glyph = if !is_double && is_word_char(prev) && is_word_char(next)
                    {
                        pair.close
                    } else if is_opening_context(prev) {
                        pair.open
                    } else {
                        pair.close
                    };
                    Content::Text(glyph)
                };
                append_markup_sequence(
                    &mut parts,
                    rules::intercept_text_element(quote_node, ctx, engine)?,
                );
            }
            SyntaxKind::Space => parts.push(if child.text().as_str().contains('\n') {
                Content::SpaceFromNewline
            } else {
                Content::Space
            }),
            // P622: quebra de parágrafo semântica — distinta de Space.
            SyntaxKind::Parbreak => parts.push(Content::Parbreak),
            k if k.is_trivia() => continue,
            // Passo 56 — associação retroactiva: <label> envolve o nó precedente.
            // O parser expõe <label> como nó irmão (não filho) do nó anterior.
            // Entre o nó alvo e a label pode haver Space — salta-os para encontrar
            // o elemento real, re-insere-os a seguir ao Labelled.
            SyntaxKind::Label => {
                if let Some(label_ast) = child.cast::<AstLabel<'_>>() {
                    let name = label_ast.get().to_string();
                    // Recolher espaços finais para re-inserir após o Labelled.
                    let mut trailing: Vec<Content> = Vec::new();
                    while matches!(
                        parts.last(),
                        Some(Content::Space | Content::SpaceFromNewline | Content::Empty)
                    ) {
                        trailing.push(parts.pop().unwrap());
                    }
                    if let Some(last) = parts.pop() {
                        // P791 — o wrapper Label também viaja pela maquinaria
                        // de show rules (apenas regras `Selector::Label` —
                        // o corpo já foi interceptado no seu próprio ponto).
                        let labelled = Content::label_auto(name, last);
                        parts.push(rules::intercept_labelled(labelled, ctx, engine)?);
                        trailing.reverse();
                        parts.extend(trailing);
                    } else {
                        // P802 — label órfã (sem elemento anterior anexável):
                        // warning, paridade vanilla `typst-eval/markup.rs`
                        // ("label `<x>` is not attached to anything"). A label
                        // é descartada (como no vanilla); os espaços recolhidos
                        // são re-inseridos para não se perderem.
                        engine.sink.warn_note(
                            child.span(),
                            &format!("label `<{name}>` is not attached to anything"),
                            "",
                        );
                        trailing.reverse();
                        parts.extend(trailing);
                    }
                }
            }
            _ => {
                if let Some(expr) = Expr::from_untyped(child) {
                    let value = eval_expr(expr, scopes, ctx, engine)?;
                    if let Some(content) = value_to_display_content(value) {
                        append_markup_sequence(&mut parts, content);
                    }
                }
            }
        }
        textual_snapshots.resize(parts.len(), snapshot);

        byte_offset += child.len();

        // P373/P431: fronteira de `#set` — o delta completo mudou vs o estado
        // corrente. Regista `(parts.len(), Styles do delta introduzido)` e actualiza
        // o corrente. (Só o `#set` muta `engine.styles` neste loop; o `#set` não
        // produz `part`, logo `parts.len()` é o início da cauda que este `#set`
        // escopa.)
        let cur = engine.styles.collapse();
        if cur != running_delta {
            let styles = cur.diff_styles(&running_delta);
            boundaries.push((parts.len(), styles));
            running_delta = cur;
        }
    }

    // P373: fold de dentro para fora — cada fronteira embrulha a sua cauda
    // (`parts[idx..]`) no delta do seu `#set`, produzindo o aninhamento
    // `Styled(A, [X, Styled(B, [Y])])` (escopo léxico, fiel ao vanilla). `#set`
    // único → 1 fronteira → 1 wrap = comportamento de antes (content-preserving).
    rules::realize_textual_parts(
        &mut parts,
        &textual_snapshots,
        &boundaries,
        ctx,
        engine,
        normalize_spaces,
    )?;
    for (idx, styles) in boundaries.into_iter().rev() {
        let tail = parts.split_off(idx);
        parts.push(Content::styled(Box::new(Content::sequence(tail)), styles));
    }

    // P863: as show rules de elemento (NodeKind) são interceptadas nos pontos
    // de construção do conteúdo, mas os parágrafos são sintetizados a partir de
    // vários nós de texto/`Space`/`Parbreak`. Aplica-se apenas as regras
    // `NodeKind::Par` ao fluxo montado, para que `#show par: ...` possa realizar
    // e transformar os parágrafos sem re-disparar regras textuais já aplicadas
    // ao grupo normalizado acima.
    Ok(Value::Content(rules::intercept_paragraphs(
        Content::sequence(parts),
        ctx,
        engine,
    )?))
}

/// Sequências interpoladas são transparentes no fluxo de markup. Os filhos
/// retêm a sua origem; um espaço inferido isolado só é decidido quando
/// encontra os vizinhos no corpo que o consome.
fn append_markup_sequence(parts: &mut Vec<Content>, content: Content) {
    match content {
        Content::Sequence(children) => {
            for child in children.iter().cloned() {
                append_markup_sequence(parts, child);
            }
        }
        other => parts.push(other),
    }
}

/// **P545** (extraído em **P780**) — conversão genérica `Value` → `Content`
/// para exibição (interpolação `#{expr}` em markup, e resolução de
/// identificador de variável em modo math — `compiler/eval/math.rs`). `None`
/// = nada a mostrar (`Value::None`, `Value::Counter`, texto vazio) —
/// distinto de `Some(Content::Empty)`, que só ocorre se o próprio
/// `Value::Content` embrulhado já for `Content::Empty` (preserva-se, não
/// se filtra).
///
/// Paridade conceptual com `Value::display()` do vanilla
/// (`typst-eval/src/math.rs::ExprExt::eval_display` chama `.display()`
/// genericamente) — cristalino não tem esse método unificado; esta função
/// é o equivalente inlined.
pub(crate) fn value_to_display_content(value: Value) -> Option<Content> {
    match value {
        Value::Content(c) => Some(c),
        Value::Str(s) => Some(Content::Text(s)),
        // P471 — símbolo Unicode → char como Content::Text.
        Value::Symbol(s) => Some(Content::Text(EcoString::from(s.value))),
        // P506 — state(key, init) → Content::State locatável.
        Value::State(s) => {
            Some(Content::state(s.key.to_string(), s.init.as_ref().clone()))
        }
        // P506 — counter(selector) → nada visível directamente (só via
        // .update()/.step()/.display()).
        Value::Counter(_) => None,
        Value::None => None,
        // P796 — Version usa o `Display` (`to_string()`), não o `repr()`:
        // `#sys.version` → "0.15.0", não "version(0, 15, 0)" (paridade
        // vanilla `Value::display`, `entities/version.md` §8b).
        Value::Version(v) => {
            let text = v.to_string();
            if text.is_empty() {
                None
            } else {
                Some(Content::Text(text.into()))
            }
        }
        // Valores primitivos convertem-se para texto. Int, Float, Bool,
        // Array, Dict, Length, Datetime, etc. usam repr_value.
        other => {
            // **P739C** — display de Float: paridade vanilla (Display de
            // f64 — inteiros exactos sem `.0`: `#(1.0)` → "1", `#(4/2)` →
            // "2", medido). `repr` mantém "1.0" (repr_value inalterado).
            // **P817-D** — display de Decimal: paridade vanilla
            // (`#decimal("1.50")` → "1.50", não `decimal("1.50")` — o repr
            // constructor-form é só para `repr()`, medido nos dois binários).
            let text = match &other {
                Value::Float(f) => format!("{f}"),
                Value::Decimal(d) => d.to_string(),
                _ => crate::compiler::eval::repr::repr_value(&other),
            };
            if text.is_empty() {
                None
            } else {
                Some(Content::Text(text.into()))
            }
        }
    }
}

pub(crate) fn eval_expr(
    expr: Expr<'_>,
    scopes: &mut Scopes<'_>,
    ctx: &mut EvalContext,
    engine: &mut Engine<'_>,
) -> SourceResult<Value> {
    let span = expr.span();
    let previous = ctx.replace_context_read_styles(engine.styles.clone());
    let previous_file = ctx.replace_context_read_file(Some(engine.current_file));
    let previous_rules = ctx.replace_context_read_rules(
        engine.show_rules.clone(),
        engine.active_guards.clone(),
    );
    let result = eval_expr_inner(expr, scopes, ctx, engine).map(|value| match value {
        Value::Func(func) => Value::Func(func.with_diagnostic_span(span)),
        other => other,
    });
    ctx.replace_context_read_styles(previous);
    ctx.replace_context_read_file(previous_file);
    ctx.replace_context_read_rules(previous_rules.0, previous_rules.1);
    result
}

fn eval_expr_inner(
    expr: Expr<'_>,
    scopes: &mut Scopes<'_>,
    ctx: &mut EvalContext,
    engine: &mut Engine<'_>,
) -> SourceResult<Value> {
    match expr {
        Expr::Int(node) => Ok(Value::Int(node.get())),
        Expr::Float(node) => Ok(Value::Float(node.get())),
        Expr::Str(node) => Ok(Value::Str(EcoString::from(node.get()?))),
        Expr::Bool(node) => Ok(Value::Bool(node.get())),
        Expr::None(_) => Ok(Value::None),
        Expr::Auto(_) => Ok(Value::Auto),

        Expr::Ident(ident) => {
            let name = ident.as_str();
            if name == "asset" {
                if let Some(value) = scopes.get(name) {
                    return Ok(value.clone());
                }
                if !ctx
                    .features
                    .contains(crate::entities::compiler_features::Feature::Bundle)
                {
                    return Err(vec![SourceDiagnostic::error(
                        ident.span(),
                        "cannot access variable `asset` because the `bundle` feature is not enabled",
                    )
                    .with_hint("try enabling the `bundle` feature")
                    .with_hint("see https://typst.app/help/compiler-features for more details")]);
                }
            }
            if name == "html"
                && !ctx
                    .features
                    .contains(crate::entities::compiler_features::Feature::Html)
            {
                return Err(vec![SourceDiagnostic::error(
                    ident.span(),
                    "cannot access variable `html` because the `html` feature is not enabled",
                )
                .with_hint("try enabling the `html` feature")
                .with_hint("see https://typst.app/help/compiler-features for more details")]);
            }
            // P772r — hint de subtracção quando o nome contém hífen,
            // paridade vanilla `foundations/scope.rs::unknown_variable`.
            scopes
                .get(name)
                .cloned()
                .ok_or_else(|| vec![bindings::unknown_variable(ident.span(), name)])
        }

        Expr::LetBinding(binding) => bindings::eval_let(binding, scopes, ctx, engine),

        Expr::CodeBlock(code_block) => {
            // Bloco de código — styles e show_rules locais (atomização
            // Passos 94 e 95). `#set`/`#show` dentro do bloco mutam as
            // cópias locais mas não afectam o chamador. Engine
            // reconstruído localmente (ADR-0044, Passo 109).
            let mut local_styles = engine.styles.clone();
            let mut local_show_rules = Arc::clone(engine.show_rules);
            let mut local_sink = TrackedMut::reborrow_mut(&mut *engine.sink);
            let mut output = Value::None;
            // **P772l** — paridade vanilla `ast::CodeBlock::eval`
            // (`typst-eval/src/code.rs:317-323`): o bloco introduz um
            // âmbito léxico próprio via `scopes.enter()`/`exit()`. Sem isto,
            // um `let` interno mutava o âmbito do chamador directamente —
            // medido: `#let x = 1; #{ let x = 2; x }; #x` devolvia `2, 2`
            // em vez de `2, 1` (shadowing vazava para fora do bloco).
            scopes.enter();
            {
                let mut local_engine = Engine {
                    world: engine.world,
                    font_metrics: engine.font_metrics,
                    route: engine.route,
                    styles: &mut local_styles,
                    show_rules: &mut local_show_rules,
                    active_guards: &mut *engine.active_guards,
                    current_file: engine.current_file,
                    sink: &mut local_sink,
                };
                for expr in code_block.body().exprs() {
                    // **P728** — o valor do bloco é o `join` sequencial dos
                    // valores das expressões (paridade vanilla
                    // `typst-eval/src/code.rs:57` + `ops::join`), não só o
                    // da última. Medido: `{ (1,); (2,) }` → `(1, 2)`.
                    let span = expr.span();
                    let value = eval_expr(expr, scopes, ctx, &mut local_engine)?;
                    output = operators::join(output, value)
                        .map_err(|msg| vec![SourceDiagnostic::error(span, msg)])?;
                    if ctx.flow.is_some() {
                        break;
                    }
                }
                // **P740A** — paridade vanilla `warn_for_discarded_content`
                // (`typst-eval/src/code.rs:413-430`): `return` incondicional
                // (flag `conditional == false`) com conteúdo acumulado antes
                // dele emite warning + hint; um segundo hint é adicionado
                // quando o conteúdo descartado contém updates de
                // state/counter (seletor `State|Counter` no vanilla, aqui
                // travessia directa das variants equivalentes). A emissão
                // acontece aqui — antes do chamador tratar o flow —, pelo
                // que o warning coexiste com o erro "cannot return outside
                // of function" (medido no vanilla).
                if let Some(FlowEvent::Return(span, Some(_), false)) = &ctx.flow {
                    if let Value::Content(c) = &output {
                        let hint2 = if content_has_state_or_counter(c) {
                            "state/counter updates are content that must end up in the document to have an effect"
                        } else {
                            ""
                        };
                        local_engine.sink.warn_note2(
                            *span,
                            "this return unconditionally discards the content before it",
                            "try omitting the `return` to automatically join all values",
                            hint2,
                        );
                    }
                }
            }
            scopes.exit();
            Ok(output)
        }

        // **P715** — `Assign`/`AddAssign`/`SubAssign`/`MulAssign`/`DivAssign`
        // não podem avaliar `lhs` como valor (precisam do nome/local para
        // mutar) — intercepta antes do dispatch genérico de operadores.
        // Ver `bindings::eval_assign`.
        Expr::Binary(binary)
            if matches!(
                binary.op(),
                BinOp::Assign
                    | BinOp::AddAssign
                    | BinOp::SubAssign
                    | BinOp::MulAssign
                    | BinOp::DivAssign
            ) =>
        {
            bindings::eval_assign(binary, scopes, ctx, engine)
        }

        // **P728** — short-circuit de `and`/`or` (paridade vanilla
        // `apply_binary` em `typst-eval/src/ops.rs:52-66`): o segundo
        // operando só é avaliado se o primeiro não decidir o resultado.
        // Medido: `false and (1/0 == 0)` → `false` (sem erro de divisão).
        Expr::Binary(binary) if matches!(binary.op(), BinOp::And | BinOp::Or) => {
            let lhs = eval_expr(binary.lhs(), scopes, ctx, engine)?;
            let decided = matches!(
                (binary.op(), &lhs),
                (BinOp::And, Value::Bool(false)) | (BinOp::Or, Value::Bool(true))
            );
            if decided {
                Ok(lhs)
            } else {
                let rhs = eval_expr(binary.rhs(), scopes, ctx, engine)?;
                operators::eval_binary_op(binary.op(), lhs, rhs)
                    .map_err(|msg| vec![SourceDiagnostic::error(binary.span(), msg)])
            }
        }

        Expr::Binary(binary) => {
            let lhs = eval_expr(binary.lhs(), scopes, ctx, engine)?;
            let rhs = eval_expr(binary.rhs(), scopes, ctx, engine)?;
            operators::eval_binary_op(binary.op(), lhs, rhs)
                .map_err(|msg| vec![SourceDiagnostic::error(binary.span(), msg)])
        }

        Expr::Unary(unary) => {
            let operand = eval_expr(unary.expr(), scopes, ctx, engine)?;
            operators::eval_unary_op(unary.op(), operand)
                .map_err(|msg| vec![SourceDiagnostic::error(unary.span(), msg)])
        }

        Expr::Conditional(cond) => {
            control_flow::eval_conditional(cond, scopes, ctx, engine)
        }
        Expr::WhileLoop(loop_expr) => {
            control_flow::eval_while(loop_expr, scopes, ctx, engine)
        }
        Expr::ForLoop(loop_expr) => {
            control_flow::eval_for(loop_expr, scopes, ctx, engine)
        }

        Expr::Closure(c) => closures::eval_closure_expr(c, scopes, ctx, engine),
        Expr::FuncCall(c) => call_dispatch::eval_func_call(c, scopes, ctx, engine),

        Expr::Strong(s) => markup::eval_strong(s, scopes, ctx, engine),
        Expr::Emph(e) => markup::eval_emph(e, scopes, ctx, engine),
        Expr::Heading(h) => markup::eval_heading(h, scopes, ctx, engine),
        Expr::Raw(r) => markup::eval_raw(r, scopes, ctx, engine),
        Expr::Link(l) => markup::eval_link(l, &*engine.styles),
        Expr::ListItem(i) => markup::eval_list_item(i, scopes, ctx, engine),
        Expr::EnumItem(i) => markup::eval_enum_item(i, scopes, ctx, engine),

        Expr::FieldAccess(a) => bindings::eval_field_access(a, scopes, ctx, engine),

        Expr::SetRule(s) => rules::eval_set_rule(s, scopes, ctx, engine),

        Expr::ContentBlock(content_block) => {
            // Content block [ ] — styles locais ao bloco. Engine
            // reconstruído localmente (ADR-0044, Passo 109).
            //
            // **Caso 4 / f3s3 (P340, F-realização fatia 2):** `show_rules` também
            // local (clone O(1) do Arc), espelhando o `CodeBlock` (`{}`). Antes,
            // o `[]` partilhava `&mut *engine.show_rules` → um `#show` dentro do
            // bloco VAZAVA para fora (mutava a chain do chamador da declaração em
            // diante). Agora confina ao escopo do bloco — paridade com o vanilla,
            // que confina via `StyledElem` (`content/mod.rs:744-752`). É o
            // confinamento estrutural que faltava ao modelo eager no `[]`.
            let mut local_styles = engine.styles.clone();
            let mut local_show_rules = Arc::clone(engine.show_rules);
            let mut local_sink = TrackedMut::reborrow_mut(&mut *engine.sink);
            // **P772l** — paridade vanilla `ast::ContentBlock::eval`
            // (`typst-eval/src/code.rs:326-332`): mesmo âmbito léxico
            // próprio do `CodeBlock`. Sem isto, `#let` dentro de `[ ]`
            // vazava para o âmbito do chamador (mesmo bug do CodeBlock).
            scopes.enter();
            let mut local_engine = Engine {
                world: engine.world,
                font_metrics: engine.font_metrics,
                route: engine.route,
                styles: &mut local_styles,
                show_rules: &mut local_show_rules,
                active_guards: &mut *engine.active_guards,
                current_file: engine.current_file,
                sink: &mut local_sink,
            };
            let result = eval_markup_impl(
                content_block.body().to_untyped(),
                scopes,
                ctx,
                &mut local_engine,
                false,
            );
            scopes.exit();
            result
        }

        Expr::Equation(eq) => {
            let block = eq.block();
            let body = math::eval_math_content(scopes, ctx, engine, eq.body())?;
            // F-5a de-bake (P364, `f_fronteira_e1.md` §3a.9): a equação **não
            // baka** mais o gate. O `#set math.equation(numbering:)` vive **só na
            // chain** (`custom("equation.numbering")` no `Content::Styled` da
            // fatia-1). O consumidor lê o gate da chain e mantém `block &&
            // numbering` (só equações de bloco numeram, paridade vanilla). Fonte
            // única.
            let content = crate::compiler::stdlib::equation_content(body, block);
            Ok(Value::Content(content))
        }

        Expr::Math(math) => {
            // Math node isolado (fora de Equation) — produzir como sequence.
            let content = math::eval_math_content(scopes, ctx, engine, math)?;
            Ok(Value::Content(content))
        }

        Expr::ModuleImport(i) => modules::eval_module_import(i, scopes, ctx, engine),
        Expr::ModuleInclude(i) => modules::eval_module_include(i, scopes, ctx, engine),

        // Passo 56 — referência cruzada: @nome → Content::Ref placeholder.
        // **P788** — suplemento explícito `@nome[sup]` avaliado como
        // `ContentBlock` normal (antes: descartado — `@sec1[Cap]`
        // renderizava o suplemento default; vanilla: "Cap 1").
        Expr::Ref(ref_node) => {
            let name = ref_node.target().to_string();
            let supplement = match ref_node.supplement() {
                Some(block) => {
                    match eval_expr(Expr::ContentBlock(block), scopes, ctx, engine)? {
                        Value::Content(c) => Some(c),
                        _ => None,
                    }
                }
                None => None,
            };
            Ok(Value::Content(Content::reference_with_supplement(name, supplement)))
        }

        // Passo 56 — label em contexto de código; associação retroactiva em markup
        // acontece via SyntaxKind::Label. Em código, <label> é um valor de primeira
        // classe (P509) para query/locate.
        Expr::Label(label_node) => {
            let name = label_node.get().to_string();
            Ok(Value::Label(crate::entities::label::Label(name)))
        }

        Expr::ShowRule(s) => rules::eval_show_rule(s, scopes, ctx, engine),

        // Passo 81 — array literal `(1fr, 1fr)` / `(10pt, auto, 1fr)`.
        // Necessário para o argumento `columns` de `grid()`.
        // **P718** — mirror de `ast::Array::eval` (vanilla `code.rs:224-271`):
        // `..spread` de `none` é ignorado, de `array` estende, de `dict`
        // erra (com hint se TODOS os itens forem spreads de dict — ver
        // `remaining_are_dict_spreads`), outro tipo erra sem hint.
        Expr::Array(arr) => {
            let items_vec: Vec<ArrayItem> = arr.items().collect();
            let mut result: Vec<Value> = Vec::with_capacity(items_vec.len());
            let mut all_dict_spreads = true;
            for (i, item) in items_vec.iter().enumerate() {
                match *item {
                    ArrayItem::Pos(expr) => {
                        all_dict_spreads = false;
                        result.push(eval_expr(expr, scopes, ctx, engine)?);
                    }
                    ArrayItem::Spread(spread) => {
                        let value = eval_expr(spread.expr(), scopes, ctx, engine)?;
                        match value {
                            Value::None => {}
                            Value::Array(a) => {
                                all_dict_spreads = false;
                                result.extend(a);
                            }
                            Value::Dict(dict) => {
                                let all_remaining_are_dict_spreads = all_dict_spreads
                                    && remaining_are_dict_spreads(
                                        &items_vec[i + 1..],
                                        scopes,
                                        ctx,
                                        engine,
                                    );
                                if !all_remaining_are_dict_spreads {
                                    return Err(vec![SourceDiagnostic::error(
                                        spread.span(),
                                        format!(
                                            "cannot spread {} into array",
                                            Value::Dict(dict).type_name()
                                        ),
                                    )]);
                                }
                                let full_text =
                                    arr.to_untyped().clone().into_text().to_string();
                                let fixed = full_text.replacen('(', "(: ", 1);
                                return Err(vec![SourceDiagnostic::error(
                                    spread.span(),
                                    "cannot spread dictionary into array".to_string(),
                                )
                                .with_hint(format!(
                                    "add a colon to create a dictionary instead: `{fixed}`"
                                ))]);
                            }
                            other => {
                                return Err(vec![SourceDiagnostic::error(
                                    spread.span(),
                                    format!(
                                        "cannot spread {} into array",
                                        vanilla_type_name(&other)
                                    ),
                                )]);
                            }
                        }
                    }
                }
            }
            Ok(Value::Array(result))
        }

        // **P466** — dict literal `(a: 1, b: 2)` e `("a": 1)`.
        // Dicts com chaves keyed não-string (ex.: regex) são deixados como
        // `Value::None` para que callers especializados (ex.: `#set text(font:)`)
        // possam inspeccionar o AST directamente.
        // **P718** — `..spread` mirror de `ast::Dict::eval` (vanilla
        // `code.rs:273-306`): `none` ignorado, `dict` estende, outro erra.
        Expr::Dict(dict) => {
            let mut map = indexmap::IndexMap::default();
            for item in dict.items() {
                match item {
                    crate::entities::ast::expr::DictItem::Named(named) => {
                        let key = named.name().as_str();
                        let value = eval_expr(named.expr(), scopes, ctx, engine)?;
                        map.insert(key.into(), value);
                    }
                    crate::entities::ast::expr::DictItem::Keyed(keyed) => {
                        let key_expr = keyed.key();
                        let key = match key_expr {
                            crate::entities::ast::expr::Expr::Str(node) => {
                                EcoString::from(node.get()?)
                            }
                            _ => return Ok(Value::None),
                        };
                        let value = eval_expr(keyed.expr(), scopes, ctx, engine)?;
                        map.insert(key, value);
                    }
                    crate::entities::ast::expr::DictItem::Spread(spread) => {
                        let value = eval_expr(spread.expr(), scopes, ctx, engine)?;
                        match value {
                            Value::None => {}
                            Value::Dict(d) => map.extend(d),
                            other => {
                                return Err(vec![SourceDiagnostic::error(
                                    spread.span(),
                                    format!(
                                        "cannot spread {} into dictionary",
                                        vanilla_type_name(&other)
                                    ),
                                )]);
                            }
                        }
                    }
                }
            }
            Ok(Value::Dict(map))
        }

        // `(expr)` — parêntese de agrupamento. Expressão única dentro de
        // parênteses avalia para o valor da expressão. Passo 83.
        // (Um tuplo com um elemento requer a vírgula trailing: `(x,)`.)
        Expr::Parenthesized(paren) => eval_expr(paren.expr(), scopes, ctx, engine),

        // Passo 76 — literais numéricos com unidade (ex: 100pt, 1.5em).
        Expr::Numeric(num) => {
            use crate::entities::ast::expr::Unit;
            use crate::entities::layout_types::{Abs, Angle, Length};
            let (value, unit) = num.get();
            match unit {
                Unit::Pt => Ok(Value::Length(Length { abs: Abs(value), em: 0.0 })),
                Unit::Mm => Ok(Value::Length(Length {
                    abs: Abs(value * Length::PT_PER_MM),
                    em: 0.0,
                })),
                Unit::Cm => Ok(Value::Length(Length {
                    abs: Abs(value * Length::PT_PER_CM),
                    em: 0.0,
                })),
                Unit::In => Ok(Value::Length(Length { abs: Abs(value * 72.0), em: 0.0 })),
                Unit::Em => Ok(Value::Length(Length { abs: Abs(0.0), em: value })),
                Unit::Deg => Ok(Value::Angle(Angle::deg(value))),
                Unit::Rad => Ok(Value::Angle(Angle::rad(value))),
                // P842 (#32) — percentual puro materializa `Ratio` (paridade
                // vanilla medida: `type(50%)` → ratio). Pré-P842 era
                // `Value::Relative` com abs zero (P469), o que fundia os
                // tipos ratio/relative. `Ratio + Length` → `Relative` nos
                // operadores, como no vanilla.
                Unit::Percent => Ok(Value::Ratio(
                    crate::entities::layout_types::Ratio::from_percent(value),
                )),
                Unit::Fr => Ok(Value::Fraction(value)),
            }
        }

        // **P506** — `context { body }` cria um bloco de delayed evaluation.
        // O parser expõe `Contextual` como sugar; construímos uma closure
        // sem argumentos que captura o scope actual e devolvemos
        // `Content::ContextBlock`.
        Expr::Contextual(node) => {
            let body_span = node.body().span();
            let body = node.body().to_untyped().clone();
            let captured = std::sync::Arc::new(scopes.snapshot());
            let closure = Func::closure(ClosureRepr {
                name: None,
                params: Vec::new(),
                sink_name: None,
                body,
                captured,
                // P772q — bloco `context { }`, paridade vanilla
                // `CapturesVisitor::new(scopes, Capturer::Context)`.
                capturer: crate::entities::scope::Capturer::Context,
            })
            .with_diagnostic_span(body_span);
            let id = ctx.next_context_id();
            Ok(Value::Content(Content::ContextBlock(Arc::new(ContextBlockElem {
                id,
                closure,
            }))))
        }

        Expr::Escape(v) => Ok(Value::Str(ecow::EcoString::from(v.get()))),
        Expr::Shorthand(v) => Ok(Value::Str(ecow::EcoString::from(v.get()))),
        Expr::Linebreak(_) => Ok(Value::Content(Content::linebreak())),

        // P635 — controlo de fluxo: definir `FlowEvent` em `ctx.flow` e
        // devolver `Value::None`. O consumo (e a detecção de "fora de
        // contexto") é feito pelos ciclos, por `apply_closure` e pelo
        // entrypoint `eval_with_full_error`.
        Expr::LoopBreak(node) => {
            if ctx.flow.is_none() {
                ctx.flow = Some(FlowEvent::Break(node.span()));
            }
            Ok(Value::None)
        }
        Expr::LoopContinue(node) => {
            if ctx.flow.is_none() {
                ctx.flow = Some(FlowEvent::Continue(node.span()));
            }
            Ok(Value::None)
        }
        Expr::FuncReturn(node) => {
            let value = node
                .body()
                .map(|body| eval_expr(body, scopes, ctx, engine))
                .transpose()?;
            if ctx.flow.is_none() {
                ctx.flow = Some(FlowEvent::Return(node.span(), value, false));
            }
            Ok(Value::None)
        }

        // Fronteira deliberada — variantes estritamente estruturais que não
        // entram no dispatcher normal (markup/math) ou ainda não migradas.
        Expr::Text(_)
        | Expr::Space(_)
        | Expr::Parbreak(_)
        | Expr::SmartQuote(_)
        | Expr::TermItem(_)
        | Expr::MathText(_)
        | Expr::MathIdent(_)
        | Expr::MathShorthand(_)
        | Expr::MathAlignPoint(_)
        | Expr::MathDelimited(_)
        | Expr::MathAttach(_)
        | Expr::MathPrimes(_)
        | Expr::MathFrac(_)
        | Expr::MathRoot(_) => Ok(Value::None),

        // **P715** — `(a, b) = expr`. Ver `bindings::eval_destruct_assignment`.
        Expr::DestructAssignment(node) => {
            bindings::eval_destruct_assignment(node, scopes, ctx, engine)
        }
    }
}

/// **P740A** — deteta updates de state/counter no conteúdo descartado
/// por um `return` (paridade do seletor `State::select_any() |
/// Counter::select_any()` do vanilla em `warn_for_discarded_content`).
/// Travessia directa: as variants da família (state, state update,
/// counter update e os dois displays de counter) disparam; desce em
/// `Sequence` e `Styled` (as formas que o `join` produz em markup).
fn content_has_state_or_counter(c: &crate::entities::content::Content) -> bool {
    use crate::entities::content::Content;
    match c {
        Content::State(_)
        | Content::StateUpdate(_)
        | Content::CounterUpdate(_)
        | Content::CounterDisplay(_)
        | Content::CounterDisplayCallback(_) => true,
        Content::Sequence(items) => items.iter().any(content_has_state_or_counter),
        Content::Styled(styled) => content_has_state_or_counter(&styled.body),
        _ => false,
    }
}

/// **P718** — lookahead para o hint de `Expr::Array` (mirror do
/// `items.all(...)` de `ast::Array::eval`, vanilla `code.rs:253-265`):
/// devolve `true` sse todos os itens restantes forem `Spread` cuja
/// expressão avalia a `Value::Dict`. Qualquer `Pos`, spread de outro tipo,
/// ou erro de avaliação → `false` (short-circuit, sem consumir o resto).
fn remaining_are_dict_spreads(
    items: &[ArrayItem],
    scopes: &mut Scopes<'_>,
    ctx: &mut EvalContext,
    engine: &mut Engine<'_>,
) -> bool {
    for item in items {
        match item {
            ArrayItem::Spread(s) => match eval_expr(s.expr(), scopes, ctx, engine) {
                Ok(Value::Dict(_)) => continue,
                _ => return false,
            },
            ArrayItem::Pos(_) => return false,
        }
    }
    true
}

/// Avalia o corpo de um nó de markup como Content.
fn eval_markup_body(
    node: &SyntaxNode,
    scopes: &mut Scopes<'_>,
    ctx: &mut EvalContext,
    engine: &mut Engine<'_>,
) -> SourceResult<Content> {
    match eval_markup(node, scopes, ctx, engine)? {
        Value::Content(c) => Ok(c),
        _ => Ok(Content::Empty),
    }
}

// eval_args, apply_func, apply_closure extraídos para eval/closures.rs (Passo 96.1).

// Math eval extraído para eval/math.rs no Passo 96.1 (ADR-0037).

// eval_let extraído para eval/bindings.rs (Passo 96.1).

// apply_show_rules e intercept_content extraídos para eval/rules.rs (Passo 96.1).

/// Constrói a stdlib: `type`, `len`, `range`, `rgb`, `luma`, `str`, `int`, `float`, `figure`, `assert`, `upper`, `lower`, `replace`, `calc`.
///
/// Passo 64 (DEBT-16): `native_figure` migrada do interceptador em eval.rs para cá.
/// O avaliador deixa de conhecer o nome "figure" — desacoplamento total.
fn make_stdlib(inputs: &SysInputs) -> Scope {
    make_stdlib_with_features(
        inputs,
        crate::entities::compiler_features::Features::default(),
    )
}

fn make_stdlib_with_features(
    inputs: &SysInputs,
    features: crate::entities::compiler_features::Features,
) -> Scope {
    crate::compiler::stdlib::make_stdlib_with_features(inputs, features)
}

// ── Auxiliares para intercepção de counter(...).method() ──────────────────

#[cfg(test)]
#[path = "p1425_tests.rs"]
mod p1425_tests;
#[cfg(test)]
#[path = "p1426_tests.rs"]
mod p1426_tests;
#[cfg(test)]
#[path = "p1427_tests.rs"]
mod p1427_tests;
#[cfg(test)]
#[path = "p1429_observation_tests.rs"]
mod p1429_observation_tests;

#[cfg(test)]
#[path = "p1430_tests.rs"]
mod p1430_tests;

#[cfg(test)]
mod p1431_tests;
/// Extrai o nome do contador de uma expressão `counter(key)`.
// extract_counter_key e eval_counter_method extraídos para eval/bindings.rs (Passo 96.1).

#[cfg(test)]
mod tests;
#[cfg(test)]
mod p1292_d_tests {
    use super::*;
    use crate::entities::args::Args;

    #[test]
    fn p1292_d_place_and_with_share_the_flush_namespace() {
        let stdlib = make_stdlib(&SysInputs::default());
        let Value::Func(place) = stdlib.get("place").unwrap() else {
            panic!("place must remain callable");
        };
        assert_eq!(place.name(), Some("place"));

        let namespace = place.namespace().expect("place namespace");
        let Value::Func(flush) = namespace.get("flush").unwrap() else {
            panic!("place.flush must be callable");
        };
        assert_eq!(flush.name(), Some("flush"));

        let with = place.clone().with(Args::positional(Vec::new()));
        assert!(with.namespace().unwrap().get("flush").is_some());
    }
}
#[cfg(test)]
mod p1293_d_tests {
    use super::*;
    use crate::entities::args::Args;

    fn assert_short_namespace_names(namespace_name: &str) {
        let stdlib = make_stdlib(&SysInputs::default());
        let Value::Func(container) = stdlib.get(namespace_name).unwrap() else {
            panic!("{namespace_name} must remain callable");
        };
        let namespace = container.namespace().expect("namespace must exist");
        let with_container = container.clone().with(Args::positional(Vec::new()));
        let with_namespace =
            with_container.namespace().expect("with must preserve namespace");

        for expected in ["cell", "header", "footer", "hline", "vline"] {
            let Value::Func(member) = namespace.get(expected).unwrap() else {
                panic!("{namespace_name}.{expected} must remain callable");
            };
            assert_eq!(member.name(), Some(expected));
            assert_eq!(
                member.clone().with(Args::positional(Vec::new())).name(),
                Some(expected),
            );

            let Value::Func(with_member) = with_namespace.get(expected).unwrap() else {
                panic!("{namespace_name}.with(...).{expected} must remain callable");
            };
            assert_eq!(with_member.name(), Some(expected));
        }
    }

    #[test]
    fn p1293_d_grid_namespace_uses_short_names_direct_and_with() {
        assert_short_namespace_names("grid");
    }

    #[test]
    fn p1293_d_table_namespace_uses_short_names_direct_and_with() {
        assert_short_namespace_names("table");
    }

    #[test]
    fn p1293_d_flat_aliases_keep_historical_names_and_lines_stay_namespaced() {
        let stdlib = make_stdlib(&SysInputs::default());
        for alias in [
            "grid_cell",
            "grid_header",
            "grid_footer",
            "table_cell",
            "table_header",
            "table_footer",
        ] {
            let Value::Func(function) = stdlib.get(alias).unwrap() else {
                panic!("{alias} must remain callable");
            };
            assert_eq!(function.name(), Some(alias));
        }

        for absent in ["grid_hline", "grid_vline", "table_hline", "table_vline"] {
            assert!(stdlib.get(absent).is_none(), "{absent} must stay namespaced");
        }
    }
}
#[cfg(test)]
pub(crate) use crate::compiler::eval::tests::eval_for_test;
// Re-export para o módulo de tests (que usa `use super::*;`).
#[cfg(test)]
pub(crate) use crate::compiler::eval::operators::{eval_binary_op, eval_unary_op};

/// P1471 — RED isolado (Agente B), a partir de `compiler/eval.md` P1471:
/// este owner só regista `pdf`/`html` no scope canónico via
/// `make_stdlib_with_features` (uma única composição,
/// `make_pdf_module`/`make_html_module()` chamadas exatamente uma vez
/// cada); a única mudança observável aqui é o kind do valor registado, de
/// `module` para `function`. Nenhuma implementação foi consultada.
#[cfg(test)]
mod p1471_tests {
    use super::*;
    use crate::entities::compiler_features::{Feature, Features};

    fn profiles() -> Vec<Features> {
        (0..4u8)
            .map(|mask| {
                let mut features = Features::empty();
                if mask & 1 != 0 {
                    features.enable(Feature::Html);
                }
                if mask & 2 != 0 {
                    features.enable(Feature::A11yExtras);
                }
                features
            })
            .collect()
    }

    /// Item 1 (nível de composição) — o scope canónico construído por
    /// `make_stdlib_with_features` regista `pdf` (sempre) e `html` (nos
    /// perfis com `Feature::Html`) como `Value::Func`, não `Value::Module`.
    /// RED nesta baseline: ambos ainda são `Value::Module`.
    #[test]
    fn p1471_scope_registers_pdf_and_html_as_func_across_profiles() {
        for features in profiles() {
            let stdlib = make_stdlib_with_features(&SysInputs::default(), features);

            let pdf = stdlib.get("pdf").expect("pdf deve estar registado no scope");
            let Value::Func(pdf_func) = pdf else {
                panic!(
                    "P1471: scope.pdf deve ser Value::Func em {features:?}, obtido {pdf:?}"
                );
            };
            assert_eq!(pdf_func.name(), Some("pdf"), "nome nativo de scope.pdf");

            if features.contains(Feature::Html) {
                let html =
                    stdlib.get("html").expect("html deve estar registado no scope");
                let Value::Func(html_func) = html else {
                    panic!(
                        "P1471: scope.html deve ser Value::Func em {features:?}, obtido {html:?}"
                    );
                };
                assert_eq!(html_func.name(), Some("html"), "nome nativo de scope.html");
            }
        }
    }
}
