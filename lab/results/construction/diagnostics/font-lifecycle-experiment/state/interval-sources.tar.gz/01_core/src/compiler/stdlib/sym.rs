//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/compiler/stdlib/sym.md
//! @prompt-hash c23c7f41
//! @layer L1
//! @updated 2026-08-30
//!
//! Módulo `sym` — catálogo Unicode do codex git pinado (P1496)
//! com overlay explícito de aliases legados.
//!
//! **P765a**: suporte a modificadores encadeados (`sym.arrow.r.filled`)
//! via `Symbol::variants`.
//! **P766**: expansão por uso real do corpus — grupos com variantes
//! (`tilde`, `integral`, `chevron`, `suit`, `tack`, `space`, `emptyset`,
//! `bracket`, `amp`) e variantes adicionais de `plus`, `gt`, `diamond`.
//!
//! **P731** — o módulo passou de `Value::Dict` a `Value::Module`
//! (paridade vanilla — medido: `type(sym)` → `module`).

use crate::entities::symbol::{Symbol, SymbolVariant};
use crate::entities::value::Value;
use ecow::EcoString;

/// Símbolos simples: nome e caractere.
/// Entradas com `.` são variantes pré-definidas de grupos simples.
static SYM_SIMPLE: &[(&str, &str)] = &[
    ("eq", "="),
    ("eq.not", "≠"),
    ("lt", "<"),
    ("lt.eq", "≤"),
    ("minus", "−"),
    ("times", "×"),
    ("div", "÷"),
    // **P894** — `dot` bare é U+22C5 (DOT OPERATOR), paridade vanilla
    // (codex `sym.txt`: `dot` bare = variante `.op`). `.c` preserva o
    // U+00B7 (MIDDLE DOT) que estava incorrectamente em `dot` bare.
    ("dot", "⋅"),
    ("dot.c", "·"),
    ("alpha", "α"),
    ("beta", "β"),
    ("gamma", "γ"),
    ("delta", "δ"),
    ("zeta", "ζ"),
    ("eta", "η"),
    ("iota", "ι"),
    ("kappa", "κ"),
    ("lambda", "λ"),
    ("mu", "μ"),
    ("nu", "ν"),
    ("xi", "ξ"),
    ("pi", "π"),
    ("tau", "τ"),
    ("upsilon", "υ"),
    ("chi", "χ"),
    ("psi", "ψ"),
    ("omega", "ω"),
    ("infinity", "∞"),
    // **P895** — `oo`: atalho de `infinity`, paridade vanilla (`codex`: `oo ∞`).
    ("oo", "∞"),
    ("sum", "∑"),
    ("product", "∏"),
    ("in", "∈"),
    ("not.in", "∉"),
    // **P895** — Hebraico usado em teoria de conjuntos/cardinais (beth,
    // paridade `codex`: `beth ב`).
    ("beth", "ב"),
    // **P895** — atalho de `propto`/relação "proporcional a" (`codex`: `prop ∝`).
    ("prop", "∝"),
    ("and", "∧"),
    ("or", "∨"),
    ("not", "¬"),
    ("forall", "∀"),
    ("exists", "∃"),
    ("dagger", "†"),
    ("star", "⋆"),
    ("bullet", "•"),
    ("circle", "○"),
    ("square", "□"),
    ("copyright", "©"),
    ("trademark", "™"),
    ("registered", "®"),
];

/// Constrói as variantes do grupo `arrow`.
fn arrow_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '→'.into()),
        ("long.bar".into(), '⟼'.into()),
        ("bar".into(), '↦'.into()),
        ("curve".into(), '⤷'.into()),
        ("turn".into(), '⮎'.into()),
        ("dashed".into(), '⇢'.into()),
        ("dotted".into(), '⤑'.into()),
        ("double".into(), '⇒'.into()),
        ("double.bar".into(), '⤇'.into()),
        ("double.long".into(), '⟹'.into()),
        ("double.long.bar".into(), '⟾'.into()),
        ("double.not".into(), '⇏'.into()),
        ("double.struck".into(), '⤃'.into()),
        ("filled".into(), '➡'.into()),
        ("hook".into(), '↪'.into()),
        ("long".into(), '⟶'.into()),
        ("r".into(), '→'.into()),
        ("r.filled".into(), '➡'.into()),
        ("long.squiggly".into(), '⟿'.into()),
        ("loop".into(), '↬'.into()),
        ("not".into(), '↛'.into()),
        ("quad".into(), '⭆'.into()),
        ("squiggly".into(), '⇝'.into()),
        ("stop".into(), '⇥'.into()),
        ("stroked".into(), '⇨'.into()),
        ("struck".into(), '⇸'.into()),
        ("dstruck".into(), '⇻'.into()),
        ("tail".into(), '↣'.into()),
        ("tail.struck".into(), '⤔'.into()),
        ("tail.dstruck".into(), '⤕'.into()),
        ("tilde".into(), '⥲'.into()),
        ("triple".into(), '⇛'.into()),
        ("twohead".into(), '↠'.into()),
        ("twohead.bar".into(), '⤅'.into()),
        ("twohead.struck".into(), '⤀'.into()),
        ("twohead.dstruck".into(), '⤁'.into()),
        ("twohead.tail".into(), '⤖'.into()),
        ("twohead.tail.struck".into(), '⤗'.into()),
        ("twohead.tail.dstruck".into(), '⤘'.into()),
        ("open".into(), '⇾'.into()),
        ("wave".into(), '↝'.into()),
        ("l".into(), '←'.into()),
        ("l.double".into(), '⇔'.into()),
        ("l.double.long".into(), '⟺'.into()),
        ("l.double.not".into(), '⇎'.into()),
        ("l.double.struck".into(), '⤄'.into()),
        ("l.filled".into(), '⬌'.into()),
        ("l.long".into(), '⟷'.into()),
        ("l.not".into(), '↮'.into()),
        ("l.stroked".into(), '⬄'.into()),
        ("l.struck".into(), '⇹'.into()),
        ("l.dstruck".into(), '⇼'.into()),
        ("l.open".into(), '⇿'.into()),
        ("l.wave".into(), '↭'.into()),
    ]
}

/// P766 — grupo `plus` (uso real: `sym.plus.o` no corpus).
fn plus_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '+'.into()),
        ("o".into(), '⊕'.into()),
        ("o.l".into(), '⨭'.into()),
        ("o.r".into(), '⨮'.into()),
        ("o.arrow".into(), '⟴'.into()),
        ("o.big".into(), '⨁'.into()),
        ("dot".into(), '∔'.into()),
        ("double".into(), '⧺'.into()),
        ("minus".into(), '±'.into()),
        ("square".into(), '⊞'.into()),
        ("triangle".into(), '⨹'.into()),
        ("triple".into(), '⧻'.into()),
        ("hat".into(), '⨣'.into()),
    ]
}

/// P766 — grupo `gt` (uso real: `sym.gt.eq.tri.not` no corpus).
fn gt_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '>'.into()),
        ("o".into(), '⧁'.into()),
        ("dot".into(), '⋗'.into()),
        ("quest".into(), '⩼'.into()),
        ("approx".into(), '⪆'.into()),
        ("arc".into(), '⪧'.into()),
        ("arc.eq".into(), '⪩'.into()),
        ("closed".into(), '⊳'.into()),
        ("closed.eq".into(), '⊵'.into()),
        ("closed.eq.not".into(), '⋭'.into()),
        ("closed.not".into(), '⋫'.into()),
        ("double".into(), '≫'.into()),
        ("double.nested".into(), '⪢'.into()),
        ("eq".into(), '≥'.into()),
        ("eq.slant".into(), '⩾'.into()),
        ("eq.lt".into(), '⋛'.into()),
        ("eq.not".into(), '≱'.into()),
        ("equiv".into(), '≧'.into()),
        ("lt".into(), '≷'.into()),
        ("lt.not".into(), '≹'.into()),
        ("neq".into(), '⪈'.into()),
        ("napprox".into(), '⪊'.into()),
        ("nequiv".into(), '≩'.into()),
        ("not".into(), '≯'.into()),
        ("ntilde".into(), '⋧'.into()),
        ("tilde".into(), '≳'.into()),
        ("tilde.not".into(), '≵'.into()),
        ("tri".into(), '⊳'.into()),
        ("tri.eq".into(), '⊵'.into()),
        ("tri.eq.not".into(), '⋭'.into()),
        ("tri.not".into(), '⋫'.into()),
        ("triple".into(), '⋙'.into()),
        ("triple.nested".into(), '⫸'.into()),
    ]
}

/// P1496 — variante de compatibilidade retirada do catálogo novo.
/// Usada apenas nos oito paths `lt.tri*` aprovados, nunca no parent
/// público `lt`, cujo repr permanece idêntico ao codex pinado.
fn lt_legacy_tri_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '<'.into()),
        ("tri".into(), '⊲'.into()),
        ("tri.eq".into(), '⊴'.into()),
        ("tri.eq.not".into(), '⋬'.into()),
        ("tri.not".into(), '⋪'.into()),
    ]
}

/// P766 — grupo `diamond` (uso real: `sym.diamond.small` no corpus).
fn diamond_variants() -> Vec<SymbolVariant> {
    vec![
        ("blue".into(), '🔷'.into()),
        ("blue.small".into(), '🔹'.into()),
        ("orange".into(), '🔶'.into()),
        ("orange.small".into(), '🔸'.into()),
        ("dot".into(), '💠'.into()),
    ]
}

/// P766 — grupo `tilde` (uso real: 19 ocorrências no corpus).
fn tilde_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '∼'.into()),
        ("op".into(), '∼'.into()),
        ("basic".into(), '~'.into()),
        ("dot".into(), '⩪'.into()),
        ("eq".into(), '≃'.into()),
        ("eq.not".into(), '≄'.into()),
        ("eq.rev".into(), '⋍'.into()),
        ("equiv".into(), '≅'.into()),
        ("equiv.not".into(), '≇'.into()),
        ("nequiv".into(), '≆'.into()),
        ("not".into(), '≁'.into()),
        ("rev".into(), '∽'.into()),
        ("rev.equiv".into(), '≌'.into()),
        ("triple".into(), '≋'.into()),
    ]
}

/// P766 — grupo `integral` (uso real: 3 ocorrências no corpus).
fn integral_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '∫'.into()),
        ("arrow.hook".into(), '⨗'.into()),
        ("ccw".into(), '⨑'.into()),
        ("cont".into(), '∮'.into()),
        ("cont.ccw".into(), '∳'.into()),
        ("cont.cw".into(), '∲'.into()),
        ("cw".into(), '∱'.into()),
        ("dash".into(), '⨍'.into()),
        ("dash.double".into(), '⨎'.into()),
        ("double".into(), '∬'.into()),
        ("quad".into(), '⨌'.into()),
        ("inter".into(), '⨙'.into()),
        ("slash".into(), '⨏'.into()),
        ("square".into(), '⨖'.into()),
        ("surf".into(), '∯'.into()),
        ("times".into(), '⨘'.into()),
        ("triple".into(), '∭'.into()),
        ("union".into(), '⨚'.into()),
        ("vol".into(), '∰'.into()),
    ]
}

/// P766 — grupo `chevron` (uso real: 3 ocorrências no corpus).
fn chevron_variants() -> Vec<SymbolVariant> {
    vec![
        ("l".into(), '⟨'.into()),
        ("l.curly".into(), '⧼'.into()),
        ("l.dot".into(), '⦑'.into()),
        ("l.closed".into(), '⦉'.into()),
        ("l.double".into(), '⟪'.into()),
        ("r".into(), '⟩'.into()),
        ("r.curly".into(), '⧽'.into()),
        ("r.dot".into(), '⦒'.into()),
        ("r.closed".into(), '⦊'.into()),
        ("r.double".into(), '⟫'.into()),
    ]
}

/// P766 — grupo `suit` (uso real: 2 ocorrências no corpus).
fn suit_variants() -> Vec<SymbolVariant> {
    vec![
        ("club".into(), '♣'.into()),
        ("diamond".into(), '♦'.into()),
        ("heart".into(), '♥'.into()),
        ("spade".into(), '♠'.into()),
    ]
}

/// P766 — grupo `tack` (uso real: 1 ocorrência no corpus).
fn tack_variants() -> Vec<SymbolVariant> {
    vec![
        ("r".into(), '⊢'.into()),
        ("r.not".into(), '⊬'.into()),
        ("r.long".into(), '⟝'.into()),
        ("r.short".into(), '⊦'.into()),
        ("r.double".into(), '⊨'.into()),
        ("rr".into(), '⊨'.into()),
        ("r.double.not".into(), '⊭'.into()),
        ("rr.not".into(), '⊭'.into()),
        ("rrr".into(), '⫢'.into()),
        ("l".into(), '⊣'.into()),
        ("l.long".into(), '⟞'.into()),
        ("l.short".into(), '⫞'.into()),
        ("l.double".into(), '⫤'.into()),
        ("ll".into(), '⫤'.into()),
        ("t".into(), '⊥'.into()),
        ("t.big".into(), '⟘'.into()),
        ("t.double".into(), '⫫'.into()),
        ("tt".into(), '⫫'.into()),
        ("t.short".into(), '⫠'.into()),
        ("b".into(), '⊤'.into()),
        ("b.big".into(), '⟙'.into()),
        ("b.double".into(), '⫪'.into()),
        ("bb".into(), '⫪'.into()),
        ("b.short".into(), '⫟'.into()),
        ("l.r".into(), '⟛'.into()),
    ]
}

/// P766 — grupo `space` (uso real: 1 ocorrência no corpus).
fn space_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), ' '.into()),
        ("nobreak".into(), '\u{a0}'.into()),
        ("nobreak.narrow".into(), '\u{202f}'.into()),
        ("en".into(), '\u{2002}'.into()),
        ("quad".into(), '\u{2003}'.into()),
        ("third".into(), '\u{2004}'.into()),
        ("quarter".into(), '\u{2005}'.into()),
        ("sixth".into(), '\u{2006}'.into()),
        ("med".into(), '\u{205f}'.into()),
        ("fig".into(), '\u{2007}'.into()),
        ("punct".into(), '\u{2008}'.into()),
        ("thin".into(), '\u{2009}'.into()),
        ("hair".into(), '\u{200a}'.into()),
    ]
}

/// P766 — grupo `emptyset` (uso real: 1 ocorrência no corpus).
fn emptyset_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '∅'.into()),
        ("zero".into(), '∅'.into()),
        ("arrow.r".into(), '⦳'.into()),
        ("arrow.l".into(), '⦴'.into()),
        ("bar".into(), '⦱'.into()),
        ("circle".into(), '⦲'.into()),
        ("rev".into(), '⦰'.into()),
    ]
}

/// P766 — grupo `bracket` (uso real: 1 ocorrência no corpus).
fn bracket_variants() -> Vec<SymbolVariant> {
    vec![
        ("l".into(), '['.into()),
        ("l.tick.t".into(), '⦍'.into()),
        ("l.tick.b".into(), '⦏'.into()),
        ("l.stroked".into(), '⟦'.into()),
        ("r".into(), ']'.into()),
        ("r.tick.t".into(), '⦐'.into()),
        ("r.tick.b".into(), '⦎'.into()),
        ("r.stroked".into(), '⟧'.into()),
        ("t".into(), '⎴'.into()),
        ("b".into(), '⎵'.into()),
    ]
}

/// P766 — grupo `amp` (uso real: 1 ocorrência no corpus).
fn amp_variants() -> Vec<SymbolVariant> {
    vec![(EcoString::default(), '&'.into()), ("inv".into(), '⅋'.into())]
}

fn subset_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '⊂'.into()),
        ("eq".into(), '⊆'.into()),
        ("neq".into(), '⊊'.into()),
    ]
}

fn floor_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '⌊'.into()),
        ("l".into(), '⌊'.into()),
        ("r".into(), '⌋'.into()),
    ]
}

fn ceil_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '⌈'.into()),
        ("l".into(), '⌈'.into()),
        ("r".into(), '⌉'.into()),
    ]
}

fn supset_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '⊃'.into()),
        ("eq".into(), '⊇'.into()),
        ("neq".into(), '⊋'.into()),
    ]
}

/// **P820** — grupo `join` (codex `sym.txt:651-654`). Símbolo **depreciado**
/// no vanilla (ver `SYM_DEPRECATED`); os caracteres continuam resolvíveis.
fn join_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '⨝'.into()),
        ("r".into(), '⟖'.into()),
        ("l".into(), '⟕'.into()),
        ("l.r".into(), '⟗'.into()),
    ]
}

/// **P820** — grupo `bowtie` (codex `sym.txt:655-663`). Sem variante bare
/// no codex: o vanilla cai na primeira variante (`stroked`, ⋈) quando não
/// há modifiers — medido `$bowtie$` → ⋈. `bowtie.big` resolve para
/// `stroked.big` (⨝) pelo algoritmo de menor número de modifiers extra
/// (`Symbol::modified`) — medido `$bowtie.big$` → ⨝.
fn planck_variants() -> Vec<SymbolVariant> {
    vec![(ecow::EcoString::default(), 'ℎ'.into()), ("reduce".into(), 'ℏ'.into())]
}

fn bowtie_variants() -> Vec<SymbolVariant> {
    vec![
        ("stroked".into(), '⋈'.into()),
        ("stroked.big".into(), '⨝'.into()),
        ("stroked.big.l".into(), '⟕'.into()),
        ("stroked.big.r".into(), '⟖'.into()),
        ("stroked.big.l.r".into(), '⟗'.into()),
        ("filled".into(), '⧓'.into()),
        ("filled.l".into(), '⧑'.into()),
        ("filled.r".into(), '⧒'.into()),
    ]
}

// **P895** (Parte B — catálogo de terceiros, `typst-passo-895-relatorio.md`)
// — os grupos abaixo eram entradas `SYM_SIMPLE` planas sem variantes; como
// `$epsilon.alt$` é sempre parseado como `FieldAccess(MathIdent("epsilon"),
// "alt")` (nunca como um único `MathIdent` "epsilon.alt"), a resolução em
// modo math passa por `Value::Symbol::modified("alt")` — que só encontra a
// variante se o símbolo base foi construído via `Symbol::with_variants`
// (`SYM_GROUPS`), nunca `Symbol::new` (`SYM_SIMPLE`). Um par de entradas
// planas "nome"/"nome.modificador" em `SYM_SIMPLE` (o padrão usado por
// `eq.not`/`dot.c`) só é alcançável chamando `sym_lookup` directamente com a
// string já combinada — não a partir de modo math real. Migrados para
// `SYM_GROUPS` para que `$epsilon.alt$` etc. funcionem de facto.

/// **P895** — grupo `epsilon` (paridade `codex`: `.alt` = ϵ, `.alt.rev` = ϶
/// fora de âmbito, não pedido).
fn epsilon_variants() -> Vec<SymbolVariant> {
    vec![(EcoString::default(), 'ε'.into()), ("alt".into(), 'ϵ'.into())]
}

/// **P895** — grupo `theta` (paridade `codex`: `.alt` = ϑ).
fn theta_variants() -> Vec<SymbolVariant> {
    vec![(EcoString::default(), 'θ'.into()), ("alt".into(), 'ϑ'.into())]
}

/// **P895** — grupo `phi` (paridade `codex`: `.alt` = ϕ).
fn phi_variants() -> Vec<SymbolVariant> {
    vec![(EcoString::default(), 'φ'.into()), ("alt".into(), 'ϕ'.into())]
}

/// **P895** — grupo `rho` (paridade `codex`: `.alt` = ϱ).
fn rho_variants() -> Vec<SymbolVariant> {
    vec![(EcoString::default(), 'ρ'.into()), ("alt".into(), 'ϱ'.into())]
}

/// **P895** — grupo `sigma` (paridade `codex`: `.alt` = ς).
fn sigma_variants() -> Vec<SymbolVariant> {
    vec![(EcoString::default(), 'σ'.into()), ("alt".into(), 'ς'.into())]
}

/// **P895** — grupo `dots` (só `.h` pedido/testado; `.h.c`/`.v`/`.down`/
/// `.up` do codex ficam fora de âmbito, não pedidos).
fn dots_variants() -> Vec<SymbolVariant> {
    vec![
        (EcoString::default(), '…'.into()),
        ("h".into(), '…'.into()),
        ("c".into(), '⋯'.into()),
        ("v".into(), '⋮'.into()),
        ("down".into(), '⋱'.into()),
        ("up".into(), '⋰'.into()),
    ]
}

/// **P895** — grupo `union` (só `.big` pedido/testado; outras variantes do
/// codex — `.serif`/`.arrow`/`.dot`/`.dot.big`/`.double` — ficam fora de
/// âmbito, não pedidas).
fn union_variants() -> Vec<SymbolVariant> {
    vec![(EcoString::default(), '∪'.into()), ("big".into(), '⋃'.into())]
}

/// **P895** — grupo `inter` (nome correcto — `sect` não existe no vanilla,
/// corrigido). Só `.big` pedido/testado; outras variantes do codex ficam
/// fora de âmbito.
fn inter_variants() -> Vec<SymbolVariant> {
    vec![(EcoString::default(), '∩'.into()), ("big".into(), '⋂'.into())]
}

/// **P820/P1496** — aviso histórico de `join`, retirado do codex
/// novo mas preservado na extensão cristalina. Depreciações de
/// bindings ainda presentes, como `spacebar`, vêm da metadata pinada
/// de `codex::SYM`; avisos de variantes são dívida P1283.
static SYM_DEPRECATED: &[(&str, &str)] =
    &[("join", "`join` is deprecated, use `bowtie.big` instead")];

/// Mensagem de depreciação de um símbolo de topo, se depreciado.
/// Os call sites (eval math, field access) emitem o warning com o span
/// apropriado (ident em math; campo em `#sym.join`).
pub fn sym_deprecation(name: &str) -> Option<&'static str> {
    codex::SYM
        .get(name)
        .and_then(|binding| binding.deprecation)
        .or_else(|| SYM_DEPRECATED.iter().find(|(n, _)| *n == name).map(|(_, msg)| *msg))
}

/// Lista de grupos com variantes: (nome, caractere base, função de variantes).
pub(crate) static SYM_GROUPS: &[(&str, &str, fn() -> Vec<SymbolVariant>)] = &[
    ("arrow", "→", arrow_variants),
    ("plus", "+", plus_variants),
    ("gt", ">", gt_variants),
    ("lt", "<", lt_legacy_tri_variants),
    ("diamond", "◇", diamond_variants),
    ("tilde", "∼", tilde_variants),
    ("integral", "∫", integral_variants),
    ("chevron", "⟨", chevron_variants),
    ("suit", "♣", suit_variants),
    ("tack", "⊢", tack_variants),
    ("space", " ", space_variants),
    ("emptyset", "∅", emptyset_variants),
    ("bracket", "[", bracket_variants),
    ("amp", "&", amp_variants),
    ("subset", "⊂", subset_variants),
    ("supset", "⊃", supset_variants),
    ("join", "⨝", join_variants),
    ("bowtie", "⋈", bowtie_variants),
    ("epsilon", "ε", epsilon_variants),
    ("theta", "θ", theta_variants),
    ("phi", "φ", phi_variants),
    ("rho", "ρ", rho_variants),
    ("sigma", "σ", sigma_variants),
    ("dots", "…", dots_variants),
    ("union", "∪", union_variants),
    ("inter", "∩", inter_variants),
    ("planck", "ℎ", planck_variants),
    ("floor", "⌊", floor_variants),
    ("ceil", "⌈", ceil_variants),
];

/// Procura um símbolo pelo nome. Entradas compostas pré-definidas
/// (`"arrow.r"`, `"eq.not"`) e modifiers encadeados (`"arrow.r.filled"`,
/// `"tilde.equiv"`) são resolvidos.
fn legacy_sym_lookup(name: &str) -> Option<Symbol> {
    // 1. Grupos com variantes.
    for (group, base, variants_fn) in SYM_GROUPS {
        if name == *group {
            return Some(Symbol::with_variants(*base, *group, variants_fn()));
        }
        let prefix = format!("{}.", group);
        if name.starts_with(&prefix) {
            let rest = &name[prefix.len()..];
            let mut s = Symbol::with_variants(*base, *group, variants_fn());
            for modifier in rest.split('.') {
                s = s.modified(modifier)?;
            }
            return Some(s);
        }
    }

    // 2. Símbolos simples (incluindo entradas compostas pré-definidas).
    SYM_SIMPLE
        .iter()
        .find(|(n, _)| *n == name)
        .map(|(n, ch)| Symbol::new(*ch, *n))
}

fn symbol_from_codex(name: &str, symbol: codex::Symbol) -> Symbol {
    let value = symbol
        .get(codex::ModifierSet::default())
        .expect("codex symbol must have a default best match")
        .0;
    let variants = symbol
        .variants()
        .map(|(modifiers, value, _)| (modifiers.as_str().into(), value.into()))
        .collect();
    Symbol::with_variants(value, name, variants)
}

fn codex_lookup(name: &str) -> Option<Symbol> {
    let mut segments = name.split('.');
    let mut leaf = segments.next()?;
    let mut binding = codex::SYM.get(leaf)?;
    loop {
        match binding.def {
            codex::Def::Module(module) => {
                leaf = segments.next()?;
                binding = module.get(leaf)?;
            }
            codex::Def::Symbol(symbol) => {
                let mut symbol = symbol_from_codex(leaf, symbol);
                for modifier in segments {
                    symbol = symbol.modified(modifier)?;
                }
                return Some(symbol);
            }
        }
    }
}

/// A tabela antiga só autoriza os paths de compatibilidade decididos
/// em P1495; não reintroduz silenciosamente outros nomes removidos do pin.
fn legacy_extension_lookup(name: &str) -> Option<Symbol> {
    let allowed = match name.split_once('.') {
        None => matches!(name, "registered" | "join"),
        Some(("join", modifiers)) => modifiers.split('.').all(|m| matches!(m, "r" | "l")),
        Some(("gt" | "lt", modifiers)) => {
            let mut has_tri = false;
            let valid = modifiers.split('.').all(|modifier| {
                has_tri |= modifier == "tri";
                matches!(modifier, "tri" | "eq" | "not")
            });
            valid && has_tri
        }
        _ => false,
    };
    allowed.then(|| legacy_sym_lookup(name)).flatten()
}

/// Procura primeiro no catálogo git pinado P1496; só os aliases
/// cristalinos aprovados recorrem à tabela histórica.
pub fn sym_lookup(name: &str) -> Option<Symbol> {
    codex_lookup(name).or_else(|| legacy_extension_lookup(name))
}

fn module_from_codex(
    name: &str,
    module: codex::Module,
) -> crate::entities::module::Module {
    let mut scope = crate::entities::scope::Scope::new();
    for (binding_name, binding) in module.iter() {
        let value = match binding.def {
            codex::Def::Symbol(symbol) => {
                Value::Symbol(symbol_from_codex(binding_name, symbol))
            }
            codex::Def::Module(child) => {
                Value::Module(module_from_codex(binding_name, child))
            }
        };
        scope.define(binding_name, value);
    }
    crate::entities::module::Module::new(name, scope)
}

/// Constrói o `Value::Module` que representa o módulo `sym` no scope.
///
/// Apenas as entradas com nome simples (sem `.`) ficam acessíveis via
/// eval FieldAccess (`sym.arrow`). Entradas compostas estão disponíveis
/// via `sym_lookup`.
pub fn build_sym_module() -> Value {
    let module = module_from_codex("sym", codex::SYM);
    let mut scope = module.scope().clone();
    // Só bindings de topo aprovados em P1283/P1495. As variantes
    // tri são paths seletivos: não alteram repr dos parents gt/lt.
    for name in ["registered", "join"] {
        if scope.get(name).is_none() {
            let symbol =
                legacy_extension_lookup(name).expect("approved symbol extension");
            scope.define(name, Value::Symbol(symbol));
        }
    }
    Value::Module(crate::entities::module::Module::new("sym", scope))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sym_lookup_simples() {
        let s = sym_lookup("alpha").unwrap();
        assert_eq!(s.value, "α");
        assert_eq!(s.name.as_str(), "alpha");
    }

    #[test]
    fn sym_lookup_composto_predefinido() {
        let s = sym_lookup("eq.not").unwrap();
        assert_eq!(s.value, "≠");
    }

    #[test]
    fn sym_lookup_arrow_modifier() {
        let s = sym_lookup("arrow.r.filled").unwrap();
        assert_eq!(s.value, "➡\u{fe0e}");
    }

    #[test]
    fn sym_lookup_tilde_modifier() {
        let s = sym_lookup("tilde.equiv").unwrap();
        assert_eq!(s.value, "≅");
    }

    #[test]
    fn sym_lookup_integral_modifier() {
        let s = sym_lookup("integral.double").unwrap();
        assert_eq!(s.value, "∬");
    }

    #[test]
    fn sym_lookup_chevron_modifier() {
        let s = sym_lookup("chevron.l").unwrap();
        assert_eq!(s.value, "⟨");
    }

    #[test]
    fn sym_lookup_suit_modifier() {
        let s = sym_lookup("suit.heart").unwrap();
        assert_eq!(s.value, "♥\u{fe0e}");
    }

    #[test]
    fn sym_lookup_tack_modifier() {
        let s = sym_lookup("tack.r.double").unwrap();
        assert_eq!(s.value, "⊩");
    }

    /// **P894** — `dot` bare deve ser U+22C5 (DOT OPERATOR, paridade vanilla
    /// `codex` `dot.op`, o valor por omissão do grupo), não U+00B7 (MIDDLE
    /// DOT) — esse é o valor de `dot.c`, uma variante distinta.
    #[test]
    fn sym_lookup_dot_bare_e_dot_operator() {
        let s = sym_lookup("dot").unwrap();
        assert_eq!(s.value, "⋅", "dot bare deve ser U+22C5, não U+00B7");
    }

    #[test]
    fn sym_lookup_dot_c_e_middle_dot() {
        let s = sym_lookup("dot.c").unwrap();
        assert_eq!(s.value, "·", "dot.c preserva o U+00B7 anteriormente em dot bare");
    }

    // **P895** (Parte B — catálogo de terceiros, `typst-passo-895-relatorio.md`)
    // — variantes `.alt` de letras gregas, em falta.
    #[test]
    fn sym_lookup_epsilon_alt() {
        assert_eq!(sym_lookup("epsilon.alt").unwrap().value, "ϵ");
    }
    #[test]
    fn sym_lookup_theta_alt() {
        assert_eq!(sym_lookup("theta.alt").unwrap().value, "ϑ");
    }
    #[test]
    fn sym_lookup_phi_alt() {
        assert_eq!(sym_lookup("phi.alt").unwrap().value, "ϕ");
    }
    #[test]
    fn sym_lookup_rho_alt() {
        assert_eq!(sym_lookup("rho.alt").unwrap().value, "ϱ");
    }
    #[test]
    fn sym_lookup_sigma_alt() {
        assert_eq!(sym_lookup("sigma.alt").unwrap().value, "ς");
    }

    #[test]
    fn sym_lookup_dots_h() {
        assert_eq!(sym_lookup("dots.h").unwrap().value, "…");
    }

    #[test]
    fn sym_lookup_union_big() {
        assert_eq!(sym_lookup("union.big").unwrap().value, "⋃");
    }

    /// `inter` (não `sect`, nome inexistente no vanilla — corrigido).
    #[test]
    fn sym_lookup_inter_bare() {
        assert_eq!(sym_lookup("inter").unwrap().value, "∩");
    }
    #[test]
    fn sym_lookup_inter_big() {
        assert_eq!(sym_lookup("inter.big").unwrap().value, "⋂");
    }

    #[test]
    fn sym_lookup_oo() {
        assert_eq!(sym_lookup("oo").unwrap().value, "∞");
    }
    #[test]
    fn sym_lookup_beth() {
        assert_eq!(sym_lookup("beth").unwrap().value, "ב");
    }
    #[test]
    fn sym_lookup_prop() {
        assert_eq!(sym_lookup("prop").unwrap().value, "∝");
    }

    #[test]
    fn sym_lookup_space_modifier() {
        let s = sym_lookup("space.nobreak").unwrap();
        assert_eq!(s.value, "\u{a0}");
    }

    #[test]
    fn sym_lookup_emptyset_modifier() {
        let s = sym_lookup("emptyset.rev").unwrap();
        assert_eq!(s.value, "⦰");
    }

    #[test]
    fn sym_lookup_bracket_modifier() {
        let s = sym_lookup("bracket.l.stroked").unwrap();
        assert_eq!(s.value, "⟦");
    }

    #[test]
    fn sym_lookup_amp_modifier() {
        let s = sym_lookup("amp.inv").unwrap();
        assert_eq!(s.value, "⅋");
    }

    #[test]
    fn sym_lookup_plus_o() {
        let s = sym_lookup("plus.o").unwrap();
        assert_eq!(s.value, "⊕");
    }

    #[test]
    fn sym_lookup_gt_eq_tri_not() {
        let s = sym_lookup("gt.eq.tri.not").unwrap();
        assert_eq!(s.value, "⋭");
    }

    #[test]
    fn sym_lookup_diamond_small() {
        let s = sym_lookup("diamond.small").unwrap();
        assert_eq!(s.value, "⋄");
    }

    #[test]
    fn sym_lookup_inexistente() {
        assert!(sym_lookup("inexistente").is_none());
    }

    // ── P820 — `join`/`bowtie` + mecanismo de depreciação ───────────────

    #[test]
    fn p820_sym_lookup_join_base() {
        let s = sym_lookup("join").unwrap();
        assert_eq!(s.value, "⨝");
    }

    #[test]
    fn p820_sym_lookup_join_variante_r() {
        let s = sym_lookup("join.r").unwrap();
        assert_eq!(s.value, "⟖");
    }

    #[test]
    fn p820_sym_lookup_bowtie_base() {
        // Sem caractere bare no codex: o vanilla cai na primeira variante
        // (`stroked`, ⋈) — medido `$bowtie$` → ⋈.
        let s = sym_lookup("bowtie").unwrap();
        assert_eq!(s.value, "⋈");
    }

    #[test]
    fn p820_sym_lookup_bowtie_big() {
        // Medido no vanilla: `$bowtie.big$` → ⨝ (variante `stroked.big`).
        let s = sym_lookup("bowtie.big").unwrap();
        assert_eq!(s.value, "⨝");
    }

    #[test]
    fn p820_sym_lookup_bowtie_filled() {
        let s = sym_lookup("bowtie.filled").unwrap();
        assert_eq!(s.value, "⧓");
    }

    #[test]
    fn p820_sym_deprecation_join() {
        assert_eq!(
            sym_deprecation("join"),
            Some("`join` is deprecated, use `bowtie.big` instead")
        );
    }

    #[test]
    fn p820_sym_deprecation_nao_depreciado_none() {
        assert_eq!(sym_deprecation("alpha"), None);
        assert_eq!(sym_deprecation("bowtie"), None);
        assert_eq!(sym_deprecation("inexistente"), None);
    }

    #[test]
    fn build_sym_module_contem_simples() {
        let module = build_sym_module();
        if let Value::Module(m) = module {
            let s = m.scope();
            assert!(s.get("arrow").is_some());
            assert!(s.get("alpha").is_some());
            assert!(s.get("eq").is_some());
            assert!(s.get("tilde").is_some());
        } else {
            panic!("esperado Value::Module");
        }
    }

    #[test]
    fn build_sym_module_arrow_e_symbol() {
        let module = build_sym_module();
        if let Value::Module(m) = module {
            let v = m.scope().get("arrow").unwrap();
            if let Value::Symbol(s) = v {
                assert_eq!(s.value, "→");
            } else {
                panic!("esperado Value::Symbol");
            }
        } else {
            panic!("esperado Value::Module");
        }
    }

    fn assert_codex_module(
        source: codex::Module,
        actual: &crate::entities::module::Module,
    ) {
        assert_eq!(actual.scope().iter().count(), source.iter().count());
        for (name, expected) in source.iter() {
            let actual = actual
                .scope()
                .get(name)
                .unwrap_or_else(|| panic!("missing sym.{name}"));
            match (expected.def, actual) {
                (codex::Def::Symbol(expected), Value::Symbol(actual)) => {
                    let expected_base = expected
                        .get(codex::ModifierSet::default())
                        .expect("every codex symbol has a default best match")
                        .0;
                    let expected_variants = expected
                        .variants()
                        .map(|(mods, value, _)| (mods.as_str().to_owned(), value))
                        .collect::<Vec<_>>();
                    let actual_variants = actual
                        .variants
                        .iter()
                        .map(|(mods, value)| (mods.as_str().to_owned(), value.as_str()))
                        .collect::<Vec<_>>();
                    assert_eq!(actual.value, expected_base, "wrong base for sym.{name}");
                    assert_eq!(
                        actual_variants, expected_variants,
                        "wrong variants for sym.{name}"
                    );
                }
                (codex::Def::Module(expected), Value::Module(actual)) => {
                    assert_codex_module(expected, actual);
                }
                (expected, actual) => {
                    panic!("wrong kind for sym.{name}: {expected:?} vs {actual:?}")
                }
            }
        }
    }

    #[test]
    fn p1283_catalogo_codex_integral_com_extensao_separada() {
        let Value::Module(module) = build_sym_module() else {
            panic!("sym must be module")
        };
        // O catálogo pinado só ganha os dois bindings top-level aprovados:
        // registered (P1283) e join (P1495); tri fica fora do parent.
        assert_eq!(module.scope().iter().count(), codex::SYM.iter().count() + 2);
        assert!(module.scope().get("registered").is_some());
        assert!(module.scope().get("join").is_some());
        for (name, expected) in codex::SYM.iter() {
            let actual = module
                .scope()
                .get(name)
                .unwrap_or_else(|| panic!("missing sym.{name}"));
            match (expected.def, actual) {
                (codex::Def::Symbol(expected), Value::Symbol(actual)) => {
                    let base = expected.get(codex::ModifierSet::default()).unwrap().0;
                    assert_eq!(actual.value, base, "wrong base for sym.{name}");
                    assert_eq!(
                        actual.variants.len(),
                        expected.variants().count(),
                        "wrong variants for sym.{name}"
                    );
                }
                (codex::Def::Module(expected), Value::Module(actual)) => {
                    assert_codex_module(expected, actual)
                }
                _ => panic!("wrong kind for sym.{name}"),
            }
        }
    }

    #[test]
    fn p1283_nested_aliases_e_parent_sem_bare() {
        let Value::Module(module) = build_sym_module() else {
            panic!("sym must be module")
        };
        assert!(matches!(module.scope().get("gender"), Some(Value::Module(_))));
        assert!(matches!(module.scope().get("control"), Some(Value::Module(_))));
        assert_eq!(sym_lookup("bowtie").unwrap().value, "⋈");
        assert_eq!(sym_lookup("bowtie.big").unwrap().value, "⨝");
        for (left, right) in [
            ("dollar", "pataca"),
            ("yen", "yuan"),
            ("emptyset", "nothing"),
            ("gradient", "nabla"),
        ] {
            let left = sym_lookup(left).unwrap();
            let right = sym_lookup(right).unwrap();
            assert_eq!(left.value, right.value);
            assert_eq!(left.variants, right.variants);
        }
    }
}
#[cfg(test)]
mod p1496_tests {
    use super::*;
    use crate::entities::module::Module;

    fn scope_symbol<'a>(root: &'a Module, name: &str) -> &'a Symbol {
        let Some(Value::Symbol(symbol)) = root.scope().get(name) else {
            panic!("missing public sym.{name}")
        };
        symbol
    }

    #[test]
    fn p1496_nested_catalog_has_children_and_named_variants() {
        let Value::Module(root) = build_sym_module() else {
            panic!("sym must be module")
        };
        for (parent, children) in [
            ("chess", &["king", "queen", "rook", "bishop", "knight", "pawn"][..]),
            (
                "keyboard",
                &[
                    "tab", "pageup", "pagedown", "shift", "capslock", "space", "erase",
                    "cmd", "option", "clear", "alt", "esc", "enter",
                ][..],
            ),
            ("ordinal", &["feminine", "masculine"][..]),
        ] {
            let Some(Value::Module(module)) = root.scope().get(parent) else {
                panic!("sym.{parent} must be a public module")
            };
            assert_eq!(module.scope().len(), children.len(), "sym.{parent} children");
            for child in children {
                assert!(
                    matches!(module.scope().get(child), Some(Value::Symbol(_))),
                    "missing sym.{parent}.{child}"
                );
                assert!(sym_lookup(&format!("{parent}.{child}")).is_some());
            }
        }
        for (piece, white, black) in [
            ("king", "♔", "♚"),
            ("queen", "♕", "♛"),
            ("rook", "♖", "♜"),
            ("bishop", "♗", "♝"),
            ("knight", "♘", "♞"),
            ("pawn", "♙", "♟\u{fe0e}"),
        ] {
            for (color, expected) in [("white", white), ("black", black)] {
                let path = format!("chess.{piece}.{color}");
                assert_eq!(
                    sym_lookup(&path).unwrap().value.as_str(),
                    expected,
                    "sym.{path}"
                );
            }
        }
        for (path, expected) in [
            ("keyboard.tab.r", "⇥"),
            ("keyboard.pageup.alt", "⎗"),
            ("keyboard.pagedown.alt", "⎘"),
            ("keyboard.capslock.pedestal", "⇫"),
            ("keyboard.erase.l", "⌫"),
            ("keyboard.erase.r", "⌦"),
            ("keyboard.enter.alt", "↵"),
            ("ordinal.feminine", "ª"),
            ("ordinal.masculine", "º"),
        ] {
            assert_eq!(sym_lookup(path).unwrap().value.as_str(), expected, "sym.{path}");
        }
    }

    #[test]
    fn p1496_metadata_families_and_five_tack_values_are_goldens() {
        for (path, expected) in [
            ("eq.gt.slant", "⪖"),
            ("equiv.lt", "⪙"),
            ("gt.eq.lt.slant", "⋛\u{fe00}"),
            ("lat.eq.slant", "⪭\u{fe00}"),
            ("lt.eq.gt.slant", "⋚\u{fe00}"),
            ("not.inv", "⌙"),
            ("prec.eq.slant", "≼"),
            ("smt.eq.slant", "⪬\u{fe00}"),
            ("succ.eq.slant", "≽"),
            ("tack.r.double", "⊩"),
            ("tilde.lt", "⪝"),
            ("trademark.mc", "🅪"),
            ("tack.r.double.not", "⊮"),
            ("tack.l.double", "⫣"),
            ("tack.t.double", "⫨"),
            ("tack.b.double", "⫧"),
        ] {
            assert_eq!(sym_lookup(path).unwrap().value.as_str(), expected, "sym.{path}");
        }
    }

    #[test]
    fn p1496_legacy_paths_preserved_without_mutating_gt_lt_repr() {
        let Value::Module(root) = build_sym_module() else {
            panic!("sym must be module")
        };
        for (path, expected) in [
            ("join", "⨝"),
            ("join.r", "⟖"),
            ("join.l", "⟕"),
            ("join.l.r", "⟗"),
            ("gt.tri", "⊳"),
            ("gt.tri.eq", "⊵"),
            ("gt.tri.eq.not", "⋭"),
            ("gt.tri.not", "⋫"),
            ("lt.tri", "⊲"),
            ("lt.tri.eq", "⊴"),
            ("lt.tri.eq.not", "⋬"),
            ("lt.tri.not", "⋪"),
        ] {
            assert_eq!(sym_lookup(path).unwrap().value.as_str(), expected, "sym.{path}");
        }
        // Modifiers são conjuntos: estas grafias antigas não podem
        // desaparecer só por não serem a ordem canônica do relatório.
        for (path, expected) in
            [("join.r.l", "⟗"), ("gt.eq.tri.not", "⋭"), ("lt.not.tri.eq", "⋬")]
        {
            assert_eq!(sym_lookup(path).unwrap().value.as_str(), expected, "sym.{path}");
        }
        assert_eq!(scope_symbol(&root, "join").value.as_str(), "⨝");
        for group in ["gt", "lt"] {
            let actual = scope_symbol(&root, group);
            let codex::Def::Symbol(source) = codex::SYM.get(group).unwrap().def else {
                panic!("codex {group} must be a symbol")
            };
            let expected = symbol_from_codex(group, source);
            assert_eq!(
                actual.variants, expected.variants,
                "sym.{group} variants changed"
            );
            assert_eq!(
                actual.repr_variants(),
                expected.repr_variants(),
                "sym.{group} repr changed"
            );
            assert!(
                !actual
                    .variants
                    .iter()
                    .any(|(mods, _)| mods.split('.').any(|part| part == "tri")),
                "legacy tri must not contaminate sym.{group} repr"
            );
        }
        assert!(matches!(root.scope().get("registered"), Some(Value::Symbol(_))));
        assert_eq!(sym_lookup("registered").unwrap().value.as_str(), "®");
        assert!(root.scope().get("sqrt").is_none());
        assert!(sym_lookup("sqrt").is_none());
    }

    #[test]
    fn p1496_spacebar_deprecation_and_legacy_warning_policy() {
        assert_eq!(sym_lookup("spacebar").unwrap().value.as_str(), "␣");
        assert_eq!(sym_lookup("keyboard.space").unwrap().value.as_str(), "␣");
        assert_eq!(sym_deprecation("spacebar"),
            Some("\u{60}spacebar\u{60} is deprecated, use \u{60}keyboard.space\u{60} instead"));
        assert_eq!(
            sym_deprecation("join"),
            Some("\u{60}join\u{60} is deprecated, use \u{60}bowtie.big\u{60} instead")
        );
        assert_eq!(sym_deprecation("tack"), None);
    }
}
