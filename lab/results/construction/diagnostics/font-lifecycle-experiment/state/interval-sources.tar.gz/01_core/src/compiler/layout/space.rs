//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/compiler/layout/space.md
//! @prompt-hash 08bcb057
//! @layer L1
//! @updated 2026-09-26

use super::{html_frame, FontMetrics, ImageSizer, Layouter};

pub(super) fn layout<M: FontMetrics, S: ImageSizer>(layouter: &mut Layouter<M, S>) {
    // P588 — não renderizar espaço visual no início de uma linha
    // ou parágrafo. Espaços iniciais são gerados por newlines após
    // `#set`, headings, etc., e não devem avançar o cursor.
    if html_frame::items_have_material(&layouter.regions.current.current_line) {
        layouter.regions.current.cursor_x += layouter.space_width();
        layouter
            .justify_opportunities
            .push(layouter.regions.current.cursor_x.0);
        if layouter.regions.current.cursor_x.0
            > layouter.regions.current.width - layouter.page_config.margin.right
        {
            layouter.flush_line();
        }
    }
}

#[cfg(test)]
mod tests {
    use crate::compiler::layout::{FixedMetrics, Layouter};
    use crate::entities::{
        content::Content,
        image_sizer::NullImageSizer,
        introspector::{Introspector, TagIntrospector},
        layout_types::{Point, Pt},
    };
    use comemo::Track;

    fn make(intr: &dyn Introspector) -> Layouter<'_, FixedMetrics, NullImageSizer> {
        Layouter::new(FixedMetrics, NullImageSizer, 11.0, intr.track())
    }

    #[test]
    fn atomized_spaces_suppress_initial_and_marker_only_advance() {
        let intr = TagIntrospector::empty();
        for space in [Content::Space, Content::SpaceFromNewline] {
            let mut layouter = make(&intr);
            let origin = layouter.regions.current.cursor_x;
            layouter.layout_content(&space);
            assert_eq!(layouter.regions.current.cursor_x, origin);
            layouter.regions.current.current_line.push(
                super::super::html_frame::context_marker(
                    7,
                    Point { x: origin, y: Pt(0.0) },
                ),
            );
            layouter.layout_content(&space);
            assert_eq!(layouter.regions.current.cursor_x, origin);
            assert!(layouter.justify_opportunities.is_empty());
        }
    }

    #[test]
    fn atomized_spaces_advance_and_wrap_after_material() {
        let intr = TagIntrospector::empty();
        for space in [Content::Space, Content::SpaceFromNewline] {
            let mut layouter = make(&intr);
            layouter.layout_content(&Content::text("A"));
            let before = layouter.regions.current.cursor_x;
            let width = layouter.space_width();
            layouter.layout_content(&space);
            assert_eq!(layouter.regions.current.cursor_x, before + width);
            assert_eq!(layouter.justify_opportunities, vec![(before + width).0]);
            layouter.regions.current.width =
                layouter.regions.current.cursor_x.0 + layouter.page_config.margin.right;
            layouter.layout_content(&space);
            assert!(!super::super::html_frame::items_have_material(
                &layouter.regions.current.current_line
            ));
            assert_eq!(layouter.finish().plain_text(), "A");
        }
    }
}
