# Prompt L0 — `entities/counter_registry`
Hash do Código: bd98f345

**Camada**: L1
**Ficheiro alvo**: `01_core/src/entities/counter_registry.rs`
**Criado em**: 2026-04-30 (P165 sub-passo .C — sub-store de M3)
**ADRs relevantes**: ADR-0033 (paridade vanilla), ADR-0066 (Introspection runtime)

---

## Contexto

`CounterRegistry` é o sub-store de counters indexados por kind (string). Aplica `CounterUpdate`s em ordem de chegada via `from_tags` (P165 .E).

Vanilla agrega no `ElementIntrospector` indirectamente — counters são queriáveis via `Selector` mas não há um "registry" dedicado. Cristalino isola por simetria com `LabelRegistry` e composição visível.

`CounterKey` enum vanilla (`Page | Selector(Selector) | Str(Str)`) **não** é replicado em M3. Em vez disso, usar `String` directo como chave (nomes: "heading", "figure", etc.). `CounterKey` rico fica para M9 quando counters custom forem adicionados via `counter("name")` em Typst markup.

---

## Restrições Estruturais

- Camada **L1**: struct puro, sem I/O.
- Read-only após construção (mutação só via `pub(crate) fn apply` durante fase de construção).
- `Clone` derivado.
- Forma interna: `HashMap<String, Vec<usize>>` — vector de números por kind, semelhante a `CounterStateLegacy.figure_numbers`.

---

## Interface pública

```rust
use crate::entities::counter_update::CounterUpdate;
use crate::entities::location::Location;

#[derive(Debug, Clone, Default)]
pub struct CounterRegistry {
    /* HashMap<String, Vec<usize>> — estado actual por key */
    /* HashMap<String, Vec<(Location, Vec<usize>)>> — history (P177) */
}

impl CounterRegistry {
    pub fn empty() -> Self;
    pub fn value(&self, key: &str) -> Option<&[usize]>;
    pub fn len(&self) -> usize;
    pub fn is_empty(&self) -> bool;

    /// **P170 (M9 sub-passo 2)** — formato hierárquico "1.2.3".
    pub fn format(&self, key: &str) -> Option<String>;

    /// **P177 (M9 sub-passo 7)** — valor do counter na `Location`
    /// indicada. Retorna o estado **após** todas as updates com
    /// `loc <= location`. `None` se não há update prévia.
    pub fn value_at(&self, key: &str, location: Location) -> Option<&[usize]>;

    /// **P184C** — n-ésimo snapshot (0-indexed) na história de `key`.
    /// Acesso por posição em vez de por `Location`. Suporta
    /// consumers que iteram counters por kind em ordem de
    /// aparecimento sem conhecer a `Location` (Layouter C3 figure
    /// auto-number per kind, `mod.rs:435–439`).
    /// `None` se key inexistente ou idx fora de range da história.
    pub fn value_at_index(&self, key: &str, idx: usize) -> Option<&[usize]>;

    pub(crate) fn apply(&mut self, key: String, update: CounterUpdate);

    /// **P170 (M9 sub-passo 2)** — step hierárquico ao nível indicado.
    /// Paridade com `CounterStateLegacy::step_hierarchical`. Resolve
    /// lacuna #5 (`m1-lacunas-captura.md`).
    pub(crate) fn apply_hierarchical(&mut self, key: String, level: usize);

    /// **P177 (M9 sub-passo 7)** — wrapper sobre `apply` que regista
    /// também snapshot na `history` para suportar `value_at`.
    /// Used por `from_tags` em arms `Figure`/`Citation`.
    pub(crate) fn apply_at(&mut self, key: String, update: CounterUpdate, location: Location);

    /// **P177 (M9 sub-passo 7)** — wrapper sobre `apply_hierarchical`
    /// que regista snapshot. Used por `from_tags` em arm `Heading`.
    pub(crate) fn apply_hierarchical_at(&mut self, key: String, level: usize, location: Location);
}
```

---

## Semântica

- `empty()`: cria registry vazio.
- `value(key)`: retorna o slice actual do counter. `None` se nunca foi tocado.
- `apply(key, update)` (pub(crate)): aplica update.
  - `CounterUpdate::Step`: incrementa o último elemento. Se vector vazio, inicializa com `[1]`. Semelhante a `CounterStateLegacy::step_flat`.
  - `CounterUpdate::Update(value)`: define para `[value]`. Reseta hierarquia.
- **P170**: `apply_hierarchical(key, level)` (pub(crate)): paridade com `CounterStateLegacy::step_hierarchical`. Comportamento:
  - `[]` + `1` → `[1]`.
  - `[1]` + `2` → `[1, 1]`.
  - `[1, 1]` + `1` → `[2]`.
  - Level clamped a mínimo 1.
- **P170**: `format(key)` retorna `Option<String>` com Vec<usize> joined com "." ("1.2.1"). Forma equivalente a `CounterStateLegacy::format_hierarchical`. Resolve lacuna #5 — CounterRegistry deixa de ser flat em M9.

Hierarquia em M9: counters podem ter múltiplos níveis para Headings (paridade com walk arm `Content::Heading` em `introspect.rs::279`). Counters flat (figure, equation) continuam a usar `apply(_, Step)` que mantém Vec de tamanho 1.

- **P177**: `value_at(key, location)` retorna `Option<&[usize]>` com o valor do counter **após** todas as updates de `key` com `loc <= location`. Implementação via `history` (Vec ordenado por Location, monotonicamente crescente via `Locator`). Retorna `None` se nenhuma update precede `location` ou key inexistente.
- **P177**: `apply_at(key, update, location)` e `apply_hierarchical_at(key, level, location)` são wrappers sobre `apply`/`apply_hierarchical` que adicionalmente fazem snapshot do estado actual em `history[key]` com a Location indicada. `from_tags` migra para usar `_at` versions; tests existentes em `apply`/`apply_hierarchical` mantêm-se sem location (não populam history).
- **P184C**: `value_at_index(key, idx)` retorna `Option<&[usize]>` com o snapshot na posição `idx` (0-indexed) da `history[key]`. Acesso por posição (não por Location) — suporta consumers que iteram counters por kind em ordem de aparecimento sem conhecer Locations específicas (P184D consumer C3 em `mod.rs:435–439`). `None` se key inexistente ou idx fora de range. Para counters flat (figure, equation), o snapshot na posição `idx` é `[idx + 1]` (cada `apply_at(Step)` regista o estado pós-update, que para flat é o número actual). Para counters hierárquicos (heading), o snapshot reflecte o estado completo da hierarquia naquela Location.

---

## Invariantes

- `apply` é a única mutação — caller externo (não-test) só lê.
- Counters começam vazios; primeiro `Step` inicializa em 1.
- Igualdade entre instâncias é por conteúdo do HashMap interno.
- Sem ordering determinístico em iteração — caller que precise de ordem deve usar a chave conhecida.

---

## Tests obrigatórios (sub-passo .C P165)

- `CounterRegistry::empty().value("heading")` retorna `None`.
- Após `apply("heading", Step)`, `value("heading")` retorna `Some([1])`.
- 3 `Step` consecutivos produzem `[3]`.
- `apply("heading", Update(5))` → `value("heading")` retorna `Some([5])`.
- Counters distintos isolados — apply em "heading" não afecta "figure".

---

## Consumers actuais

Nenhum no momento da criação.

## Consumers planeados

- `rules/introspect/from_tags.rs` (P165 .E) — populador.
- `entities/introspector.rs` `TagIntrospector` (P165 .D) — leitor via getter.

---

## Sobre paridade

Vanilla não tem `CounterRegistry` separado — counters são parte do estado fixpoint via `comemo` + `ElementIntrospector` queries. Cristalino isola para coerência com `LabelRegistry`. Forma simplificada (flat counter, 1 nível) é suficiente para M3 minimal viable.

Forma rica (hierarquia, função counters via `Func`) fica para M9+ paralelamente à introdução de `CounterKey` enum vanilla.

Ver `00_nucleo/diagnosticos/inventario-tipos-introspection-vanilla.md` (2026-04-30) §3 para classificação de `Counter`/`CounterKey`/`CounterUpdate` vanilla.

---

## Resultado Esperado

- `01_core/src/entities/counter_registry.rs` — struct + 5 métodos + tests.
- Re-export em `01_core/src/entities/mod.rs`.

---

## Proposta P1148 — updates completos (AGUARDA GATE ADR-0127)

Medição da fonte ratificada `a51e02804` mostra que o update transporta estado
hierárquico, nível de step ou callback. Se o gate do contrato público em
`entities/counter_update.md` for aprovado, `apply` passa a:

- substituir o estado completo por `Set(Vec<usize>)`;
- aplicar `Step(level)` com a mesma regra hierárquica já existente em
  `apply_hierarchical`;
- aplicar `Func` ao array corrente e converter o resultado novamente em
  estado, propagando erro de avaliação em vez de o ignorar.

O callback executa na construção do introspector, não no field access. A fase
já transporta `Engine + EvalContext` para callbacks de `StateUpdate`; P1148
reusa esse canal e não cria uma fase nova. Qualquer alteração de assinatura
pública adicional descoberta na materialização volta ao gate ADR-0127.

---

## Log de ações para chaves filtradas

### Medição anterior à decisão

HEAD `2f42d64253547734564513a1159ee6b584c1c4b4`:
`entities/counter_registry.rs:25-36` contém estados e snapshots, não ações;
`:69-84` distingue Step/Set/Func. A medição histórica demonstra por fonte
que inferir ações pelas diferenças de snapshots perde Set versus Step.
A medição histórica registra no vanilla
Step/Func/Step com chave filtrada resultando em 12, não apenas tamanho da query.
Estado, UTC e binários estão nos registros; não existe candidato implementado.

### Contrato

Adicionar armazenamento **privado** de eventos ordenados, somente dados L1:
Location, origem automática/manual e ação CounterUpdate verdadeira; evento
manual conserva CounterKey inteira. Evento automático remete à ocorrência
canônica por Location e preserva Step(level) efetivo/gate do seu owner.
Registrar apenas uma ação automática por ocorrência, não duplicar a escrita
auxiliar figure:kind. Não deduzir ação por número anterior/posterior.

Acesso/mutação ao log é interno pub(crate), sem novo campo público ou método
de trait. Clone/default/empty preservam isolamento por documento/iteração.
O log não importa compiler nem executa Func; não é segundo store de campos.
Estado/histórico borrowed e métodos públicos existentes conservam o contrato
de leitura materializada. O cálculo de uma chave arbitrária da linguagem
devolve vetor owned no owner de compiler, não uma referência a temporário.

Este log prepara dados para a resolução sob demanda de
`compiler/introspect/from_tags.md`, aprovada pelo dono. A aprovação de fase
não dispensa os demais gates do P1339 antes da implementação.

## P1485.3 — ordem de Page no bundle (ratificado; ADR-0127)

### Medição anterior à decisão

`value_at` filtra por Location e escolhe a última entrada por inserção
(`01_core/src/entities/counter_registry.rs:151-159`); `apply_at` acrescenta
ao fim (`:182-194`). Pós-pass Page Func pode, portanto, inserir evento
de Location anterior depois da fronteira seguinte. É risco inferido
da fonte, não prova de output Func; sonda Set e proveniência no
diagnóstico P1485. Valor Page é linguagem, ordem de armazenamento é
mecânica (ADR-0107).

### Limite do owner

Suportar por helper privado a materialização de snapshots Page em ordem
causal Location + fonte exigida por `compiler/introspect/from_tags.md`
P1485.3. Não mudar assinatura pública, significado de outras chaves nem
transformar reset em ocorrência localizada. Compiler avalia Func; entidade
guarda só estados, Locations e ações, sem Engine, I/O ou import reverso.
O contrato público de introspecção P1485.3 foi confirmado pelo dono
em 2026-09-24.


## Histórico de Revisões

| Data | Motivo | Arquivos afetados |
|------|--------|-------------------|
| 2026-04-30 | P165 sub-passo .C: sub-store de counters por kind para Introspector M3 | `counter_registry.rs`, `counter_registry.md` |
| 2026-04-29 | P177 sub-passo .B: history field + `value_at` + `apply_at` / `apply_hierarchical_at` | `counter_registry.rs`, `counter_registry.md` |
| 2026-05-03 | P184C sub-passo .C: helper `value_at_index(key, idx)` para acesso por posição na história (não por Location). Suporta `Introspector::figure_number_at_index` (P184C .D) consumido por C3 (P184D). | `counter_registry.rs`, `counter_registry.md` |
