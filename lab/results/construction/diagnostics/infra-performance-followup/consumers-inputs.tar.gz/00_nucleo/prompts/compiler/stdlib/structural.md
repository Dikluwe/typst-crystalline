# L0 — stdlib/structural
Hash do Código: 6e39d730

Layer: L1
Exclusive consumer: `01_core/src/compiler/stdlib/structural/mod.rs`

## Evidence and classification

`01_core/src/compiler/stdlib/structural/mod.rs:1` (@prompt) identifies the current owner and its local entrypoints. This is implementation inspection, not a new bilateral parity measurement or an inference of upstream intent. The historical decision evidence and its original snapshot qualifications are retained in `00_nucleo/diagnosticos/sanitization-parser-stdlib-history.md`.

## Contract and ownership

Own only structural module declarations and direct reexports of constructors and internal bridges. Preserve bibliography, divider, document, footnote, heading, lists, markup, math, outline, par, quote, table_grid, table_lines and title composition, with existing test-only child modules.

The corresponding child L0s under `00_nucleo/prompts/compiler/stdlib/structural/` exclusively own argument validation, casts, defaults, Content construction, contextual realization and mathematical module composition. This hub owns no numbering table, math formula, outline geometry, header/footer parsing or show-rule policy. Keep the existing visibility of equation/math option helpers, outline page realization and public native constructors without wrappers or wildcard reexports.

Do not copy rendering into entities or remove native bindings as part of atomization. The global registry is a different owner; mathematical namespace construction remains with the math child.

## Acceptance

Preserve the specified language semantics, syntax, morphology, diagnostics, spans, defaults and public identities. Do not change signatures, compatibility, feature defaults or phase ownership through this documentary revision. Shared pinned claims remain authoritative; this prompt owns only its exclusive consumer. Architectural decisions follow ADR-0107, ADR-0108, ADR-0109, ADR-0127, ADR-0129 and ADR-0130.
