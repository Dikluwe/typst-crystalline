# L0 — mod

Hash do Código: 100a86e0

**Layer:** L1
**Exclusive consumer:** `01_core/src/compiler/mod.rs`

## Consumer evidence

`01_core/src/compiler/mod.rs:7` locates `pub mod eval;`.
This audit locates the existing consumer; it does not establish language parity.
Historical evidence and unresolved discrepancies are archived in
`00_nucleo/diagnosticos/sanitization-remaining-compiler-history.md`.

## Ownership and boundary

This owner governs only the static compiler facade in `01_core/src/compiler/mod.rs`.
Declare the public modules `eval`, `introspect`, `lang`, `layout`,
`lexer`, `math`, `parse`, `scopes` and `stdlib`. Do not add execution
logic or behavioral reexports. Each module's own prompt owns its API and behavior.

The compiler remains pure L1: no infrastructure imports, I/O or mutable global
state. Evaluation, paginated layout and semantic HTML are distinct responsibilities;
this facade does not execute, reorder or merge their phases.

Canonical owners include `00_nucleo/prompts/compiler/eval.md`,
`00_nucleo/prompts/compiler/introspect.md`, `00_nucleo/prompts/compiler/lang.md`,
`00_nucleo/prompts/compiler/layout.md`, `00_nucleo/prompts/compiler/lexer/mod.md`,
`00_nucleo/prompts/compiler/math/mod.md`, `00_nucleo/prompts/compiler/parse.md`,
`00_nucleo/prompts/compiler/scopes.md` and `00_nucleo/prompts/compiler/stdlib/_comum.md`.
