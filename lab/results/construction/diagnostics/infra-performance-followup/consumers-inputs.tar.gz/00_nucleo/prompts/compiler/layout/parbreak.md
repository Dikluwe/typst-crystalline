# L0 — parbreak
Hash do Código: 9caffd96

**Layer:** L1
**Exclusive consumer:** `01_core/src/compiler/layout/parbreak.rs`
**Architecture:** ADR-0107, ADR-0108, ADR-0109, ADR-0127, ADR-0129, ADR-0130.

## Evidence before specification

The current consumer implements the operations specified below at `01_core/src/compiler/layout/parbreak.rs:15`, `01_core/src/compiler/layout/parbreak.rs:40`, `01_core/src/compiler/layout/parbreak.rs:92`.

Source inspection establishes current behavior and mechanical ownership; it is not a new bilateral parity measurement or evidence of upstream intent. Observable text, morphology, geometry and errors remain language-level obligations; buffer layout and traversal structure are implementation mechanics. Historical probes and their snapshot-specific qualifications are recorded in `00_nucleo/diagnosticos/sanitization-layout-history.md`. Older vanilla pins must not be presented as proof against the current pinned reference `9f2b6e8715237cb086899a42873660fe744622e8`.

## Ownership and contract

This prompt owns only the named consumer. State storage and general coordination remain in `00_nucleo/prompts/compiler/layout.md`; the contract below defines this unit's operations, not ownership of that hub.

For a material pending line, insert the transparent ParbreakBoundary before closing the line. Resolve `par.spacing` and `par.leading` from the active chain/style, falling back through `00_nucleo/prompts/compiler/layout/vanilla_defaults.md`; apply `max(spacing - leading, 0)` and the existing pending-block-margin collapse. Preserve `prev_block_below_pending`, `block_chain_active` and `prev_margin_is_parbreak`. Empty or direct-marker-only lines do not change flow. This visual boundary does not add painted text.

## Acceptance and limits

Preserve the unit's current rendered content, morphology, causal positions/pages, styles and diagnostics, including the explicitly documented limits. Follow the existing static descendant interface without altering public signatures, defaults, compatibility or pipeline phase. This documentation does not authorize implementation of unresolved proposals.
