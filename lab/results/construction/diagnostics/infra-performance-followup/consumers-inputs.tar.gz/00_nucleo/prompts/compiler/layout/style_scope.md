# L0 — style scope
Hash do Código: 43054a1c

Núcleos Tekt:
- 00_nucleo/prompts/_nuclei/layout/element-form-b.toml sha256:6dbf8faa56960845c60734f5e047685ec5b3a6f14c0ce3a48d333b8982d0baa5

**Layer:** L1
**Exclusive consumer:** `01_core/src/compiler/layout/style_scope.rs`
**Architecture:** ADR-0107, ADR-0108, ADR-0109, ADR-0127, ADR-0129, ADR-0130.

## Evidence before specification

The current consumer implements the operations specified below at `01_core/src/compiler/layout/style_scope.rs:18`, `01_core/src/compiler/layout/style_scope.rs:79`, `01_core/src/compiler/layout/style_scope.rs:93`.

Source inspection establishes current behavior and mechanical ownership; it is not a new bilateral parity measurement or evidence of upstream intent. Observable text, morphology, geometry and errors remain language-level obligations; buffer layout and traversal structure are implementation mechanics. Historical probes and their snapshot-specific qualifications are recorded in `00_nucleo/diagnosticos/sanitization-layout-history.md`. Older vanilla pins must not be presented as proof against the current pinned reference `9f2b6e8715237cb086899a42873660fe744622e8`.

## Ownership and contract

This prompt owns only the named consumer. State storage and general coordination remain in `00_nucleo/prompts/compiler/layout.md`; the contract below defines this unit's operations, not ownership of that hub.

Styled saves the chain and cached TextStyle, pushes the lexical Styles, rebuilds TextStyle and dispatches its body before restoring both. Capture the first effective document language if still absent. A private `outline.link.destination` delegates to `00_nucleo/prompts/compiler/layout_outline.md`; a `pdf.marker.tag = label` realizes the body in the existing inline subframe and emits a Label semantic envelope. A scope introducing `par.line.*` closes any material terminal line before popping. Strong and Emph install their canonical deltas with the same save/restore discipline; SmallCaps saves, enables and restores only its existing flag. Do not duplicate the hub's causal locator.

## Acceptance and limits

Preserve the unit's current rendered content, morphology, causal positions/pages, styles and diagnostics, including the explicitly documented limits. Follow the existing static descendant interface without altering public signatures, defaults, compatibility or pipeline phase. This documentation does not authorize implementation of unresolved proposals.
