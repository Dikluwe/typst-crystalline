# L0 — compiler/stdlib/registry/diagnostics
Hash do Código: 91473bbf

**Layer:** L1
**Exclusive consumer:** `01_core/src/compiler/stdlib/registry/diagnostics.rs`
**Governance:** ADR-0107, ADR-0129, ADR-0130.

## Contract

Register assert with eq/ne children, panic, numbering and eval. Numbering/eval use the Engine ABI; preserve the other native bindings. Do not validate arguments locally.

Preserve the owned public names, Value kinds, native bindings, children and
aliases. Do not implement Args validation, casts, export or lookup behavior;
those operations are outside this registration consumer.

## Acceptance

Verify the owned behavior through local tests and its existing integrations.
Preserve public paths and observable results. Ownership, nucleus integrity and
lineage checks must remain valid; no unrelated consumer is authorized by this prompt.
