# L0 — page geometry
Hash do Código: fcdf7326

**Layer:** L1
**Exclusive consumer:** `01_core/src/compiler/layout/page_geometry.rs`
**Architecture:** ADR-0107, ADR-0108, ADR-0109, ADR-0127, ADR-0129, ADR-0130.

## Evidence before specification

The current consumer implements the operations specified below at `01_core/src/compiler/layout/page_geometry.rs:103`, `01_core/src/compiler/layout/page_geometry.rs:137`, `01_core/src/compiler/layout/page_geometry.rs:9`, `01_core/src/compiler/layout/page_geometry.rs:56`, `01_core/src/compiler/layout/page_geometry.rs:72`.

Source inspection establishes current behavior and mechanical ownership; it is not a new bilateral parity measurement or evidence of upstream intent. Observable text, morphology, geometry and errors remain language-level obligations; buffer layout and traversal structure are implementation mechanics. Historical probes and their snapshot-specific qualifications are recorded in `00_nucleo/diagnosticos/sanitization-layout-history.md`. Older vanilla pins must not be presented as proof against the current pinned reference `9f2b6e8715237cb086899a42873660fe744622e8`.

## Ownership and contract

This prompt owns only the named consumer. State storage and general coordination remain in `00_nucleo/prompts/compiler/layout.md`; the contract below defines this unit's operations, not ownership of that hub.

Apply typed page geometry to PageConfig: explicit width/height override paper dimensions, omitted axes retain prior base dimensions, and flip swaps those bases. Preserve binding, direction and folded margin precedence. The apply helper initially resolves margins at physical page one; subsequent physical-page resolution remains in the existing regional transition path. Install no page, evaluate no callbacks and do not own a regional transition.

For auto width, derive rightmost material extent from emitted and pending items using `00_nucleo/prompts/compiler/layout/helpers.md`, include deferred equation logical widths and the current numbered-equation reservation, then add right margin with a minimum of total horizontal margins. The numbered reservation uses the equation width plus both number/gutter sides, with the existing 0.5em gutter. For auto height, use the causal last_block_descent_y or current cursor fallback plus bottom margin, with a minimum of vertical margins. These are final geometry projections, not arbitrary shrink-to-ink promises. `00_nucleo/prompts/compiler/layout/page_commit.md` and the hub call them at their existing composition points.

## Acceptance and limits

Preserve the unit's current rendered content, morphology, causal positions/pages, styles and diagnostics, including the explicitly documented limits. Follow the existing static descendant interface without altering public signatures, defaults, compatibility or pipeline phase. This documentation does not authorize implementation of unresolved proposals.
