# L0 — compiler/eval/tests
Hash do Código: dc8e0095

Núcleos Tekt:
- 00_nucleo/prompts/_nuclei/eval/core.toml sha256:e7642a709c937928333439b2a78cdb3a6dbd6b56d67fcc67728efd2a26796e58

**Layer:** L1 test-only
**Exclusive consumer:** `01_core/src/compiler/eval/tests.rs`
**Governance:** ADR-0107, ADR-0108, ADR-0127, ADR-0129, ADR-0130.

## Source evidence

The current exclusive consumer defines the following owned boundaries:

- `01_core/src/compiler/eval/tests.rs:26` — `fn eval_for_test`.
- `01_core/src/compiler/eval/tests.rs:36` — `fn eval_for_test_keep_sink`.
- `01_core/src/compiler/eval/tests.rs:60` — `fn eval_for_test_with_registry`.
- `01_core/src/compiler/eval/tests.rs:85` — `fn eval_for_test_full_error`.
- `01_core/src/compiler/eval/tests.rs:112` — `fn eval_for_test_with_limits`.

## Contract

Own only the eval unit-test consumer, pure test Worlds, fixtures and test helpers,
not productive evaluation code. Test public semantics, syntax, morphology and
complete observable diagnostics/spans rather than Debug, pointer addresses,
render-byte identity or an expectation copied from the candidate.

Cover literals/units, expression/block/array/dictionary/spread order, scopes,
bindings/destructuring/assignment, closures/With, operators/short-circuit, loops,
imports/includes/modules, static/bound calls, field/content/snapshot methods and
Content construction. Positive tests retain values/effects; negatives retain
severity, exact message, hint/trace order and publicly available UTF-8 half-open
ranges. Preserve legitimately absent sources without inventing anchors.

Repeat applicable feature cases under default/html/a11y/html+a11y and the independent
bundle combinations. Disabled profiles do not count as exercised parity; local
homonyms remain resolvable. Test asset/std.asset/format.bundle against the real
active constructor identity, path normalization, UTF-8/arbitrary Bytes and schema
errors (including prohibited kind), not an old active-feature placeholder.
Actual target export obligations remain with L3/L4 tests.

Imports distinguish bare no-effect identifier warning from alias/field/items/
wildcard/file/dynamic/failure cases; warnings survive later errors. Module field
diagnostics use stored names and field-only spans; std aliases retain actual
identity and imported sources retain Source. Test global color membership and
PDF accessibility gates without giving this test prompt registry ownership.
PDF type/repr are function/pdf; emoji remains module.

Array repr tests cover boundary cardinalities (0/1/39/40/41/42/81/256), nested
escaping/Unicode and full payload conservation. Elision cannot leak into Args or
Content sequences. Named-module, alias, reexport and collision tests retain stored
names. JSON/TOML/YAML default/pretty/compact, CBOR, decoders/read and nonfinite/-0.0
cases preserve their own contracts, not generic warning/trace normalization.

Args tests preserve complete occurrence order, repeats, individual and aggregate
origins through direct/alias/With/spread/sink/linked calls and distinct equal-output
factories. Callback filter/map/join order and short-circuit remain discriminatory;
arguments.filter bool failures anchor at function origin while callback failures
retain their own causal origin. Queried-content tests retain authoritative ordered
snapshot fields through arrays/closures; language equality ignores label/location
as specified but detects relevant field/numbering changes. Do not replace it with
the internal observation relation.

Textual tests separate raw ContentBlock repr from realized flow: preserve Space
after Linebreak and between newline-separated CJK before interpolation, normalize
only later insertion. Test origin/collapse/discard independently from literal/regex
cross-node matching. Keep explicit-space, Latin/Korean, ideographic punctuation,
ambiguous quotes, comments, strong/dynamic, destructive Linebreak, style-chain and
nontext boundaries as controls. Local pre-normalized show replaces only its match;
combined local CJK show and sequential identical-rule override remain separate
unresolved parity cases, not GREEN credited by these tests.

Math tests preserve real syntax/qualified construction, arity/casts, presence and
identities. Keep primes slot/nesting distinctions, cases MathAlignPoint and lr body
order. norm/round/abs require their public MathLr bodies with ‖/‖, ⌊/⌉ and |/|;
do not require historical MathDelimited lowering. lr cases likewise retain public
MathLr while unrelated MathDelimited cases keep their own contract. Annotation
families require each actual public variant/body/annotation/explicit-none state,
not glyph equivalence or MathUnderover. Mathematical overline is not text overline.
Test func/has/at/fields alongside repr where contracted. before/after tests cover
construction/default inclusive and explicit false; contextual query tests belong
to introspection's exclusive test owner.

Keep regression families for bytes, gradients, datetime, int, counter and scope,
with pure Worlds and independently frozen expectations. Neutral rounding values
are fixture mechanics, not public contracts.
No parser/build/fixture/import failure may masquerade as the expected result.
Unknown/timeout/opaque observation fails closed. Repeat/reverse orders must be
stable and comparisons may not strip diagnostics to manufacture equality.
