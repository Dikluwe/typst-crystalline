# L0 — introspect/labelled
Hash do Código: 5fb0db7f

```text
Núcleos Tekt:
- 00_nucleo/prompts/_nuclei/layout/element-form-b.toml sha256:6dbf8faa56960845c60734f5e047685ec5b3a6f14c0ce3a48d333b8982d0baa5
```

## Ownership and evidence

Layer: L1. Sole consumer: `01_core/src/compiler/introspect/labelled.rs`.
The pure compute_labelled body at `:24` reads typed, location-aware counters.
The auto Label branch at `01_core/src/compiler/introspect.rs:2300` passes
the causal wrapper chain's language, with the explicit language argument only
as fallback. Snapshot/traversal/label registration remain parent-owned.
Heading language text belongs to the canonical helper at
`00_nucleo/prompts/compiler/lang/heading_supplement.md`.

## Contract

Preserve the pure descendant free function over introspector, target Location,
Content and optional language, returning (optional resolved text, optional
figure number). Do not mutate stores or allocate identities.

For Heading, read its element-function hierarchical counter at Location and
join canonical localized supplement, a space and the number when available.
For a block Equation, read its element-function flat counter; a positive number
produces the existing compatibility text `Equação (N)`, otherwise no text.
For Figure, read its per-kind counter (default image); a positive number
produces localized figure supplement plus number and returns that figure number.
Otherwise return present empty text and no figure number. Other targets return
neither. Do not silently unwrap arbitrary Styled targets or infer a missing
numbering gate from the body's render.

This helper preserves compatibility resolved text; it is not the authoritative
numeric-reference path and must not override its precedence. It does not replace
the equation runtime supplement owner with its compatibility literal.
The parent reuses target Location, captures causal language and publishes the
derived association only when applicable.

## Acceptance and phase boundary

Check hierarchical/flat counters at the supplied target Location, missing
values, captioned/numbered Figure paths and unsupported targets without invented
associations. Check mixed-language and forward/backward heading references
against the causal store, including an explicit synthetic language fallback.
A language present in the wrapper chain always wins over that fallback;
reference/layout/environment language is not a substitute.

A show-set that changes language only in the rendered tree is not a pre-show
introspection correction. Its parity is unresolved at this boundary and any
phase change requires its own L0 and ADR-0127 approval. Preserve current
fallbacks without promising a completed language-parity result for them.
