# L0 — compiler/eval/rules
Hash do Código: 3fe03d29

Núcleos Tekt:
- 00_nucleo/prompts/_nuclei/compiler-feature-gates.toml sha256:59d8938dc06d347ccc9db23ae1b740876b369227daacd266a219811a661b3cb9
- 00_nucleo/prompts/_nuclei/eval/core.toml sha256:e7642a709c937928333439b2a78cdb3a6dbd6b56d67fcc67728efd2a26796e58

**Layer:** L1
**Exclusive consumer:** `01_core/src/compiler/eval/rules.rs`
**Governance:** ADR-0107, ADR-0108, ADR-0127, ADR-0129, ADR-0130.

## Source evidence

The current exclusive consumer defines the following owned boundaries:

- `01_core/src/compiler/eval/rules.rs:43` — `fn type_mismatch`.
- `01_core/src/compiler/eval/rules.rs:59` — `fn expected_length_error`.
- `01_core/src/compiler/eval/rules.rs:87` — `fn edge_cast_error`.
- `01_core/src/compiler/eval/rules.rs:119` — `fn pdf_pages_found_name`.
- `01_core/src/compiler/eval/rules.rs:135` — `fn validate_pdf_page_range_element`.
- `01_core/src/compiler/eval/rules.rs:213` — `fn pdf_standard_expected_list`.
- `01_core/src/compiler/eval/rules.rs:231` — `fn pdf_standard_and_list`.
- `01_core/src/compiler/eval/rules.rs:242` — `fn pdf_version_display`.
- `01_core/src/compiler/eval/rules.rs:248` — `fn pdf_standard_version_hint`.
- `01_core/src/compiler/eval/rules.rs:262` — `fn pdf_validator_label`.
- `01_core/src/compiler/eval/rules.rs:270` — `fn pdf_validator_range`.
- `01_core/src/compiler/eval/rules.rs:290` — `fn pdf_standards_conflict_diagnostic`.

Prior source readings supporting these clauses (snapshot provenance is
retained in the assigned history diagnostic, not asserted as a fresh measurement):

- `src/space_discarding.rs:53-73,194-256`.
- `text/smartquote.rs:38-89,335-419`.
- `typst-library/src/layout/page.rs:764-772`.
- `typst-library/src/layout/page.rs:813-821`.
- `typst-realize/src/spaces.rs:114-127`.

## Contract

Own set/show evaluation, argument validation, style deltas, rule application,
realization and typed interception. Preserve lexical precedence, innermost-first
application, RuleId revocation/active guards, current casts, warnings, spans and
first-error behavior. Unknown named arguments are never silently ignored.
Show-set transports Styles; transformations preserve semantic morphology.
Delegate selector semantics to
00_nucleo/prompts/compiler/eval/selector_matching.md and one-node termination to
00_nucleo/prompts/compiler/eval/show_rule_termination.md; do not duplicate either
algorithm. Native Element/Where follow the node path, not literal/regex slicing.
The special paragraph routes use the typed native-paragraph predicate without
expanding to all elements/compositions or applying text/element rules twice.

## Textual realization

Before literal/regex show on realized flow/root, collapse adjacent spaces to one
occurrence whose newline origin is the OR of its components. Discard only an
inferred newline occurrence when an adjacent internal textual character satisfies
the pure pinned Unicode nonspacing classification (Han/Bopomofo/Hiragana/Katakana/
Yi and the measured ideographic punctuation, not Korean or ambiguous curly quotes).
Use immutable data and the authorized icu_properties dependency; codex's unavailable
space_discarding module is not an import substitute. Keep explicit space between
supporting texts when no component has newline. Explicit Linebreak is destructive
and consumes adjacent spaces, including explicit ones, but remains Linebreak.
Parbreak and actual nontext content remain causal boundaries. A textless style
wrapper does not hide adjacent characters for normalization; distinct style
chains do separate regex matching groups. Do not use global trim/split_whitespace,
document language or target-specific space heuristics.

Search literal/regex over the largest eligible realized group of the same lexical
snapshot and style chain, including separated Text/space and dynamic text nodes.
Each recipe receives only its matched slice; preserve leftmost order, unmatched
prefix/suffix, precedence, guard/revocation and depth limit. A replacement is not
fed back into the same revoked rule. Empty regex matches remain rejected and
literal '.' stays distinct from regex '.'.

While a ContentBlock is only a value, preserve raw Space/SpaceFromNewline.
Its local textual show operates provisionally before normalization: replace only
the matched slice, preserving unmatched separators for later insertion. Root
realization normalizes the inserted value and applies its eligible snapshot.
The combined local CJK show/normalization case and sequential-identical-rule
override remain explicit unresolved parity obligations, not presumed successes.

## Lexical and synthesized content

Capture immutable lexical rules/styles for an OutlineElem during the renderable
interception pass before applying outline transformations, not from a final global
stack or by inventing snapshots in the pre-show pass. realize_outlines receives
the generated entry, causal snapshot and private parent styles. Apply the normal
matcher/precedence/guards once; absent transformation, use the entry default composed
from its helpers and causal link. Each fixpoint candidate is rebuilt from its own
source, not cumulatively transformed. Do not execute callbacks in pure layout or
insert realized entries as new query occurrences.

Set outline(indent:) accepts length/function/auto and the retained crystalline bool
compatibility. Set outline.entry(fill:) accepts content/none. Store validated
values lexically; explicit constructor values win. Materialize inherited indent
on outlines and fill on direct entries only when omitted. Synthesized entries
receive effective fill. A visually neutral carrier with outline.parent.indent
and outline.parent.key preserves the exact parent for contextual content returned
by a transformation, without changing matching/query order or phase.

For RawElem, synthesize raw.line only when a currently applicable typed rule targets
those instances. Split newline preserving empty segments and ordered one-based
number/count/text/body, run the normal show engine once per line and recompose
with line boundaries. Without such a rule, preserve RawElem/highlighting/default
intact. Manual raw.line uses the same dynamic carrier and show machinery; filters
read its real fields. No alternate guard or precedence algorithm is introduced.

## Set-rule schemas and transport

Keep the existing heading/page/figure/text/par/table schemas and their defaults,
casts and warning policy. Font dictionaries delegate to
00_nucleo/prompts/compiler/eval/font_dict.md. Table numbering retains lexical
table.numbering string/none capture, not the cell-cast owner. Smartquote accepts
enabled:boolean, alternative:boolean and canonical quotes string/array/dictionary/
auto forms. Existing crystalline none compatibility normalizes to auto and is not
claimed as vanilla surface. Validate the whole delta before applying it.

Recognize par.line structurally with exactly numbering (string/function/none),
number-align (horizontal alignment/auto), number-margin (left/right/start/end),
number-clearance (length/auto), numbering-scope (document/page). Store validated
par.line.* values; omission is neutral and unknown names fail. Keep numbering
Func identity/span intact: do not call it, convert its return or fabricate a
physical-line marker during set evaluation. Late execution/request handling stays
with its pipeline/layout owners.

Math set schemas delegate domain casts to the same canonical constructor domain:

- frac.style: vertical/skewed/horizontal stored as canonical Str, with explicit
  element value above cascade above vertical default; binom does not consume it.
- accent.size/dotless: relative length/bool, defaults 100%/true.
- cases.delim/reverse/gap: delimiter pair/bool/relative, defaults {}/false/0.2em.
- mat.delim/align/augment/gap/row-gap/column-gap: canonical casts. gap feeds both
  axes; specific gaps win at the same level. Defaults are ()/center/none and
  row 0.2em/column 0.5em. Explicit augment retains its offsets while folding
  cascaded stroke; explicit none clears inherited augment. Inside augment only
  hline/vline/stroke are consumed; other inner keys are tolerated, but invalid
  consumed values and unknown outer named arguments still fail.
- stretch.size: relative length with default 100%.

For all of these, explicit element arguments win over cascade, and cascade never
sets morphological presence bits or appears as fabricated explicit fields/repr.
Unknown/duplicate names and invalid values fail before effective style mutation.

Recognize dotted format targets structurally, not through an empty text_str.
Empty rules are neutral; omitted fields never insert defaults or erase an earlier
lexical decision. Preserve independent fields, schema diagnostics and ordering:

- format.svg: optional pretty Bool -> format.svg.pretty (default false only when
  the document makes no decision).
- format.png: optional ppi Int/Float -> Float at format.png.ppi. Omission does
  not insert 144.0. Finite zero/negative values retain their measured acceptance;
  nonfinite cases with an aborting oracle do not acquire a parity claim.
- format.html: gate Html at field html before evaluating any argument. The exact
  disabled diagnostic is ``cannot access field `html` because the `html` feature
  is not enabled``, with ``try enabling the `html` feature`` and
  `see https://typst.app/help/compiler-features for more details`.
  Active calls evaluate argument expressions before ordinary schema validation;
  optional pretty Bool is stored at format.html.pretty.
- format.pdf is ungated and accepts tagged Auto/Bool, pretty Bool, pages and
  standard independently under format.pdf.*. Invalid tagged uses
  `expected boolean or auto, found <type>`, not the bool-only message. Unknown,
  duplicate or positional arguments fail normally, not as unsupported-target
  warnings; preserve absence of partial effective deltas.

PDF pages validation is complete during set evaluation. Accept positive Int,
from/to dictionary, array of Int/dictionary, or explicit None. Store the original
validated Value; None is a present reset distinct from omission and empty array
is a present empty selection. Preserve `page numbers start at one`,
`page range must not be empty`,
`unexpected key "{key}", valid keys are "from" and "to"`, and
`start of page range cannot be larger than end`. Top-level mismatch expects
integer/dictionary/array/none; array-element mismatch expects only integer/dictionary.
Nested array/None elements are not accepted. The typed reconstruction belongs to
00_nucleo/prompts/compiler/layout/format_options.md and fails closed on impossible
already-validated state.

PDF standard accepts a canonical PdfStandard string or array of strings, including
empty array, but not None. Use the exact closed name list from
00_nucleo/prompts/entities/document_format_options.md. Unrecognized strings omit
the found-type suffix; wrong-typed values include it. Array-item diagnostics omit
the array alternative and retain the final 'or' list form. Validate PdfStandards::new
and map its structured conflicts to the existing precise messages/hints; normalize
a single string to a one-item Value::Array, retain an original array, then store.
This provides language parsing/conflict validation, not proof of PDF structural
conformance. Preserve distinct conflicts for version/PDF-A/PDF-UA multiplicity,
empty intersection and explicit version outside the allowed range.

This owner does not choose top-level/container boundaries, CLI precedence,
pages/tagged/standard interactions, rasterize, format SVG or export HTML/PDF.
Those retain their format-options and pipeline owners. Feature enablement remains
independent from target selection under the pinned nucleus.
