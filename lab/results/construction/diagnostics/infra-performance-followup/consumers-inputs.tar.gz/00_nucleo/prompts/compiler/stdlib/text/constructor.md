# L0 — stdlib/text/constructor
Hash do Código: c7807d84

Layer: L1
Exclusive consumer: `01_core/src/compiler/stdlib/text/constructor.rs`

## Evidence and classification

`01_core/src/compiler/stdlib/text/constructor.rs:36`, `01_core/src/compiler/stdlib/text/constructor.rs:190`, `01_core/src/compiler/stdlib/text/constructor.rs:198` identifies the current ownership boundary. This inspection is not a new bilateral parity measurement or proof of upstream intent. Historical decision evidence retains its original snapshot qualifications in `00_nucleo/diagnosticos/sanitization-parser-stdlib-history.md`.

## Contract and ownership

Own native_text and its private length/weight/style/lang/font/edge validators. Require body: Content|Str; an initial positional Color is optional fill only when no named fill is supplied, moving body to the next item. Reject excess positionals and missing body (`text() requer body como argumento`).

Accept the current VANILLA_TEXT_SET_PROPS closed set, with the same validation and transport as the set-rule owner. Known but uncaptured fields retain the existing accepted-without-effect scope limitation; unknown names, including bold/italic, fail `unexpected argument: {name}`. Preserve implemented transports: size Length -> Size(Pt), fill Color|none -> Fill/removal, weight raw Int or symbolic Str -> Weight(u16), style normal|italic|oblique -> text.style, tracking Length -> Tracking, lang BCP-47 Str -> Lang, font Str|Array[Str]|Dict -> FontList, top-edge/bottom-edge named metric or Length -> their custom values, horizontal Dir -> text.dir, variations Dict -> folded text.variations through FontVariations::from_value.

Font accepts one family, a nonempty string array, named dict with required family and optional variant/weight/style, or legacy family-keyed variants/variant arrays. Empty fallback fails `font fallback list must not be empty`. Top-edge metrics are ascender/cap-height/x-height/baseline/bounds; bottom-edge baseline/descender/bounds. Invalid metrics use edge_cast_error. Vertical ttb/btt fails `text direction must be horizontal`. Preserve `unknown font weight name: {name}` and `unknown font style name: {name}`.

Accumulate Styles and return Content::Styled, or direct body when empty. Reuse the set-rule error helpers (type_mismatch, expected_length_error, edge_cast_error), not duplicated literals. Validators remain private, only native_text is reexported. No World/context/file reads. This unit owns constructor validation; set-rule dispatch and shared pinned properties remain with their actual owners.

## Acceptance

Preserve the specified syntax, semantics, morphology, errors/hints/spans, defaults and public identities, with no productive-code change. Preserve pinned shared claims and the exclusive owner boundary under ADR-0107, ADR-0108, ADR-0109, ADR-0127, ADR-0129 and ADR-0130. Historical evidence does not establish parity against a newer snapshot.
