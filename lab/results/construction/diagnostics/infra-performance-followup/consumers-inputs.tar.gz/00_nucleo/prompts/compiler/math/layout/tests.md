# L0 — math/layout/tests

Hash do Código: 72753b5b

Núcleos Tekt:
- 00_nucleo/prompts/_nuclei/math/layout-observables.toml sha256:42a441e59c53fdc5bf619005c0e018eb63251533fb6dc6c16c13d000e592e40c

**Layer:** L1 (tests)
**Exclusive consumer:** `01_core/src/compiler/math/layout/tests.rs`

## Consumer evidence

`01_core/src/compiler/math/layout/tests.rs:16` locates `fn default_style() -> TextStyle`.
This audit locates the existing consumer; it does not establish language parity.
Historical evidence and unresolved discrepancies are archived in
`00_nucleo/diagnosticos/sanitization-remaining-compiler-history.md`.

## Test-only ownership

Own only `01_core/src/compiler/math/layout/tests.rs` and its cfg(test)
integration. Test obligations do not authorize productive geometry.
Exercise dispatch, styles, baseline/extents, spacing and feature regressions
with injected metrics and attributable oracles. Record formula/observable
provenance for new cases; fixture coordinates and bytes are not contracts.

Root fixtures preserve index_explicit: square-root controls use None/false,
explicit indices use true, without changing independent geometry oracles.

Fraction coverage distinguishes vertical/skewed/horizontal, explicit versus
omitted style, style-chain precedence, slash associativity, both
deparenthesization bits and the barless binomial. Observe axis, operand order,
separation and bar/slash presence rather than freezing font names, private
frames or operation order. Independent feature suites keep their own owners
under `00_nucleo/prompts/compiler/math/layout/`.

Acceptance observes morphology and attributable font-derived geometry;
historical RED/GREEN reports or aggregate test totals are not fresh parity
evidence.
