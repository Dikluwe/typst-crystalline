# L0 — sequence
Hash do Código: a65199cc

**Layer:** L1
**Exclusive consumer:** `01_core/src/compiler/layout/sequence.rs`
**Architecture:** ADR-0107, ADR-0108, ADR-0109, ADR-0127, ADR-0129, ADR-0130.

## Evidence before specification

The current consumer implements the operations specified below at `01_core/src/compiler/layout/sequence.rs:201`, `01_core/src/compiler/layout/sequence.rs:583`, `01_core/src/compiler/layout/sequence.rs:805`, `01_core/src/compiler/layout/sequence.rs:24`, `01_core/src/compiler/layout/sequence.rs:36`, `01_core/src/compiler/layout/sequence.rs:65`.

Source inspection establishes current behavior and mechanical ownership; it is not a new bilateral parity measurement or evidence of upstream intent. Observable text, morphology, geometry and errors remain language-level obligations; buffer layout and traversal structure are implementation mechanics. Historical probes and their snapshot-specific qualifications are recorded in `00_nucleo/diagnosticos/sanitization-layout-history.md`. Older vanilla pins must not be presented as proof against the current pinned reference `9f2b6e8715237cb086899a42873660fe744622e8`.

## Ownership and contract

This prompt owns only the named consumer. State storage and general coordination remain in `00_nucleo/prompts/compiler/layout.md`; the contract below defines this unit's operations, not ownership of that hub.

Own ordered sibling iteration, lookahead/sticky handling, item grouping, block-margin collapse and vertical fractional preflight. Dispatch each actual child through the hub, retaining boundary and page events. SpaceFromNewline has the same width/transparency/grouping/closing behavior as Space; keep its Content origin and do not normalize CJK, show/regex, Empty, Parbreak or Styled into one category.

For a finite supported region, preflight the same sibling slice without emitting items, Locations or pages: reserve fixed items/gaps, exclude fractional Block body/intrinsic height, sum finite weights and distribute nonnegative remaining height proportionally; zero weight/sum is safe and does not divide. Save/restore the private concrete Block allocation and use the re-entry guard. Do not write allocations into entities.

Recognize a fractional Block through Styled and singleton-substantive Sequence wrappers iteratively; Space, SpaceFromNewline and Empty are transparent. Ambiguous/multiple substantive children are not flattened. Ordinary finite flow retains its existing base; continuous page columns use the remaining height from the entry cursor. Only the dedicated explicit-segment entry removes the segmented-column guard and uses the same cursor-relative regional base. Cell/subframe/note contexts and nested/multiregion distribution remain fail-closed outside the source's certified paths.

### Certified inline prefixes

A supported prefix is scanned from the existing sibling slice, with scalar metric/style accumulators rather than a speculative emission engine. Plain Text/space/empty and a direct Styled/Strong/Emph Text wrapper retain their current restricted style-delta gates. Cosmetic-only wrappers do not manufacture independent fixed lines; disallowed nested/compound geometry/style cases stay opaque. Leading, font/script/tracking/edge changes and arbitrary custom channels are not implicitly accepted.

Preserve the present size-only certifications: a single reduced text wrapper; a direct outer-sized fragment paired with a larger Styled(Text) in either order; two size-only wrappers in supported decreasing/equal-above-outer cases; and the exact certified single-wrap pairs. No-wrap certification requires the real injected-width gate, not a nominal fixture size. The fixed reserve accounts for the initial top edge, actual current-line maximum/descent, the selected next ascent/leading and the paragraph-to-block boundary consistently with `00_nucleo/prompts/compiler/layout/line_commit.md`. In the above-outer decreasing/equal cases, do not double-reserve a boundary that runtime already delivers.

The certified boundary belongs to the prefix/first-fractional-Block handshake and is applied once even if trailing whitespace already closed the line. Closing early does not lose the boundary, and ordinary/rejected prefixes acquire no new displacement.

A certified single wrap requires exactly two direct size-only Styled(Text) single-word fragments, a wrap at their boundary and a complete vertical reserve that fits. Preserve equal/unequal above-outer pairs, outer/larger pairs and below/above-outer pairs in both orders. Reject multiword, additional fragment, composed delta, nested wrapper, internal/multiple wrap or insufficient reserve. A first overlong word is deferred only until the second fragment proves the complete supported form; an incomplete overlong prefix remains opaque.

Record the existing wrap/Block indices and boundary. Request the certified line-close hooks before entering the second wrapper and before terminal whitespace/Block. Reserve per-line ascent/descent/outer-leading, not the global maximum twice. When the first overlong word closes inside text emission, arm the existing one-shot so that first close uses the certified formula. For a smaller singleton, retain its own baseline/next-ascent and only outer leading; when it is second, apply the source's single baseline correction before its wrapper. The hub stores the arm, `00_nucleo/prompts/compiler/layout/line_commit.md` consumes it, and `00_nucleo/prompts/compiler/layout/sub_frame.md` isolates it.

### Grouping and flow boundaries

Preserve sticky headings, list/enum/term grouping, loose-item gap reset and enum-counter lifetime according to the current iterator, without asserting that every Parbreak resets an enum. Keep block-chain below/above collapse and terminal fractional-tail marking; do not move Block's own frame-end or Place's own anchor into a global scan. Direct private HTML markers do not create a pending material line/gap/wrap/flush; wrappers retain their existing materiality.

The certified matrix remains a bounded compatibility subset, not a full flow simulator or arbitrary fraction-parity claim. Collected structs, algorithms and exported bytes may differ from vanilla; observable content, order, pages, positions and styles may not be redefined by this documentation.

## Acceptance and limits

Preserve the unit's current rendered content, morphology, causal positions/pages, styles and diagnostics, including the explicitly documented limits. Follow the existing static descendant interface without altering public signatures, defaults, compatibility or pipeline phase. This documentation does not authorize implementation of unresolved proposals.
